import React from "react";
import { Bar, Doughnut, Line, Bubble, Scatter } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement, ArcElement,
  LineElement, PointElement, BubbleController, ScatterController,
  Title, Tooltip, Legend, Filler,
} from "chart.js";

ChartJS.register(
  CategoryScale, LinearScale, BarElement, ArcElement,
  LineElement, PointElement, BubbleController, ScatterController,
  Title, Tooltip, Legend, Filler
);

const COLORS = ["#4ADE80","#FBBF24","#60A5FA","#F87171","#A78BFA","#F472B6","#34D399","#FB923C"];

const baseOpts = {
  responsive: true, maintainAspectRatio: false,
  plugins: { legend: { display: false } },
};

// Draws the numeric value at the end of each bar — mirrors Altair's mark_text() label overlay
function makeBarLabelPlugin(formatFn, horizontal) {
  return {
    id: "barValueLabels",
    afterDatasetsDraw(chart) {
      const { ctx } = chart;
      chart.data.datasets.forEach((dataset, dsIndex) => {
        const meta = chart.getDatasetMeta(dsIndex);
        if (meta.hidden) return;
        meta.data.forEach((bar, i) => {
          const val = dataset.data[i];
          if (val === null || val === undefined) return;
          const label = formatFn ? formatFn(val) : `${val}`;
          ctx.save();
          ctx.font = "600 11px Inter, sans-serif";
          ctx.fillStyle = "#111827";
          if (horizontal) {
            ctx.textAlign = "left";
            ctx.textBaseline = "middle";
            ctx.fillText(label, bar.x + 6, bar.y);
          } else {
            ctx.textAlign = "center";
            ctx.textBaseline = "bottom";
            ctx.fillText(label, bar.x, bar.y - 4);
          }
          ctx.restore();
        });
      });
    },
  };
}

export function HBarChart({ labels, data, color = "#60A5FA", height = 300, formatFn, xAxisLabel }) {
  const cfg = {
    ...baseOpts,
    indexAxis: "y",
    layout: { padding: { right: 50 } },
    scales: {
      x: {
        grid: { display: false },
        ticks: { callback: formatFn || (v => v) },
        title: xAxisLabel ? { display: true, text: xAxisLabel, color: "#64748b", font: { size: 12 } } : undefined,
      },
      y: { grid: { display: false } },
    },
  };
  const d = {
    labels,
    datasets: [{ data, backgroundColor: color, borderRadius: 5 }],
  };
  return <div style={{ position: "relative", height }}><Bar data={d} options={cfg} plugins={[makeBarLabelPlugin(formatFn, true)]} /></div>;
}

export function VBarChart({ labels, data, color = "#60A5FA", height = 300, formatFn }) {
  const cfg = {
    ...baseOpts,
    layout: { padding: { top: 24 } },
    scales: {
      x: { grid: { display: false }, ticks: { autoSkip: false, maxRotation: 45 } },
      y: { grid: { display: false }, ticks: { callback: formatFn || (v => v) } },
    },
  };
  const d = { labels, datasets: [{ data, backgroundColor: color, borderRadius: 5 }] };
  return <div style={{ position: "relative", height }}><Bar data={d} options={cfg} plugins={[makeBarLabelPlugin(formatFn, false)]} /></div>;
}

export function GroupedBarChart({ labels, datasets, height = 320, formatFn, horizontal = false }) {
  const cfg = {
    ...baseOpts,
    indexAxis: horizontal ? "y" : "x",
    layout: horizontal ? { padding: { right: 50 } } : { padding: { top: 24 } },
    plugins: { legend: { display: true, position: "bottom" } },
    scales: {
      x: { grid: { display: false }, ticks: { autoSkip: false, maxRotation: horizontal ? 0 : 45 } },
      y: { grid: { display: false }, ticks: { callback: formatFn || (v => v) } },
    },
  };
  const d = {
    labels,
    datasets: datasets.map((ds, i) => ({
      ...ds, backgroundColor: COLORS[i % COLORS.length], borderRadius: 4,
    })),
  };
  return <div style={{ position: "relative", height }}><Bar data={d} options={cfg} plugins={[makeBarLabelPlugin(formatFn, horizontal)]} /></div>;
}

export function DonutChart({ labels, data, colors = COLORS, height = 260 }) {
  const total = data.reduce((a, b) => a + (+b || 0), 0);
  const uid = React.useId ? React.useId() : Math.random().toString(36).slice(2);

  const percentLabelPlugin = {
    id: "percentLabels-" + uid,
    afterDatasetsDraw(chart) {
      const { ctx } = chart;
      const meta = chart.getDatasetMeta(0);
      if (!meta || !meta.data || !meta.data.length) return;
      ctx.save();
      ctx.font = "700 12px Inter, sans-serif";
      ctx.fillStyle = "#1F2937";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      meta.data.forEach((arc, i) => {
        const val = data[i];
        if (!val || total === 0) return;
        const pct = Math.round((val / total) * 100);
        if (pct <= 0) return;
        const angle = (arc.startAngle + arc.endAngle) / 2;
        const r = arc.outerRadius + 16;
        const x = arc.x + Math.cos(angle) * r;
        const y = arc.y + Math.sin(angle) * r;
        ctx.fillText(`${pct}%`, x, y);
      });
      ctx.restore();
    },
  };

  const cfg = {
    responsive: true, maintainAspectRatio: false,
    cutout: "55%",
    layout: { padding: 28 },
    plugins: { legend: { display: false } },
  };
  const d = { labels, datasets: [{ data, backgroundColor: colors.slice(0, data.length), hoverOffset: 4, borderWidth: 0 }] };
  return <div style={{ position: "relative", height }}><Doughnut data={d} options={cfg} plugins={[percentLabelPlugin]} /></div>;
}

export function LineAreaChart({ labels, data, color = "#4ECDC4", fillColor = "rgba(219,234,254,0.3)", height = 220, formatFn }) {
  const cfg = {
    ...baseOpts,
    scales: {
      x: { grid: { display: false } },
      y: { grid: { display: false }, ticks: { callback: formatFn || (v => v) } },
    },
  };
  const d = {
    labels,
    datasets: [{
      data, borderColor: color, backgroundColor: fillColor,
      fill: true, tension: 0.4, pointBackgroundColor: color,
    }],
  };
  return <div style={{ position: "relative", height }}><Line data={d} options={cfg} /></div>;
}

export function BubbleChart({ datasets, height = 340, xLabel = "", yLabel = "" }) {
  const cfg = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: true, position: "bottom" } },
    scales: {
      x: { title: { display: true, text: xLabel }, grid: { display: false } },
      y: { title: { display: true, text: yLabel }, grid: { display: false } },
    },
  };
  const d = { datasets: datasets.map((ds, i) => ({ ...ds, backgroundColor: COLORS[i % COLORS.length] + "b0" })) };
  return <div style={{ position: "relative", height }}><Bubble data={d} options={cfg} /></div>;
}

export function ScatterChart({ datasets, height = 340, xLabel = "", yLabel = "" }) {
  const cfg = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: true, position: "bottom" } },
    scales: {
      x: { title: { display: true, text: xLabel }, grid: { display: false } },
      y: { title: { display: true, text: yLabel }, grid: { display: false } },
    },
  };
  const d = { datasets: datasets.map((ds, i) => ({ ...ds, backgroundColor: COLORS[i % COLORS.length], pointRadius: 10 })) };
  return <div style={{ position: "relative", height }}><Scatter data={d} options={cfg} /></div>;
}

export function DonutLegend({ items }) {
  return (
    <div className="donut-legend">
      {items.map((item, i) => (
        <span key={i} className="legend-item">
          <span className="legend-dot" style={{ background: item.color || COLORS[i % COLORS.length] }} />
          {item.label}
        </span>
      ))}
    </div>
  );
}
