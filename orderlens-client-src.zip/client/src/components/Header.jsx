import React from "react";

const LOGO_URL = process.env.REACT_APP_LOGO_URL ||
  "https://th.bing.com/th/id/OIP.Vy1yFQtg8-D1SsAxcqqtSgHaE6?w=235&h=180&c=7&r=0&o=7&dpr=1.5&pid=1.7&rm=3";

const NAV_ITEMS = [
  { key: "dashboard",  label: "Dashboard" },
  { key: "genie",      label: "Genie" },
  { key: "lifecycle",  label: "Order Life Cycle" },
  { key: "forecast",   label: "Forecast" },
  { key: "agents",     label: "AI Agents" },
];

export default function Header({ currentPage, setCurrentPage }) {
  return (
    <>
      <header className="app-header">
        <div className="header-left">
          <div>
            <div className="logo-title">OrderLens</div>
            <div className="logo-sub">Sales &amp; Operations Analytics</div>
          </div>
        </div>

        <nav className="header-nav">
          {NAV_ITEMS.map(item => (
            <button
              key={item.key}
              className={`nav-btn${currentPage === item.key ? " active" : ""}`}
              onClick={() => setCurrentPage(item.key)}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="header-right">
          <img
            className="yash-header-logo"
            src={LOGO_URL}
            alt="YASH Technologies"
            onError={e => { e.target.style.display = "none"; }}
          />
        </div>
      </header>
      <hr className="header-divider" />
    </>
  );
}
