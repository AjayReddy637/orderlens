import React, { useState, useEffect, useRef } from "react";

const DEFAULT_BG = "#FBF9F4";

export default function BgButton() {
  const [bgColor, setBgColor] = useState(() => {
    return window.__orderlensBg || DEFAULT_BG;
  });
  const [open, setOpen] = useState(false);
  const wrapRef = useRef(null);

  useEffect(() => {
    document.documentElement.style.backgroundColor = bgColor;
    document.body.style.backgroundColor = bgColor;
    const appEl = document.querySelector(".app-wrapper");
    if (appEl) appEl.style.backgroundColor = bgColor;
    window.__orderlensBg = bgColor;
  }, [bgColor]);

  useEffect(() => {
    function handleClickOutside(e) {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const presets = [
    "#FBF9F4", "#FFFFFF", "#E0F2FE", "#F3F4F6",
    "#DCFCE7", "#F3E8FF", "#FCE7F3", "#FEF9C3", "#CFFAFE",
  ];

  return (
    <div ref={wrapRef} style={{ position: "fixed", bottom: 22, right: 28, zIndex: 100000 }}>
      {open && (
        <div style={{
          position: "absolute", bottom: 60, right: 0,
          background: "#fff", borderRadius: 12, padding: 14,
          boxShadow: "0 8px 24px rgba(15,23,42,0.18)",
          border: "1px solid #E5E7EB", width: 180,
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#6B7280", marginBottom: 8, letterSpacing: 0.4 }}>
            BACKGROUND COLOR
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 6, marginBottom: 10 }}>
            {presets.map((c) => (
              <button
                key={c}
                onClick={() => setBgColor(c)}
                title={c}
                style={{
                  width: 26, height: 26, borderRadius: "50%",
                  background: c, cursor: "pointer",
                  border: bgColor === c ? "2px solid #374151" : "1px solid #E5E7EB",
                  boxShadow: bgColor === c ? "0 0 0 2px rgba(55,65,81,0.15)" : "none",
                }}
              />
            ))}
          </div>
          <input
            type="color"
            value={bgColor}
            onChange={(e) => setBgColor(e.target.value)}
            style={{ width: "100%", height: 32, border: "none", cursor: "pointer", borderRadius: 6 }}
          />
          <button
            onClick={() => setBgColor(DEFAULT_BG)}
            style={{
              marginTop: 8, width: "100%", fontSize: 11, color: "#6B7280",
              background: "#F9FAFB", border: "1px solid #E5E7EB", borderRadius: 6,
              padding: "5px 0", cursor: "pointer", fontWeight: 600,
            }}
          >
            Reset to Default
          </button>
        </div>
      )}
      <button
        onClick={() => setOpen((o) => !o)}
        title="Change background color"
        style={{
          width: 50, height: 50, borderRadius: "50%",
          background: "#fff", border: "2px solid #E5E7EB",
          boxShadow: "0 4px 12px rgba(15,23,42,0.14)",
          fontSize: 13, fontWeight: 700, color: "#374151",
          cursor: "pointer", display: "flex", alignItems: "center",
          justifyContent: "center", transition: "transform 0.15s ease",
        }}
        onMouseEnter={(e) => (e.currentTarget.style.transform = "scale(1.08)")}
        onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
      >
        BG
      </button>
    </div>
  );
}
