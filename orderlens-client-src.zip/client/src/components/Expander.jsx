import React, { useState } from "react";

export default function Expander({ title, defaultOpen = false, children }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="expander">
      <div className="expander-header" onClick={() => setOpen((o) => !o)}>
        <span>{title}</span>
        <span className={`expander-chevron${open ? " open" : ""}`}>›</span>
      </div>
      {open && <div className="expander-body">{children}</div>}
    </div>
  );
}
