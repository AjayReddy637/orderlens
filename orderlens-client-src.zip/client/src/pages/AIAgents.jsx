import React, { useState } from "react";
import { fetchPipelineFunnel, fetchDealerStageDropoff, fetchOrderVelocity } from "../services/api";
import { generateBottleneckAnalysis, generateDealerFixPlan, generateVelocityPlan } from "../services/api";

const STAGES = ["PLACED","CONFIRMED","SHIPPED","DELIVERED"];

function StepPill({ label }) {
  return <div className="step-pill">⚙ {label}</div>;
}

function ParamBox({ label, hint, children }) {
  return (
    <div className="param-box">
      <div className="param-lbl">{label}</div>
      {children}
      {hint && <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 6 }}>{hint}</div>}
    </div>
  );
}

// ─── AGENT 1: ORDER DROP-OFF ───────────────────────────────────────────────────
function DropoffAgent({ onClose }) {
  const [period, setPeriod]     = useState("Full data range");
  const [minOrd, setMinOrd]     = useState(1);
  const [topN, setTopN]         = useState(5);
  const [running, setRunning]   = useState(false);
  const [step, setStep]         = useState(0);
  const [funnel, setFunnel]     = useState(null);
  const [dealerData, setDealerData] = useState([]);
  const [aiResult, setAiResult] = useState("");
  const [dealerPlans, setDealerPlans] = useState({});

  const fracMap = { "Full data range": 1.0, "Latest 75% of data": 0.75, "Latest 50% of data": 0.5, "Latest 25% of data": 0.25 };

  function getFracClause(f) {
    if (f >= 1.0) return "dt_min";
    return `DATE_ADD('day', CAST(-ROUND(total_days * ${f}, 0) AS INTEGER), dt_max)`;
  }

  async function run() {
    setRunning(true); setStep(1); setFunnel(null); setDealerData([]); setAiResult(""); setDealerPlans({});
    const frac = fracMap[period] || 1.0;
    const fracClause = getFracClause(frac);

    try {
      const raw = await fetchPipelineFunnel(fracClause);
      const f = raw[0] || {};
      const placed    = +(f.PLACED_COUNT || f.placed_count || 0);
      const confirmed = +(f.CONFIRMED_COUNT || f.confirmed_count || 0);
      const shipped   = +(f.SHIPPED_COUNT || f.shipped_count || 0);
      const delivered = +(f.DELIVERED_COUNT || f.delivered_count || 0);
      const base = placed || 1;

      const stages = [
        { stage:"PLACED",    count:placed,    pct:100, dropPct:0, dropN:0 },
        { stage:"CONFIRMED", count:confirmed, pct:+(confirmed/base*100).toFixed(1), dropPct:+(Math.max(0,placed-confirmed)/base*100).toFixed(1), dropN:Math.max(0,placed-confirmed) },
        { stage:"SHIPPED",   count:shipped,   pct:+(shipped/base*100).toFixed(1),   dropPct:+(Math.max(0,confirmed-shipped)/Math.max(confirmed,1)*100).toFixed(1), dropN:Math.max(0,confirmed-shipped) },
        { stage:"DELIVERED", count:delivered, pct:+(delivered/base*100).toFixed(1), dropPct:+(Math.max(0,shipped-delivered)/Math.max(shipped,1)*100).toFixed(1),   dropN:Math.max(0,shipped-delivered) },
      ];
      const bottleneck = stages.slice(1).reduce((a,b) => +b.dropPct > +a.dropPct ? b : a, stages[1]);
      setFunnel({ stages, bottleneck, placed, confirmed, shipped, delivered });

      setStep(2);
      const dealers = await fetchDealerStageDropoff(fracClause, minOrd);
      setDealerData(dealers);

      setStep(3);
      const bnIdx = STAGES.indexOf(bottleneck.stage);
      const fromStage = bnIdx > 0 ? STAGES[bnIdx-1] : "PLACED";
      const toStage   = bottleneck.stage;
      const fromCol   = fromStage + "_CNT";
      const toCol     = toStage   + "_CNT";

      const worstDealers = dealers
        .filter(d => +(d[fromCol] || d[fromCol.toLowerCase()] || 0) > 0)
        .slice(0, topN)
        .map(d => ({
          DEALER_NAME: d.DEALER_NAME || d.dealer_name,
          FROM_CNT: +(d[fromCol] || d[fromCol.toLowerCase()] || 0),
          TO_CNT:   +(d[toCol]   || d[toCol.toLowerCase()]   || 0),
          DROP_PCT: Math.max(0, (+(d[fromCol] || 0) - +(d[toCol] || 0)) / Math.max(+(d[fromCol] || 0),1) * 100),
        }));

      const ai = await generateBottleneckAnalysis(
        { placed, confirmed, confirmedPct:+(confirmed/base*100).toFixed(1), confirmDrop:stages[1].dropPct,
          shipped, shippedPct:+(shipped/base*100).toFixed(1), shipDrop:stages[2].dropPct,
          delivered, deliveredPct:+(delivered/base*100).toFixed(1), delivDrop:stages[3].dropPct,
          biggestDrop: bottleneck.dropPct },
        worstDealers, `${fromStage} → ${toStage}`
      );
      setAiResult(ai);

      setStep(4);
      const plans = {};
      for (const d of worstDealers.slice(0, Math.min(topN, 5))) {
        const plan = await generateDealerFixPlan(
          d.DEALER_NAME, d.DROP_PCT, d.FROM_CNT, d.TO_CNT, fromStage, toStage
        );
        plans[d.DEALER_NAME] = plan;
      }
      setDealerPlans(plans);

    } catch(e) { alert("Error: " + e.message); }
    setRunning(false);
  }

  const STAGE_COLORS = {
    PLACED:    { fg:"#1e40af", bg:"#dbeafe" },
    CONFIRMED: { fg:"#0284c7", bg:"#e0f2fe" },
    SHIPPED:   { fg:"#0f766e", bg:"#d1fae5" },
    DELIVERED: { fg:"#059669", bg:"#d1fae5" },
  };

  function downloadCSV(rows, filename) {
    if (!rows.length) return;
    const keys = Object.keys(rows[0]);
    const csv = [keys.join(","), ...rows.map(r => keys.map(k => JSON.stringify(r[k] ?? "")).join(","))].join("\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = filename; a.click();
  }

  return (
    <div>
      <div className="ag-active-banner" style={{ background:"linear-gradient(135deg,#0f766e,#0284c7)" }}>
        <div style={{ fontSize: 32 }}>🔍</div>
        <div>
          <div style={{ fontSize: 18, fontWeight: 900 }}>Order Drop-Off Agent</div>
          <div style={{ fontSize: 13, opacity: .9 }}>Maps your 4-stage pipeline, finds where orders are stuck, and generates AI fixes.</div>
        </div>
        <button onClick={onClose} style={{ marginLeft:"auto", background:"rgba(255,255,255,.2)", border:"none", color:"#fff", borderRadius:8, padding:"6px 14px", cursor:"pointer", fontWeight:700 }}>✕ Close</button>
      </div>

      <div style={{ fontSize:14, fontWeight:700, marginBottom:12 }}>Parameters</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 16 }}>
        <ParamBox label="Analysis Period" hint="Uses your actual data dates automatically.">
          <select className="filter-input" style={{ width:"100%" }} value={period} onChange={e => setPeriod(e.target.value)}>
            {["Full data range","Latest 75% of data","Latest 50% of data","Latest 25% of data"].map(o => <option key={o}>{o}</option>)}
          </select>
        </ParamBox>
        <ParamBox label="Min Orders per Dealer" hint={`Only dealers with ≥ ${minOrd} total orders.`}>
          <input type="range" min={1} max={20} value={minOrd} onChange={e => setMinOrd(+e.target.value)} style={{ width:"100%" }} />
          <div style={{ fontSize:13, fontWeight:700 }}>{minOrd}</div>
        </ParamBox>
        <ParamBox label="Top N Dealers per Stage" hint={`Show ${topN} worst-performing dealers.`}>
          <input type="range" min={3} max={15} value={topN} onChange={e => setTopN(+e.target.value)} style={{ width:"100%" }} />
          <div style={{ fontSize:13, fontWeight:700 }}>{topN}</div>
        </ParamBox>
      </div>

      <button className="btn btn-primary" style={{ width: "100%", padding: "12px 0", fontSize: 14 }} onClick={run} disabled={running}>
        {running ? "Running…" : "Run Order Drop-Off Agent"}
      </button>

      {step >= 1 && !funnel && <div className="spinner-text"><span className="spinner-dot" /> Building pipeline funnel…</div>}

      {funnel && (
        <>
          <StepPill label="Step 1 — Pipeline Funnel" />
          <div style={{ fontSize:14, fontWeight:700, marginBottom:12 }}>Order Pipeline Funnel</div>
          <div className="funnel-row">
            {funnel.stages.map(s => {
              const col = STAGE_COLORS[s.stage] || { fg:"#374151", bg:"#F3F4F6" };
              const isBn = s.stage === funnel.bottleneck.stage;
              return (
                <div key={s.stage} className="funnel-tile"
                  style={{ background:col.bg, border:`2px solid ${isBn ? "#DC2626" : col.bg}` }}>
                  {isBn && <div style={{ fontSize:10, fontWeight:800, color:"#DC2626", marginBottom:2 }}>⚠ BOTTLENECK</div>}
                  <div style={{ fontSize: 22, fontWeight: 900 }} style={{ color:col.fg }}>{s.count.toLocaleString()}</div>
                  <div style={{ fontSize: 12, fontWeight: 700 }} style={{ color:col.fg }}>{s.stage}</div>
                  <div style={{ fontSize: 12, opacity: .8 }} style={{ color:col.fg }}>{s.pct}% of placed</div>
                  {s.dropPct > 0 && (
                    <div style={{ fontSize: 11, fontWeight: 700, marginTop: 8 }} style={{ color:s.dropPct>=20?"#DC2626":s.dropPct>=10?"#D97706":"#64748b" }}>
                      ▼ {s.dropPct}% dropped
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginTop: 14 }}>
            {funnel.stages.slice(1).map((s, i) => {
              const prev = funnel.stages[i];
              const c = +s.dropPct >= 20 ? "#dc2626" : +s.dropPct >= 10 ? "#d97706" : "#059669";
              return (
                <div key={s.stage} className="funnel-flow-card">
                  <div style={{ fontSize: 11, color: "#64748b", marginBottom: 4 }}>{STAGES[i]} → {s.stage}</div>
                  <div style={{ fontSize: 20, fontWeight: 900 }} style={{ color:c }}>{s.dropPct}%</div>
                  <div style={{ fontSize: 11 }} style={{ color:c }}>dropout rate · {s.dropN.toLocaleString()} orders lost</div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {step >= 2 && dealerData.length > 0 && (
        <>
          <StepPill label="Step 2 — Dealer Breakdown" />
          <div style={{ fontSize:14, fontWeight:700, marginBottom:8 }}>Dealer Performance by Stage</div>
          <div className="card" style={{ padding: 16, marginBottom: 16 }}>
            <table className="data-table">
              <thead>
                <tr><th>Dealer</th><th>Total Orders</th><th>Confirmed %</th><th>Shipped %</th><th>Delivered %</th></tr>
              </thead>
              <tbody>
                {dealerData.map((r,i) => (
                  <tr key={i}>
                    <td>{r.DEALER_NAME || r.dealer_name}</td>
                    <td>{(r.TOTAL_ORDERS || r.total_orders || 0).toLocaleString()}</td>
                    <td>{parseFloat(r.CONFIRMED_PCT || r.confirmed_pct || 0).toFixed(1)}%</td>
                    <td>{parseFloat(r.SHIPPED_PCT || r.shipped_pct || 0).toFixed(1)}%</td>
                    <td>{parseFloat(r.DELIVERED_PCT || r.delivered_pct || 0).toFixed(1)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {step >= 3 && aiResult && (
        <>
          <StepPill label="Step 3 — AI Bottleneck Analysis" />
          <div style={{ fontSize:14, fontWeight:700, marginBottom:8 }}>AI Bottleneck &amp; Fix Recommendations</div>
          <div style={{ background: "#f0fdf4", borderLeft: "4px solid #059669", borderRadius: 10, padding: "18px 20px", fontSize: 13, lineHeight: 1.8 }} style={{ marginBottom:16 }}
            dangerouslySetInnerHTML={{ __html: aiResult.replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\n/g,"<br/>") }} />
        </>
      )}

      {step >= 4 && Object.keys(dealerPlans).length > 0 && (
        <>
          <StepPill label="Step 4 — Per-Dealer Action Plans" />
          <div style={{ fontSize:14, fontWeight:700, marginBottom:8 }}>Per-Dealer Action Plans</div>
          {Object.entries(dealerPlans).map(([dealer, plan]) => (
            <details key={dealer} style={{ marginBottom:8 }}>
              <summary style={{ cursor:"pointer", padding:"10px 14px", background:"#F8FAFC", borderRadius:10, border:"1px solid #E5E7EB", fontWeight:700, fontSize:13 }}>
                🔴 {dealer}
              </summary>
              <div style={{ background: "#f0fdf4", borderLeft: "4px solid #059669", borderRadius: 10, padding: "18px 20px", fontSize: 13, lineHeight: 1.8 }} style={{ borderRadius:"0 0 10px 10px", marginTop:0 }}
                dangerouslySetInnerHTML={{ __html: plan.replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\n/g,"<br/>") }} />
            </details>
          ))}

          <div style={{ marginTop:16 }}>
            <div style={{ fontSize:14, fontWeight:700, marginBottom:8 }}>Export Full Pipeline Report</div>
            <div style={{ display: "flex", gap: 12 }}>
              <button className="btn btn-secondary" onClick={() => downloadCSV(funnel?.stages || [], "funnel_summary.csv")}>⬇ Download Funnel Summary (CSV)</button>
              <button className="btn btn-secondary" onClick={() => downloadCSV(dealerData, "dealer_dropoff.csv")}>⬇ Download Dealer Breakdown (CSV)</button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ─── AGENT 2: ORDER VELOCITY ───────────────────────────────────────────────────
function VelocityAgent({ onClose }) {
  const [split, setSplit]     = useState("50% / 50%");
  const [thresh, setThresh]   = useState(20);
  const [maxD, setMaxD]       = useState(10);
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState([]);
  const [plans, setPlans]     = useState({});
  const [step, setStep]       = useState(0);

  const splitMap = { "50% / 50%": 0.5, "33% / 67%": 0.33, "25% / 75%": 0.25 };

  async function run() {
    setRunning(true); setStep(1); setResults([]); setPlans({});
    const sf = splitMap[split] || 0.5;
    try {
      const rows = await fetchOrderVelocity(sf, thresh, maxD);
      setResults(rows);
      setStep(2);
      const p = {};
      for (const row of rows.slice(0, 5)) {
        const dealer    = row.DEALER_NAME || row.dealer_name;
        const prevOrds  = +(row.PREV_ORDERS || 0);
        const currOrds  = +(row.CURR_ORDERS || 0);
        const dropPct   = +(row.ORDER_CHANGE_PCT || 0);
        const prevRev   = +(row.PREV_REV || 0);
        const currRev   = +(row.CURR_REV || 0);
        const prevOpd   = +(row.PREV_ORDERS_PER_DAY || 0);
        const currOpd   = +(row.CURR_ORDERS_PER_DAY || 0);
        const prevProd  = +(row.PREV_PRODUCTS || 0);
        const currProd  = +(row.CURR_PRODUCTS || 0);
        const dropType  = (prevProd - currProd) <= Math.max(1, prevProd/2) ? "product-specific slowdown" : "broad activity drop";
        const catSummary = `${prevProd} products before → ${currProd} now`;
        const plan = await generateVelocityPlan(dealer, prevOrds, currOrds, dropPct, prevRev, currRev, prevOpd, currOpd, catSummary, dropType);
        p[dealer] = plan;
      }
      setPlans(p);
    } catch(e) { alert("Error: " + e.message); }
    setRunning(false);
  }

  function downloadCSV() {
    const rows = results.map(r => ({
      Dealer: r.DEALER_NAME || r.dealer_name,
      "Prior Orders": r.PREV_ORDERS, "Current Orders": r.CURR_ORDERS,
      "Order Change %": r.ORDER_CHANGE_PCT, "Prior Rev": r.PREV_REV, "Current Rev": r.CURR_REV,
    }));
    const keys = Object.keys(rows[0] || {});
    const csv = [keys.join(","), ...rows.map(r => keys.map(k => JSON.stringify(r[k] ?? "")).join(","))].join("\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csv], {type:"text/csv"}));
    a.download = "velocity_report.csv"; a.click();
  }

  return (
    <div>
      <div className="ag-active-banner" style={{ background:"linear-gradient(135deg,#0f766e,#0891b2)" }}>
        <div style={{ fontSize: 32 }}>🚦</div>
        <div>
          <div style={{ fontSize: 18, fontWeight: 900 }}>Order Velocity Agent</div>
          <div style={{ fontSize: 13, opacity: .9 }}>Detects dealers whose ordering pace has slowed and generates re-engagement plans.</div>
        </div>
        <button onClick={onClose} style={{ marginLeft:"auto", background:"rgba(255,255,255,.2)", border:"none", color:"#fff", borderRadius:8, padding:"6px 14px", cursor:"pointer", fontWeight:700 }}>✕ Close</button>
      </div>

      <div style={{ fontSize:14, fontWeight:700, marginBottom:12 }}>Parameters</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 16 }}>
        <ParamBox label="Split Point" hint="Splits data into current vs prior period.">
          <select className="filter-input" style={{ width:"100%" }} value={split} onChange={e => setSplit(e.target.value)}>
            {["50% / 50%","33% / 67%","25% / 75%"].map(o => <option key={o}>{o}</option>)}
          </select>
        </ParamBox>
        <ParamBox label="Min Order Count Drop %" hint={`Flag dealers with ≥ ${thresh}% fewer orders.`}>
          <input type="range" min={5} max={60} step={5} value={thresh} onChange={e => setThresh(+e.target.value)} style={{ width:"100%" }} />
          <div style={{ fontSize:13, fontWeight:700 }}>{thresh}%</div>
        </ParamBox>
        <ParamBox label="Max Dealers to Analyse" hint={`Analyse top ${maxD} slowdown dealers.`}>
          <input type="range" min={3} max={20} value={maxD} onChange={e => setMaxD(+e.target.value)} style={{ width:"100%" }} />
          <div style={{ fontSize:13, fontWeight:700 }}>{maxD}</div>
        </ParamBox>
      </div>
      <button className="btn btn-primary" style={{ width: "100%", padding: "12px 0", fontSize: 14 }} onClick={run} disabled={running}>
        {running ? "Running…" : "Run Order Velocity Agent"}
      </button>

      {step >= 1 && results.length === 0 && running && (
        <div className="spinner-text"><span className="spinner-dot" /> Comparing order velocity…</div>
      )}

      {results.length > 0 && (
        <>
          <StepPill label="Step 1 — Velocity Results" />
          <div style={{ fontSize:14, fontWeight:700, marginBottom:8 }}>Dealers with Order Slowdown ≥ {thresh}%</div>
          <div className="card" style={{ padding: 16, marginBottom: 16 }}>
            <table className="data-table">
              <thead>
                <tr><th>Dealer</th><th>Prior Orders</th><th>Current Orders</th><th>Change %</th><th>Prior Rev</th><th>Current Rev</th></tr>
              </thead>
              <tbody>
                {results.map((r,i) => {
                  const chg = parseFloat(r.ORDER_CHANGE_PCT || r.order_change_pct || 0);
                  return (
                    <tr key={i}>
                      <td>{r.DEALER_NAME || r.dealer_name}</td>
                      <td>{(+(r.PREV_ORDERS || 0)).toLocaleString()}</td>
                      <td>{(+(r.CURR_ORDERS || 0)).toLocaleString()}</td>
                      <td style={{ color:chg < 0 ? "#DC2626" : "#059669", fontWeight:700 }}>{chg.toFixed(1)}%</td>
                      <td>${parseFloat(r.PREV_REV || 0).toLocaleString()}</td>
                      <td>${parseFloat(r.CURR_REV || 0).toLocaleString()}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}

      {Object.keys(plans).length > 0 && (
        <>
          <StepPill label="Step 2 — Re-engagement Plans" />
          <div style={{ fontSize:14, fontWeight:700, marginBottom:8 }}>Re-engagement Plans</div>
          {Object.entries(plans).map(([dealer, plan]) => (
            <details key={dealer} style={{ marginBottom:8 }}>
              <summary style={{ cursor:"pointer", padding:"10px 14px", background:"#F8FAFC", borderRadius:10, border:"1px solid #E5E7EB", fontWeight:700, fontSize:13 }}>
                🔴 {dealer}
              </summary>
              <div style={{ background: "#f0fdf4", borderLeft: "4px solid #059669", borderRadius: 10, padding: "18px 20px", fontSize: 13, lineHeight: 1.8 }} style={{ borderRadius:"0 0 10px 10px", marginTop:0 }}
                dangerouslySetInnerHTML={{ __html: plan.replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\n/g,"<br/>") }} />
            </details>
          ))}
          <div style={{ display: "flex", gap: 12 }} style={{ marginTop:16 }}>
            <button className="btn btn-secondary" onClick={downloadCSV}>⬇ Download Velocity Report (CSV)</button>
          </div>
        </>
      )}
    </div>
  );
}

// ─── AGENT 3: SMART FULFILLMENT ────────────────────────────────────────────────
function FulfillmentAgent({ onClose }) {
  return (
    <div>
      <div className="ag-active-banner" style={{ background:"linear-gradient(135deg,#0891b2,#0f766e)" }}>
        <div style={{ fontSize: 32 }}>🚚</div>
        <div>
          <div style={{ fontSize: 18, fontWeight: 900 }}>Smart Fulfillment Agent</div>
          <div style={{ fontSize: 13, opacity: .9 }}>
            Optimises order routing across your warehouses, dark stores and retail outlets.
            For any product going to any region, finds the fastest node (Speed mode) or the
            cheapest node (Cost mode) — with full stock check, carrier, cost and delivery-day breakdown.
          </div>
        </div>
        <button onClick={onClose} style={{ marginLeft:"auto", background:"rgba(255,255,255,.2)", border:"none", color:"#fff", borderRadius:8, padding:"6px 14px", cursor:"pointer", fontWeight:700 }}>✕ Close</button>
      </div>

      <div className="step-pill">⚙ Step 1 — Fulfillment Network Overview</div>

      <div style={{ background: "#fef2f2", border: "1.5px solid #fecaca", borderRadius: 12, padding: "14px 16px", marginTop: 12 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: "#b91c1c", marginBottom: 4 }}>
          ⚠️ Smart Fulfillment tables not found
        </div>
        <div style={{ fontSize: 12, color: "#7f1d1d" }}>
          Please run STEP1, STEP2 and STEP3 SQL scripts first in your Athena/Glue setup
          to create the required tables and views.
        </div>
      </div>

      <div style={{ background: "#fff7ed", border: "1.5px solid #fed7aa", borderRadius: 12, padding: "18px 20px", marginTop: 12 }}>
        <div style={{ fontWeight: 800, fontSize: 14, color: "#c2410c", marginBottom: 10 }}>
          📋 What you need to run first:
        </div>
        <div style={{ fontSize: 13, color: "#374151", lineHeight: 2 }}>
          <b>Step 1</b> → STEP1_CREATE_RAW_TABLES.sql — creates the 3 raw source tables<br/>
          <b>Step 2</b> → STEP2_INSERT_SAMPLE_DATA.sql — loads sample fulfillment data<br/>
          <b>Step 3</b> → STEP3_CREATE_VIEWS.sql — creates the views the agent queries
        </div>
        <div style={{ fontSize: 12, color: "#92400e", marginTop: 12 }}>
          Required tables: <code>FULFILLMENT_NODES</code>, <code>INVENTORY_BY_LOCATION</code>, <code>SHIPPING_COST_MATRIX</code>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN AI AGENTS PAGE ───────────────────────────────────────────────────────
export default function AIAgents() {
  const [activeAgent, setActiveAgent] = useState(null);

  const AGENTS = [
    { key:"dropoff",     icon:"🔍", iconCls:"agent-icon-1", title:"Order Drop-Off Agent",
      desc:"Finds every stuck ORDER ID in your pipeline right now. Shows exactly how many days each order has been sitting at the same status, detects SLA breaches, and generates a per-order action list.",
      label:"Launch Order Drop-Off Agent" },
    { key:"velocity",    icon:"🚦", iconCls:"agent-icon-2", title:"Order Velocity Agent",
      desc:"Finds specific dealer–product combinations that are overdue for reorder based on each dealer's own historical reorder cycle. Generates a proactive outreach task list with channel, message hook and urgency.",
      label:"Launch Order Velocity Agent" },
    { key:"fulfillment", icon:"🚚", iconCls:"agent-icon-3", title:"Smart Fulfillment Agent",
      desc:"Optimises order routing across your warehouses, dark stores and retail outlets. Finds the fastest node (Speed mode) or cheapest node (Cost mode) — with full stock check, carrier, cost and delivery-day breakdown.",
      label:"Launch Smart Fulfillment Agent" },
  ];

  return (
    <div className="block-container">
      <div className="ag-hero">
        <h1>AI Agents</h1>
        <p>Autonomous multi-step workflows that analyse your order data, diagnose issues, optimise fulfillment routing, generate AI action plans and produce exportable reports — all in one click.</p>
      </div>

      <div style={{ fontSize: 12, color: "#64748b", marginBottom: 16 }}>
        Data-driven agents run live against your Athena tables — parameters below control the analysis window.
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20 }}>
        {AGENTS.map(a => (
          <div key={a.key} className="ag-card">
            <div className={`ag-icon ${a.key === "dropoff" ? "ag-icon-rev" : a.key === "velocity" ? "ag-icon-int" : "ag-icon-sf"}`}>{a.icon}</div>
            <div className="ag-title">{a.title}</div>
            <div className="ag-desc">{a.desc}</div>
            <button
              className={`btn ${activeAgent === a.key ? "btn-primary" : "btn-secondary"}`} style={{ width: "100%" }}
              onClick={() => setActiveAgent(a.key)}
            >
              {a.label}
            </button>
          </div>
        ))}
      </div>

      {activeAgent && (
        <>
          <hr style={{ border: "none", borderTop: "2px solid #e5e7eb", margin: "24px 0 20px" }} />
          {activeAgent === "dropoff"     && <DropoffAgent     onClose={() => setActiveAgent(null)} />}
          {activeAgent === "velocity"    && <VelocityAgent    onClose={() => setActiveAgent(null)} />}
          {activeAgent === "fulfillment" && <FulfillmentAgent onClose={() => setActiveAgent(null)} />}
        </>
      )}
    </div>
  );
}
