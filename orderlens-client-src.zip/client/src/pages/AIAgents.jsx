import React, { useState, useEffect } from "react";
import { fetchPipelineFunnel, fetchDealerStageDropoff, fetchOrderVelocity } from "../services/api";
import { generateBottleneckAnalysis, generateDealerFixPlan, generateVelocityPlan } from "../services/api";
import { fetchFulfillmentProducts, fetchFulfillmentRegions, fetchFulfillmentRoute, fetchFulfillmentOverview, fetchFulfillmentNodes, fetchDataRange } from "../services/api";
import Expander from "../components/Expander";

const STAGES = ["PLACED","CONFIRMED","SHIPPED","DELIVERED"];

function StepPill({ label }) {
  return <div className="step-pill">⚙ {label}</div>;
}

function ParamBox({ label, hint, children }) {
  return (
    <div className="param-box">
      <div className="param-lbl">{label}</div>
      {children}
      {hint && <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 6 }}>{hint}</div>}
    </div>
  );
}

// ─── AGENT 1: ORDER DROP-OFF ───────────────────────────────────────────────────
function DropoffAgent({ onClose }) {
  const [period, setPeriod]     = useState("Full data range");
  const [minOrd, setMinOrd]     = useState(1);
  const [topN, setTopN]         = useState(5);
  const [running, setRunning]   = useState(false);
  const [step, setStep]         = useState(0);
  const [funnel, setFunnel]     = useState(null);
  const [dealerData, setDealerData] = useState([]);
  const [aiResult, setAiResult] = useState("");
  const [dealerPlans, setDealerPlans] = useState({});

  const fracMap = { "Full data range": 1.0, "Latest 75% of data": 0.75, "Latest 50% of data": 0.5, "Latest 25% of data": 0.25 };

  function getFracClause(f) {
    if (f >= 1.0) return "dt_min";
    return `DATE_ADD('day', CAST(-ROUND(total_days * ${f}, 0) AS INTEGER), dt_max)`;
  }

  async function run() {
    setRunning(true); setStep(1); setFunnel(null); setDealerData([]); setAiResult(""); setDealerPlans({});
    const frac = fracMap[period] || 1.0;
    const fracClause = getFracClause(frac);

    try {
      const raw = await fetchPipelineFunnel(fracClause);
      const f = raw[0] || {};
      const placed    = +(f.PLACED_COUNT || f.placed_count || 0);
      const confirmed = +(f.CONFIRMED_COUNT || f.confirmed_count || 0);
      const shipped   = +(f.SHIPPED_COUNT || f.shipped_count || 0);
      const delivered = +(f.DELIVERED_COUNT || f.delivered_count || 0);
      const base = placed || 1;

      const stages = [
        { stage:"PLACED",    count:placed,    pct:100, dropPct:0, dropN:0 },
        { stage:"CONFIRMED", count:confirmed, pct:+(confirmed/base*100).toFixed(1), dropPct:+(Math.max(0,placed-confirmed)/base*100).toFixed(1), dropN:Math.max(0,placed-confirmed) },
        { stage:"SHIPPED",   count:shipped,   pct:+(shipped/base*100).toFixed(1),   dropPct:+(Math.max(0,confirmed-shipped)/Math.max(confirmed,1)*100).toFixed(1), dropN:Math.max(0,confirmed-shipped) },
        { stage:"DELIVERED", count:delivered, pct:+(delivered/base*100).toFixed(1), dropPct:+(Math.max(0,shipped-delivered)/Math.max(shipped,1)*100).toFixed(1),   dropN:Math.max(0,shipped-delivered) },
      ];
      const bottleneck = stages.slice(1).reduce((a,b) => +b.dropPct > +a.dropPct ? b : a, stages[1]);
      setFunnel({ stages, bottleneck, placed, confirmed, shipped, delivered });

      setStep(2);
      const dealers = await fetchDealerStageDropoff(fracClause, minOrd);
      setDealerData(dealers);

      setStep(3);
      const bnIdx = STAGES.indexOf(bottleneck.stage);
      const fromStage = bnIdx > 0 ? STAGES[bnIdx-1] : "PLACED";
      const toStage   = bottleneck.stage;
      const fromCol   = fromStage + "_CNT";
      const toCol     = toStage   + "_CNT";

      const worstDealers = dealers
        .filter(d => +(d[fromCol] || d[fromCol.toLowerCase()] || 0) > 0)
        .slice(0, topN)
        .map(d => ({
          DEALER_NAME: d.DEALER_NAME || d.dealer_name,
          FROM_CNT: +(d[fromCol] || d[fromCol.toLowerCase()] || 0),
          TO_CNT:   +(d[toCol]   || d[toCol.toLowerCase()]   || 0),
          DROP_PCT: Math.max(0, (+(d[fromCol] || 0) - +(d[toCol] || 0)) / Math.max(+(d[fromCol] || 0),1) * 100),
        }));

      const ai = await generateBottleneckAnalysis(
        { placed, confirmed, confirmedPct:+(confirmed/base*100).toFixed(1), confirmDrop:stages[1].dropPct,
          shipped, shippedPct:+(shipped/base*100).toFixed(1), shipDrop:stages[2].dropPct,
          delivered, deliveredPct:+(delivered/base*100).toFixed(1), delivDrop:stages[3].dropPct,
          biggestDrop: bottleneck.dropPct },
        worstDealers, `${fromStage} → ${toStage}`
      );
      setAiResult(ai);

      setStep(4);
      const plans = {};
      for (const d of worstDealers.slice(0, Math.min(topN, 5))) {
        const plan = await generateDealerFixPlan(
          d.DEALER_NAME, d.DROP_PCT, d.FROM_CNT, d.TO_CNT, fromStage, toStage
        );
        plans[d.DEALER_NAME] = plan;
      }
      setDealerPlans(plans);

    } catch(e) { alert("Error: " + e.message); }
    setRunning(false);
  }

  const STAGE_COLORS = {
    PLACED:    { fg:"#1e40af", bg:"#dbeafe" },
    CONFIRMED: { fg:"#0284c7", bg:"#e0f2fe" },
    SHIPPED:   { fg:"#0f766e", bg:"#d1fae5" },
    DELIVERED: { fg:"#059669", bg:"#d1fae5" },
  };

  function downloadCSV(rows, filename) {
    if (!rows.length) return;
    const keys = Object.keys(rows[0]);
    const csv = [keys.join(","), ...rows.map(r => keys.map(k => JSON.stringify(r[k] ?? "")).join(","))].join("\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = filename; a.click();
  }

  return (
    <div>
      <div className="ag-active-banner" style={{ background:"linear-gradient(135deg,#0f766e,#0284c7)" }}>
        <div style={{ fontSize: 32 }}>🔍</div>
        <div>
          <div style={{ fontSize: 18, fontWeight: 900 }}>Order Drop-Off Agent</div>
          <div style={{ fontSize: 13, opacity: .9 }}>Maps your 4-stage pipeline, finds where orders are stuck, and generates AI fixes.</div>
        </div>
        <button onClick={onClose} style={{ marginLeft:"auto", background:"rgba(255,255,255,.2)", border:"none", color:"#fff", borderRadius:8, padding:"6px 14px", cursor:"pointer", fontWeight:700 }}>✕ Close</button>
      </div>

      <div style={{ fontSize:14, fontWeight:700, marginBottom:12 }}>Parameters</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 16 }}>
        <ParamBox label="Analysis Period" hint="Uses your actual data dates automatically.">
          <select className="filter-input" style={{ width:"100%" }} value={period} onChange={e => setPeriod(e.target.value)}>
            {["Full data range","Latest 75% of data","Latest 50% of data","Latest 25% of data"].map(o => <option key={o}>{o}</option>)}
          </select>
        </ParamBox>
        <ParamBox label="Min Orders per Dealer" hint={`Only dealers with ≥ ${minOrd} total orders.`}>
          <input type="range" min={1} max={20} value={minOrd} onChange={e => setMinOrd(+e.target.value)} style={{ width:"100%" }} />
          <div style={{ fontSize:13, fontWeight:700 }}>{minOrd}</div>
        </ParamBox>
        <ParamBox label="Top N Dealers per Stage" hint={`Show ${topN} worst-performing dealers.`}>
          <input type="range" min={3} max={15} value={topN} onChange={e => setTopN(+e.target.value)} style={{ width:"100%" }} />
          <div style={{ fontSize:13, fontWeight:700 }}>{topN}</div>
        </ParamBox>
      </div>

      <button className="btn btn-primary" style={{ width: "100%", padding: "12px 0", fontSize: 14 }} onClick={run} disabled={running}>
        {running ? "Running…" : "Run Order Drop-Off Agent"}
      </button>

      {step >= 1 && !funnel && <div className="spinner-text"><span className="spinner-dot" /> Building pipeline funnel…</div>}

      {funnel && (
        <>
          <StepPill label="Step 1 — Pipeline Funnel" />
          <div style={{ fontSize:14, fontWeight:700, marginBottom:12 }}>Order Pipeline Funnel</div>
          <div className="funnel-row">
            {funnel.stages.map(s => {
              const col = STAGE_COLORS[s.stage] || { fg:"#374151", bg:"#F3F4F6" };
              const isBn = s.stage === funnel.bottleneck.stage;
              return (
                <div key={s.stage} className="funnel-tile"
                  style={{ background:col.bg, border:`2px solid ${isBn ? "#DC2626" : col.bg}` }}>
                  {isBn && <div style={{ fontSize:10, fontWeight:800, color:"#DC2626", marginBottom:2 }}>⚠ BOTTLENECK</div>}
                  <div style={{ fontSize: 22, fontWeight: 900 }} style={{ color:col.fg }}>{s.count.toLocaleString()}</div>
                  <div style={{ fontSize: 12, fontWeight: 700 }} style={{ color:col.fg }}>{s.stage}</div>
                  <div style={{ fontSize: 12, opacity: .8 }} style={{ color:col.fg }}>{s.pct}% of placed</div>
                  {s.dropPct > 0 && (
                    <div style={{ fontSize: 11, fontWeight: 700, marginTop: 8 }} style={{ color:s.dropPct>=20?"#DC2626":s.dropPct>=10?"#D97706":"#64748b" }}>
                      ▼ {s.dropPct}% dropped
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginTop: 14 }}>
            {funnel.stages.slice(1).map((s, i) => {
              const prev = funnel.stages[i];
              const c = +s.dropPct >= 20 ? "#dc2626" : +s.dropPct >= 10 ? "#d97706" : "#059669";
              return (
                <div key={s.stage} className="funnel-flow-card">
                  <div style={{ fontSize: 11, color: "#64748b", marginBottom: 4 }}>{STAGES[i]} → {s.stage}</div>
                  <div style={{ fontSize: 20, fontWeight: 900 }} style={{ color:c }}>{s.dropPct}%</div>
                  <div style={{ fontSize: 11 }} style={{ color:c }}>dropout rate · {s.dropN.toLocaleString()} orders lost</div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {step >= 2 && dealerData.length > 0 && (
        <>
          <StepPill label="Step 2 — Dealer Breakdown" />
          <div style={{ fontSize:14, fontWeight:700, marginBottom:8 }}>Dealer Performance by Stage</div>
          <div className="card" style={{ padding: 16, marginBottom: 16 }}>
            <table className="data-table">
              <thead>
                <tr><th>Dealer</th><th>Total Orders</th><th>Confirmed %</th><th>Shipped %</th><th>Delivered %</th></tr>
              </thead>
              <tbody>
                {dealerData.map((r,i) => (
                  <tr key={i}>
                    <td>{r.DEALER_NAME || r.dealer_name}</td>
                    <td>{(r.TOTAL_ORDERS || r.total_orders || 0).toLocaleString()}</td>
                    <td>{parseFloat(r.CONFIRMED_PCT || r.confirmed_pct || 0).toFixed(1)}%</td>
                    <td>{parseFloat(r.SHIPPED_PCT || r.shipped_pct || 0).toFixed(1)}%</td>
                    <td>{parseFloat(r.DELIVERED_PCT || r.delivered_pct || 0).toFixed(1)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {step >= 3 && aiResult && (
        <>
          <StepPill label="Step 3 — AI Bottleneck Analysis" />
          <div style={{ fontSize:14, fontWeight:700, marginBottom:8 }}>AI Bottleneck &amp; Fix Recommendations</div>
          <div style={{ background: "#f0fdf4", borderLeft: "4px solid #059669", borderRadius: 10, padding: "18px 20px", fontSize: 13, lineHeight: 1.8 }} style={{ marginBottom:16 }}
            dangerouslySetInnerHTML={{ __html: aiResult.replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\n/g,"<br/>") }} />
        </>
      )}

      {step >= 4 && Object.keys(dealerPlans).length > 0 && (
        <>
          <StepPill label="Step 4 — Per-Dealer Action Plans" />
          <div style={{ fontSize:14, fontWeight:700, marginBottom:8 }}>Per-Dealer Action Plans</div>
          {Object.entries(dealerPlans).map(([dealer, plan]) => (
            <details key={dealer} style={{ marginBottom:8 }}>
              <summary style={{ cursor:"pointer", padding:"10px 14px", background:"#F8FAFC", borderRadius:10, border:"1px solid #E5E7EB", fontWeight:700, fontSize:13 }}>
                🔴 {dealer}
              </summary>
              <div style={{ background: "#f0fdf4", borderLeft: "4px solid #059669", borderRadius: 10, padding: "18px 20px", fontSize: 13, lineHeight: 1.8 }} style={{ borderRadius:"0 0 10px 10px", marginTop:0 }}
                dangerouslySetInnerHTML={{ __html: plan.replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\n/g,"<br/>") }} />
            </details>
          ))}

          <div style={{ marginTop:16 }}>
            <div style={{ fontSize:14, fontWeight:700, marginBottom:8 }}>Export Full Pipeline Report</div>
            <div style={{ display: "flex", gap: 12 }}>
              <button className="btn btn-secondary" onClick={() => downloadCSV(funnel?.stages || [], "funnel_summary.csv")}>⬇ Download Funnel Summary (CSV)</button>
              <button className="btn btn-secondary" onClick={() => downloadCSV(dealerData, "dealer_dropoff.csv")}>⬇ Download Dealer Breakdown (CSV)</button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ─── AGENT 2: ORDER VELOCITY ───────────────────────────────────────────────────
function VelocityAgent({ onClose }) {
  const [split, setSplit]     = useState("50% / 50%");
  const [thresh, setThresh]   = useState(20);
  const [maxD, setMaxD]       = useState(10);
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState([]);
  const [plans, setPlans]     = useState({});
  const [step, setStep]       = useState(0);

  const splitMap = { "50% / 50%": 0.5, "33% / 67%": 0.33, "25% / 75%": 0.25 };

  async function run() {
    setRunning(true); setStep(1); setResults([]); setPlans({});
    const sf = splitMap[split] || 0.5;
    try {
      const rows = await fetchOrderVelocity(sf, thresh, maxD);
      setResults(rows);
      setStep(2);
      const p = {};
      for (const row of rows.slice(0, 5)) {
        const dealer    = row.DEALER_NAME || row.dealer_name;
        const prevOrds  = +(row.PREV_ORDERS || 0);
        const currOrds  = +(row.CURR_ORDERS || 0);
        const dropPct   = +(row.ORDER_CHANGE_PCT || 0);
        const prevRev   = +(row.PREV_REV || 0);
        const currRev   = +(row.CURR_REV || 0);
        const prevOpd   = +(row.PREV_ORDERS_PER_DAY || 0);
        const currOpd   = +(row.CURR_ORDERS_PER_DAY || 0);
        const prevProd  = +(row.PREV_PRODUCTS || 0);
        const currProd  = +(row.CURR_PRODUCTS || 0);
        const dropType  = (prevProd - currProd) <= Math.max(1, prevProd/2) ? "product-specific slowdown" : "broad activity drop";
        const catSummary = `${prevProd} products before → ${currProd} now`;
        const plan = await generateVelocityPlan(dealer, prevOrds, currOrds, dropPct, prevRev, currRev, prevOpd, currOpd, catSummary, dropType);
        p[dealer] = plan;
      }
      setPlans(p);
    } catch(e) { alert("Error: " + e.message); }
    setRunning(false);
  }

  function downloadCSV() {
    const rows = results.map(r => ({
      Dealer: r.DEALER_NAME || r.dealer_name,
      "Prior Orders": r.PREV_ORDERS, "Current Orders": r.CURR_ORDERS,
      "Order Change %": r.ORDER_CHANGE_PCT, "Prior Rev": r.PREV_REV, "Current Rev": r.CURR_REV,
    }));
    const keys = Object.keys(rows[0] || {});
    const csv = [keys.join(","), ...rows.map(r => keys.map(k => JSON.stringify(r[k] ?? "")).join(","))].join("\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csv], {type:"text/csv"}));
    a.download = "velocity_report.csv"; a.click();
  }

  return (
    <div>
      <div className="ag-active-banner" style={{ background:"linear-gradient(135deg,#0f766e,#0891b2)" }}>
        <div style={{ fontSize: 32 }}>🚦</div>
        <div>
          <div style={{ fontSize: 18, fontWeight: 900 }}>Order Velocity Agent</div>
          <div style={{ fontSize: 13, opacity: .9 }}>Detects dealers whose ordering pace has slowed and generates re-engagement plans.</div>
        </div>
        <button onClick={onClose} style={{ marginLeft:"auto", background:"rgba(255,255,255,.2)", border:"none", color:"#fff", borderRadius:8, padding:"6px 14px", cursor:"pointer", fontWeight:700 }}>✕ Close</button>
      </div>

      <div style={{ fontSize:14, fontWeight:700, marginBottom:12 }}>Parameters</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 16 }}>
        <ParamBox label="Split Point" hint="Splits data into current vs prior period.">
          <select className="filter-input" style={{ width:"100%" }} value={split} onChange={e => setSplit(e.target.value)}>
            {["50% / 50%","33% / 67%","25% / 75%"].map(o => <option key={o}>{o}</option>)}
          </select>
        </ParamBox>
        <ParamBox label="Min Order Count Drop %" hint={`Flag dealers with ≥ ${thresh}% fewer orders.`}>
          <input type="range" min={5} max={60} step={5} value={thresh} onChange={e => setThresh(+e.target.value)} style={{ width:"100%" }} />
          <div style={{ fontSize:13, fontWeight:700 }}>{thresh}%</div>
        </ParamBox>
        <ParamBox label="Max Dealers to Analyse" hint={`Analyse top ${maxD} slowdown dealers.`}>
          <input type="range" min={3} max={20} value={maxD} onChange={e => setMaxD(+e.target.value)} style={{ width:"100%" }} />
          <div style={{ fontSize:13, fontWeight:700 }}>{maxD}</div>
        </ParamBox>
      </div>
      <button className="btn btn-primary" style={{ width: "100%", padding: "12px 0", fontSize: 14 }} onClick={run} disabled={running}>
        {running ? "Running…" : "Run Order Velocity Agent"}
      </button>

      {step >= 1 && results.length === 0 && running && (
        <div className="spinner-text"><span className="spinner-dot" /> Comparing order velocity…</div>
      )}

      {results.length > 0 && (
        <>
          <StepPill label="Step 1 — Velocity Results" />
          <div style={{ fontSize:14, fontWeight:700, marginBottom:8 }}>Dealers with Order Slowdown ≥ {thresh}%</div>
          <div className="card" style={{ padding: 16, marginBottom: 16 }}>
            <table className="data-table">
              <thead>
                <tr><th>Dealer</th><th>Prior Orders</th><th>Current Orders</th><th>Change %</th><th>Prior Rev</th><th>Current Rev</th></tr>
              </thead>
              <tbody>
                {results.map((r,i) => {
                  const chg = parseFloat(r.ORDER_CHANGE_PCT || r.order_change_pct || 0);
                  return (
                    <tr key={i}>
                      <td>{r.DEALER_NAME || r.dealer_name}</td>
                      <td>{(+(r.PREV_ORDERS || 0)).toLocaleString()}</td>
                      <td>{(+(r.CURR_ORDERS || 0)).toLocaleString()}</td>
                      <td style={{ color:chg < 0 ? "#DC2626" : "#059669", fontWeight:700 }}>{chg.toFixed(1)}%</td>
                      <td>${parseFloat(r.PREV_REV || 0).toLocaleString()}</td>
                      <td>${parseFloat(r.CURR_REV || 0).toLocaleString()}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}

      {Object.keys(plans).length > 0 && (
        <>
          <StepPill label="Step 2 — Re-engagement Plans" />
          <div style={{ fontSize:14, fontWeight:700, marginBottom:8 }}>Re-engagement Plans</div>
          {Object.entries(plans).map(([dealer, plan]) => (
            <details key={dealer} style={{ marginBottom:8 }}>
              <summary style={{ cursor:"pointer", padding:"10px 14px", background:"#F8FAFC", borderRadius:10, border:"1px solid #E5E7EB", fontWeight:700, fontSize:13 }}>
                🔴 {dealer}
              </summary>
              <div style={{ background: "#f0fdf4", borderLeft: "4px solid #059669", borderRadius: 10, padding: "18px 20px", fontSize: 13, lineHeight: 1.8 }} style={{ borderRadius:"0 0 10px 10px", marginTop:0 }}
                dangerouslySetInnerHTML={{ __html: plan.replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\n/g,"<br/>") }} />
            </details>
          ))}
          <div style={{ display: "flex", gap: 12 }} style={{ marginTop:16 }}>
            <button className="btn btn-secondary" onClick={downloadCSV}>⬇ Download Velocity Report (CSV)</button>
          </div>
        </>
      )}
    </div>
  );
}

// ─── AGENT 3: SMART FULFILLMENT ────────────────────────────────────────────────
function FulfillmentAgent({ onClose }) {
  const [products, setProducts] = useState([]);
  const [regions, setRegions]   = useState([]);
  const [overview, setOverview] = useState(null);
  const [nodes, setNodes]       = useState([]);
  const [productId, setProductId] = useState("");
  const [productSearch, setProductSearch] = useState("");
  const [toRegion, setToRegion]   = useState("");
  const [mode, setMode]           = useState("speed");
  const [results, setResults]     = useState(null);
  const [running, setRunning]     = useState(false);
  const [loadingOpts, setLoadingOpts] = useState(true);
  const [errMsg, setErrMsg]       = useState(null);

  useEffect(() => {
    Promise.all([
      fetchFulfillmentProducts(), fetchFulfillmentRegions(),
      fetchFulfillmentOverview(), fetchFulfillmentNodes(),
    ])
      .then(([p, r, ov, nd]) => {
        setProducts(p.map(row => ({ id: row.product_id || row.PRODUCT_ID, name: row.product_name || row.PRODUCT_NAME })));
        setRegions(r.map(row => row.to_region || row.TO_REGION));
        setOverview(ov);
        setNodes(nd);
        setLoadingOpts(false);
      })
      .catch(() => setLoadingOpts(false));
  }, []);

  const filteredProducts = productSearch
    ? products.filter(p => p.name.toLowerCase().includes(productSearch.toLowerCase()))
    : products;

  async function run() {
    if (!productId || !toRegion) return;
    setRunning(true);
    setErrMsg(null);
    setResults(null);
    try {
      const rows = await fetchFulfillmentRoute(productId, toRegion, mode);
      setResults(rows);
    } catch (e) {
      setErrMsg(e.message);
    }
    setRunning(false);
  }

  return (
    <div>
      <div className="ag-active-banner" style={{ background:"linear-gradient(135deg,#0891b2,#0f766e)" }}>
        <div style={{ fontSize: 32 }}>🚚</div>
        <div>
          <div style={{ fontSize: 18, fontWeight: 900 }}>Smart Fulfillment Agent</div>
          <div style={{ fontSize: 13, opacity: .9 }}>
            Finds the optimal fulfillment node — fastest delivery or lowest cost — with live stock check
            across all warehouses, dark stores and retail outlets.
          </div>
        </div>
        <button onClick={onClose} style={{ marginLeft:"auto", background:"rgba(255,255,255,.2)", border:"none", color:"#fff", borderRadius:8, padding:"6px 14px", cursor:"pointer", fontWeight:700 }}>✕ Close</button>
      </div>

      <div className="step-pill">⚙ Step 1 — Fulfillment Network Overview</div>

      {loadingOpts ? (
        <div className="spinner-text" style={{ marginTop: 14 }}><span className="spinner-dot" /> Loading fulfillment network…</div>
      ) : (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 12, marginTop: 14, marginBottom: 14 }}>
            <div className="funnel-tile" style={{ background: "#dbeafe" }}>
              <div style={{ fontSize: 26, fontWeight: 900, color: "#1e40af" }}>{overview?.warehouses ?? overview?.WAREHOUSES ?? 0}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#1e3a8a" }}>Warehouses</div>
            </div>
            <div className="funnel-tile" style={{ background: "#fef3c7" }}>
              <div style={{ fontSize: 26, fontWeight: 900, color: "#92400e" }}>{overview?.dark_stores ?? overview?.DARK_STORES ?? 0}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#78350f" }}>Dark Stores</div>
            </div>
            <div className="funnel-tile" style={{ background: "#d1fae5" }}>
              <div style={{ fontSize: 26, fontWeight: 900, color: "#065f46" }}>{overview?.retail_nodes ?? overview?.RETAIL_NODES ?? 0}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#064e3b" }}>Retail Nodes</div>
            </div>
            <div className="funnel-tile" style={{ background: "#ede9fe" }}>
              <div style={{ fontSize: 26, fontWeight: 900, color: "#5b21b6" }}>{overview?.products ?? overview?.PRODUCTS ?? 0}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#4c1d95" }}>Products</div>
            </div>
            <div className="funnel-tile" style={{ background: "#dbeafe" }}>
              <div style={{ fontSize: 26, fontWeight: 900, color: "#1e40af" }}>{overview?.regions ?? overview?.REGIONS ?? 0}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#1e3a8a" }}>Regions</div>
            </div>
          </div>

          <Expander title="📍 View All Fulfillment Nodes">
            <table className="data-table">
              <thead><tr><th>Warehouse ID</th><th>Name</th><th>Type</th><th>City</th><th>Region</th><th>Country</th></tr></thead>
              <tbody>
                {nodes.map((n, i) => (
                  <tr key={i}>
                    <td>{n.warehouse_id}</td><td>{n.warehouse_name}</td><td>{n.node_type}</td>
                    <td>{n.city}</td><td>{n.region}</td><td>{n.country}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Expander>

          <div style={{ fontWeight: 800, fontSize: 16, margin: "20px 0 12px", color: "#0f172a" }}>Routing Parameters</div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginBottom: 6 }}>
            <div>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#374151", marginBottom: 4 }}>PRODUCT TO ROUTE</div>
              <input
                className="filter-input" style={{ width: "100%", marginBottom: 6 }}
                placeholder="Search product…" value={productSearch}
                onChange={e => setProductSearch(e.target.value)}
              />
              <select className="filter-input" style={{ width: "100%" }} value={productId} onChange={e => setProductId(e.target.value)}>
                <option value="">Select a product…</option>
                {filteredProducts.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
              <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 4 }}>Select the product you want to fulfill.</div>
            </div>

            <div>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#374151", marginBottom: 4 }}>DELIVERY REGION</div>
              <select className="filter-input" style={{ width: "100%" }} value={toRegion} onChange={e => setToRegion(e.target.value)}>
                <option value="">Select a region…</option>
                {regions.map(r => <option key={r} value={r}>{r}</option>)}
              </select>
              <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 4 }}>Where the order needs to be delivered.</div>
            </div>

            <div>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#374151", marginBottom: 4 }}>PRIORITY MODE</div>
              <label style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, cursor: "pointer", fontSize: 14 }}>
                <input type="radio" name="priorityMode" checked={mode === "speed"} onChange={() => setMode("speed")} />
                ⚡ Speed — Fastest delivery
              </label>
              <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 14 }}>
                <input type="radio" name="priorityMode" checked={mode === "cost"} onChange={() => setMode("cost")} />
                💰 Cost — Lowest total cost
              </label>
              <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 6 }}>
                {mode === "speed" ? "Speed: closest node with stock, fastest carrier." : "Cost: cheapest shipping route with stock available."}
              </div>
            </div>
          </div>
        </>
      )}

      <button className="btn btn-primary" style={{ width: "100%", padding: "12px 0", fontSize: 14, marginTop: 14 }}
        onClick={run} disabled={!productId || !toRegion || running}>
        {running ? "Finding best route…" : "Run Smart Fulfillment Agent"}
      </button>

      {!productId && !toRegion && !running && (
        <div className="info-box" style={{ marginTop: 14 }}>
          Select a product, delivery region and priority mode, then click <b>Run Smart Fulfillment Agent</b>.
        </div>
      )}

      {running && <div className="spinner-text" style={{ marginTop: 16 }}><span className="spinner-dot" /> Checking stock and shipping routes…</div>}

      {errMsg && (
        <div style={{ background: "#fef2f2", border: "1.5px solid #fecaca", borderRadius: 12, padding: "14px 16px", marginTop: 16 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "#b91c1c" }}>⚠️ {errMsg}</div>
        </div>
      )}

      {results && results.length === 0 && !running && (
        <div className="info-box" style={{ marginTop: 16 }}>
          No fulfillment node currently has this product in stock with a route to {toRegion}.
        </div>
      )}

      {results && results.length > 0 && !running && (
        <div style={{ marginTop: 16 }}>
          <div style={{ fontWeight: 800, fontSize: 15, marginBottom: 10, color: "#0f172a" }}>
            Recommended Route ({mode === "speed" ? "Fastest" : "Cheapest"})
          </div>
          {results.slice(0, 1).map((r, i) => (
            <div key={i} className="card" style={{ background: "#f0fdf4", border: "1.5px solid #bbf7d0", marginBottom: 12 }}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
                <div>
                  <div style={{ fontSize: 11, color: "#64748b", fontWeight: 700 }}>FROM NODE</div>
                  <div style={{ fontSize: 15, fontWeight: 800 }}>{r.warehouse_name}</div>
                  <div style={{ fontSize: 12, color: "#475569" }}>{r.node_type} • {r.node_city}, {r.node_region}</div>
                </div>
                <div>
                  <div style={{ fontSize: 11, color: "#64748b", fontWeight: 700 }}>STOCK AVAILABLE</div>
                  <div style={{ fontSize: 15, fontWeight: 800, color: "#059669" }}>{(+r.stock_qty).toLocaleString()} units</div>
                  <div style={{ fontSize: 12, color: "#475569" }}>Reorder at {(+r.reorder_threshold).toLocaleString()}</div>
                </div>
                <div>
                  <div style={{ fontSize: 11, color: "#64748b", fontWeight: 700 }}>DELIVERY</div>
                  <div style={{ fontSize: 15, fontWeight: 800 }}>{r.est_delivery_days} day{r.est_delivery_days === 1 ? "" : "s"}</div>
                  <div style={{ fontSize: 12, color: "#475569" }}>{r.carrier} • {r.service_type}</div>
                </div>
              </div>
              <div style={{ marginTop: 12, paddingTop: 12, borderTop: "1px solid #d1fae5", display: "flex", justifyContent: "space-between" }}>
                <div style={{ fontSize: 13, color: "#475569" }}>Shipping to {r.to_city}, {r.to_region}</div>
                <div style={{ fontSize: 18, fontWeight: 900, color: "#059669" }}>${(+r.shipping_cost).toFixed(2)}</div>
              </div>
            </div>
          ))}

          {results.length > 1 && (
            <Expander title={`View ${results.length - 1} alternative route${results.length - 1 === 1 ? "" : "s"}`}>
              <table className="data-table">
                <thead>
                  <tr><th>Node</th><th>City</th><th>Stock</th><th>Cost</th><th>Days</th><th>Carrier</th></tr>
                </thead>
                <tbody>
                  {results.slice(1).map((r, i) => (
                    <tr key={i}>
                      <td>{r.warehouse_name}</td>
                      <td>{r.node_city}</td>
                      <td>{(+r.stock_qty).toLocaleString()}</td>
                      <td>${(+r.shipping_cost).toFixed(2)}</td>
                      <td>{r.est_delivery_days}d</td>
                      <td>{r.carrier}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Expander>
          )}
        </div>
      )}
    </div>
  );
}

// ─── MAIN AI AGENTS PAGE ───────────────────────────────────────────────────────
export default function AIAgents() {
  const [activeAgent, setActiveAgent] = useState(null);
  const [dataRange, setDataRange] = useState(null);

  useEffect(() => {
    fetchDataRange().then(setDataRange).catch(() => {});
  }, []);

  const AGENTS = [
    { key:"fulfillment", icon:"🚚", iconCls:"agent-icon-3", title:"Smart Fulfillment Agent",
      desc:"Optimises order routing across your warehouses, dark stores and retail outlets. Finds the fastest node (Speed mode) or cheapest node (Cost mode) — with full stock check, carrier, cost and delivery-day breakdown.",
      label:"Launch Smart Fulfillment Agent" },
  ];

  return (
    <div className="block-container">
      <div className="ag-hero">
        <h1>AI Agents</h1>
        <p>Autonomous multi-step workflows that analyse your order data, diagnose issues, optimise fulfillment routing, generate AI action plans and produce exportable reports — all in one click.</p>
      </div>

      <div style={{ fontSize: 12, color: "#64748b", marginBottom: 16 }}>
        {dataRange && (dataRange.MIN_DATE || dataRange.min_date)
          ? `Data available: ${dataRange.MIN_DATE || dataRange.min_date} → ${dataRange.MAX_DATE || dataRange.max_date} | ${(dataRange.DEALERS || dataRange.dealers || 0).toLocaleString()} dealers | ${(dataRange.ORDERS || dataRange.orders || 0).toLocaleString()} orders`
          : "Data-driven agents run live against your Athena tables — parameters below control the analysis window."}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 20, maxWidth: 340 }}>
        {AGENTS.map(a => (
          <div key={a.key} className="ag-card">
            <div className="ag-icon ag-icon-sf">{a.icon}</div>
            <div className="ag-title">{a.title}</div>
            <div className="ag-desc">{a.desc}</div>
            <button
              className={`btn ${activeAgent === a.key ? "btn-primary" : "btn-secondary"}`} style={{ width: "100%" }}
              onClick={() => setActiveAgent(a.key)}
            >
              {a.label}
            </button>
          </div>
        ))}
      </div>

      {activeAgent && (
        <>
          <hr style={{ border: "none", borderTop: "2px solid #e5e7eb", margin: "24px 0 20px" }} />
          {activeAgent === "fulfillment" && <FulfillmentAgent onClose={() => setActiveAgent(null)} />}
        </>
      )}
    </div>
  );
}
