import React, { useState, useRef, useEffect } from "react";
import { generateGenieAnswer, runQuery, fetchMonthlyRevenue, fetchRevByDealer, fetchSalesByProductType, fetchOrderStatus } from "../services/api";
import Expander from "../components/Expander";
import { LineAreaChart, HBarChart } from "../components/Charts";

const QUICK_ANALYSES = [
  {
    key: "revenue_overview", title: "Revenue Overview",
    desc: "Track total revenue, monthly trends and major changes",
    question: "Show me total revenue YTD, monthly trends, and top 5 dealers",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="4" y="14" width="4" height="6" rx="1" fill="white"/><rect x="10" y="10" width="4" height="10" rx="1" fill="white"/><rect x="16" y="6" width="4" height="14" rx="1" fill="white"/></svg>
    ),
  },
  {
    key: "dealer_analysis", title: "Dealer Analysis",
    desc: "Understand dealer-wise revenue, concentration, and dependency",
    question: "Analyze dealer concentration and dependency",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="9" cy="7" r="3" stroke="white" strokeWidth="1.5" fill="none"/><path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2" stroke="white" strokeWidth="1.5" fill="none"/><rect x="14" y="8" width="8" height="2" rx="0.5" fill="white"/><rect x="14" y="12" width="6" height="2" rx="0.5" fill="white"/><rect x="14" y="16" width="8" height="2" rx="0.5" fill="white"/></svg>
    ),
  },
  {
    key: "product_performance", title: "Product Performance",
    desc: "Identify top products, revenue, and quantity trends",
    question: "Show top products by revenue and quantity",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M7 3h8l5 5v11a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z" stroke="white" strokeWidth="1.5" fill="none"/><line x1="7" y1="9" x2="17" y2="9" stroke="white" strokeWidth="1.5"/><line x1="7" y1="13" x2="15" y2="13" stroke="white" strokeWidth="1.5"/></svg>
    ),
  },
  {
    key: "order_status", title: "Order Status",
    desc: "See order status distribution, fulfillment, and bottlenecks",
    question: "Show order status distribution by count and revenue",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="white" strokeWidth="1.5" fill="none"/><path d="M12 6v6l4 2" stroke="white" strokeWidth="1.5" strokeLinecap="round"/></svg>
    ),
  },
];

const RECENT_KEY  = "orderlens_recent_queries";
const SAVED_KEY   = "orderlens_saved_insights";
const SESSIONS_KEY = "orderlens_chat_sessions";
const MONTH_ABBR = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

function monthLabel(ym) {
  const m = parseInt((ym || "").slice(5, 7), 10);
  return m >= 1 && m <= 12 ? MONTH_ABBR[m - 1] : ym;
}

function abbrCurrency(v) {
  const n = Math.abs(v);
  const sign = v < 0 ? "-" : "";
  if (n >= 1e9) return sign + "$" + (n/1e9).toFixed(1) + "B";
  if (n >= 1e6) return sign + "$" + (n/1e6).toFixed(1) + "M";
  if (n >= 1e3) return sign + "$" + (n/1e3).toFixed(1) + "K";
  return sign + "$" + n.toFixed(0);
}

function parseThreeSections(text) {
  if (!text) return { desc: null, pres: null, pred: null };
  const di = text.search(/\b(?:\d+\.?\s+)?\*{0,2}descriptive\*{0,2}(?:\s*[-:])?/i);
  const pi = text.search(/\b(?:\d+\.?\s+)?\*{0,2}prescriptive\*{0,2}(?:\s*[-:])?/i);
  const ri = text.search(/\b(?:\d+\.?\s+)?\*{0,2}predictive\*{0,2}(?:\s*[-:])?/i);
  const idxs = [["desc", di], ["pres", pi], ["pred", ri]].filter(function(p){ return p[1] >= 0; }).sort(function(a,b){ return a[1]-b[1]; });
  if (idxs.length === 0) return { desc: text, pres: null, pred: null };
  const out = { desc: null, pres: null, pred: null };
  idxs.forEach(function(pair, idx) {
    const key = pair[0], start = pair[1];
    const matchEnd = text.slice(start).search(/[-:]/);
    const contentStart = matchEnd >= 0 ? start + matchEnd + 1 : start;
    const end = idx + 1 < idxs.length ? idxs[idx + 1][1] : text.length;
    out[key] = text.slice(contentStart, end).trim().replace(/^\*+/, "").trim();
  });
  return out;
}

function stripBold(s) {
  return (s || "").replace(/\*\*(.+?)\*\*/g, "$1");
}

function renderMultiline(text) {
  if (!text) return null;
  const lines = stripBold(text).split("\n");
  return lines.map(function(line, i) {
    return <React.Fragment key={i}>{line}{i < lines.length - 1 && <br />}</React.Fragment>;
  });
}

const TODAY = new Date().toISOString().slice(0, 10);
const YEAR_START = TODAY.slice(0,4) + "-01-01";

const OUT_OF_DOMAIN_MSG = "Hello! I am Orderlens Assistant. I can help you with Sales & Operation data insights, " +
  "Revenue information, Dealer analysis, Product Perfomance, order status, dashboard metrics, " +
  "and related business data. Please ask a Orderlens or dashboard-related question.";

const NON_PROC_PATTERNS = [
  /^(hi|hello|hey|howdy|hiya|yo)\b/i,
  /^good\s*(morning|afternoon|evening|night|day)\b/i,
  /^how are you/i, /^how('s| is) (it going|everything|life|your day)/i,
  /^who are you/i, /^what (are|is) you\b/i,
  /^tell me (a joke|something funny|a story)/i,
  /^(crack|tell).*(joke|funny)/i,
  /^what('s| is) (the )?weather/i,
  /^what('s| is) (your )?(name|favorite|hobby|age)/i,
  /^what (do|can) you do\??$/i,
  /^(thanks|thank you|thx|ty)\b/i,
  /^(bye|goodbye|see you|cya|ttyl)\b/i,
  /^are you (a |an )?(ai|bot|robot|human|person|machine)\??$/i,
  /^capital of\b/i,
  /^who (invented|discovered|created|founded|built)\b/i,
  /^what is (the )?(meaning of life|ai|machine learning|blockchain|crypto)/i,
  /^(define|explain|what is)\s+(love|life|happiness|success|beauty)/i,
  /^(how|what).*(recipe|cook|bake|movie|music|song|book|game|sport|football|cricket)\b/i,
  /^(write|compose|create)\s+(a |an )?(poem|story|song|joke|essay)\b/i,
  /^(translate|convert)\s+\w+\s+to\b/i,
  /^what('s| is) (today's )?(date|time|day)\b/i,
  /^\d+\s*[\+\-\*\/]\s*\d+/,
];

function isOutOfDomain(question) {
  const q = (question || "").trim();
  if (!q) return false;
  return NON_PROC_PATTERNS.some(function(re){ return re.test(q); });
}

export default function Genie() {
  const [messages, setMessages]         = useState([]);
  const [selectedTile, setSelectedTile] = useState(null);
  const [lastResponse, setLastResponse] = useState(null);
  const [quickData, setQuickData]       = useState(null); // { monthly: [...], dealers: [...], metrics: {...}, anomaly }
  const [input, setInput]               = useState("");
  const [loading, setLoading]           = useState(false);
  const [showChats, setShowChats]       = useState(false);

  const [recentQueries, setRecentQueries] = useState(function() {
    try { return JSON.parse(localStorage.getItem(RECENT_KEY) || "[]"); } catch (e) { return []; }
  });
  const [savedInsights, setSavedInsights] = useState(function() {
    try { return JSON.parse(localStorage.getItem(SAVED_KEY) || "[]"); } catch (e) { return []; }
  });
  const [sessions, setSessions] = useState(function() {
    try { return JSON.parse(localStorage.getItem(SESSIONS_KEY) || "[]"); } catch (e) { return []; }
  });

  const scrollRef = useRef(null);

  useEffect(function() {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading]);

  function persistSession(msgs) {
    if (msgs.length === 0) return;
    const label = "Chat on " + new Date().toLocaleString();
    const updated = [{ id: Date.now(), label: label, messages: msgs, turns: msgs.length, ts: Date.now() }].concat(sessions).slice(0, 20);
    setSessions(updated);
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(updated));
  }

  function saveRecent(q) {
    const updated = [q].concat(recentQueries.filter(function(x){ return x !== q; })).slice(0, 10);
    setRecentQueries(updated);
    localStorage.setItem(RECENT_KEY, JSON.stringify(updated));
  }

  function saveInsight(q) {
    if (!q) return;
    const updated = [{ title: q.slice(0, 80), question: q, saved: new Date().toLocaleString() }]
      .concat(savedInsights.filter(function(x){ return x.question !== q; })).slice(0, 20);
    setSavedInsights(updated);
    localStorage.setItem(SAVED_KEY, JSON.stringify(updated));
  }

  async function runQueryForContext() {
    try {
      const results = await runQuery(
        "SELECT DEALER_NAME, PRODUCT_NAME, ORDER_STATUS, TOTAL_AMOUNT, QUANTITY, EFFECTIVE_DATE FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' ORDER BY EFFECTIVE_DATE DESC LIMIT 50"
      );
      return results.map(function(r){ return Object.values(r).join(", "); }).join("\n");
    } catch (e) { return ""; }
  }

  // Build the Key-Insights metrics + monthly trend + top dealers, mirroring Streamlit's run_quick_analysis("revenue_overview")
  // Revenue Overview: monthly trend + top dealers + KPI tiles + anomaly
  async function buildRevenueOverview() {
    const [monthly, dealers] = await Promise.all([
      fetchMonthlyRevenue(YEAR_START, TODAY, ""),
      fetchRevByDealer(YEAR_START, TODAY, ""),
    ]);
    const monthlySorted = [...monthly].sort((a, b) => (a.MONTH || "").localeCompare(b.MONTH || ""));
    const totalYTD = monthlySorted.reduce((s, r) => s + (+(r.REVENUE_M || 0) * 1e6), 0);
    const curM = monthlySorted.length ? +(monthlySorted[monthlySorted.length - 1].REVENUE_M || 0) : 0;
    const prevM = monthlySorted.length > 1 ? +(monthlySorted[monthlySorted.length - 2].REVENUE_M || 0) : 0;
    const momPct = prevM ? ((curM - prevM) / prevM) * 100 : 0;

    const dealersSorted = [...dealers].sort((a, b) => (+(b.REVENUE_M || 0)) - (+(a.REVENUE_M || 0)));
    const totalDealerRev = dealersSorted.reduce((s, r) => s + (+(r.REVENUE_M || 0)), 0);
    const top5Rev = dealersSorted.slice(0, 5).reduce((s, r) => s + (+(r.REVENUE_M || 0)), 0);
    const top5Pct = totalDealerRev ? Math.round((top5Rev / totalDealerRev) * 100) : 0;

    let anomaly = null;
    for (let i = 1; i < monthlySorted.length; i++) {
      const prev = +(monthlySorted[i - 1].REVENUE_M || 0);
      const cur = +(monthlySorted[i].REVENUE_M || 0);
      if (prev > 0 && (cur - prev) / prev > 0.20) {
        const pct = Math.round(((cur - prev) / prev) * 100);
        const topDealer = dealersSorted[0];
        anomaly = `${monthlySorted[i].MONTH} revenue spiked by ${pct}% vs prior month` +
          (topDealer ? `, primarily driven by ${topDealer.DEALER_NAME || topDealer.dealer_name} (${abbrCurrency((+topDealer.REVENUE_M||0)*1e6)})` : "") + ".";
      }
    }

    return {
      kind: "revenue",
      metrics: { totalYTD, momPct, top5Pct, qoqPct: 0 },
      anomaly,
      lineChart: { title: "Monthly Revenue Trend", labels: monthlySorted.map(r => monthLabel(r.MONTH || "")), data: monthlySorted.map(r => +(r.REVENUE_M||0)*1e6) },
      barChart: { title: "Top Dealers by Revenue", labels: dealersSorted.slice(0,5).map(r => r.DEALER_NAME || r.dealer_name || ""), data: dealersSorted.slice(0,5).map(r => +(r.REVENUE_M||0)*1e6), formatFn: v => `${(v/1e6).toFixed(4)}M` },
    };
  }

  // Dealer Analysis: top dealers bar + dealer concentration
  async function buildDealerAnalysis() {
    const dealers = await fetchRevByDealer(YEAR_START, TODAY, "");
    const dealersSorted = [...dealers].sort((a, b) => (+(b.REVENUE_M || 0)) - (+(a.REVENUE_M || 0)));
    const total = dealersSorted.reduce((s, r) => s + (+(r.REVENUE_M || 0)), 0);
    const top5Rev = dealersSorted.slice(0, 5).reduce((s, r) => s + (+(r.REVENUE_M || 0)), 0);
    const top5Pct = total ? Math.round((top5Rev / total) * 100) : 0;
    const topDealer = dealersSorted[0];
    const topPct = total && topDealer ? Math.round((+(topDealer.REVENUE_M||0) / total) * 100) : 0;

    return {
      kind: "dealer",
      metrics: { totalDealers: dealersSorted.length, top5Pct, topDealerName: topDealer ? (topDealer.DEALER_NAME||topDealer.dealer_name) : "", topPct },
      anomaly: topPct > 30 ? `${topDealer.DEALER_NAME || topDealer.dealer_name} accounts for ${topPct}% of total revenue, indicating high dealer concentration risk.` : null,
      barChart: { title: "Top Dealers by Revenue", labels: dealersSorted.slice(0,10).map(r => r.DEALER_NAME || r.dealer_name || ""), data: dealersSorted.slice(0,10).map(r => +(r.REVENUE_M||0)*1e6), formatFn: v => `${(v/1e6).toFixed(2)}M` },
    };
  }

  // Product Performance: sales by product type
  async function buildProductPerformance() {
    const sales = await fetchSalesByProductType(YEAR_START, TODAY, "");
    const sorted = [...sales].sort((a, b) => (+(b.TOTAL_SALES || 0)) - (+(a.TOTAL_SALES || 0)));
    const total = sorted.reduce((s, r) => s + (+(r.TOTAL_SALES || 0)), 0);
    const top = sorted[0];
    return {
      kind: "product",
      metrics: { totalRevenue: total, topType: top ? top.PRODUCT_TYPE : "", typeCount: sorted.length },
      anomaly: null,
      barChart: { title: "Sales by Product Type", labels: sorted.map(r => r.PRODUCT_TYPE || ""), data: sorted.map(r => +(r.TOTAL_SALES||0)), formatFn: v => `$${(v/1e6).toFixed(1)}M` },
    };
  }

  // Order Status: distribution bar
  async function buildOrderStatus() {
    const statuses = await fetchOrderStatus(YEAR_START, TODAY, "");
    const sorted = [...statuses].sort((a, b) => (+(b.ORDER_COUNT || 0)) - (+(a.ORDER_COUNT || 0)));
    const total = sorted.reduce((s, r) => s + (+(r.ORDER_COUNT || 0)), 0);
    return {
      kind: "order",
      metrics: { totalOrders: total, statusCount: sorted.length },
      anomaly: null,
      barChart: { title: "Order Status Distribution", labels: sorted.map(r => r.ORDER_STATUS || ""), data: sorted.map(r => +(r.ORDER_COUNT||0)), formatFn: v => v.toLocaleString() },
    };
  }

  function inferAnalysisKind(question, tileKey) {
    if (tileKey) return tileKey;
    const q = (question || "").toLowerCase();
    if (q.includes("dealer") && (q.includes("concentration") || q.includes("depend"))) return "dealer_analysis";
    if (q.includes("product") || q.includes("quantity")) return "product_performance";
    if (q.includes("order status") || q.includes("fulfillment") || q.includes("bottleneck")) return "order_status";
    if (q.includes("revenue") || q.includes("dealers")) return "revenue_overview";
    return null;
  }

  async function buildChartsForKind(kind) {
    try {
      if (kind === "revenue_overview") return await buildRevenueOverview();
      if (kind === "dealer_analysis")  return await buildDealerAnalysis();
      if (kind === "product_performance") return await buildProductPerformance();
      if (kind === "order_status") return await buildOrderStatus();
      return null;
    } catch (e) {
      return null;
    }
  }

  async function ask(question, tileKey) {
    if (!question || !question.trim()) return;
    setSelectedTile(tileKey || null);
    saveRecent(question);
    setMessages(function(m){ return m.concat([{ role: "user", content: question }]); });

    if (isOutOfDomain(question)) {
      setQuickData(null);
      setLastResponse(null);
      setMessages(function(m){ return m.concat([{ role: "ai", content: OUT_OF_DOMAIN_MSG, full: true }]); });
      return;
    }

    setLoading(true);
    setQuickData(null);
    try {
      const ctx = await runQueryForContext();
      const answerPromise = generateGenieAnswer(question, ctx);
      const kind = inferAnalysisKind(question, tileKey);
      const quickPromise = kind ? buildChartsForKind(kind) : Promise.resolve(null);
      const [answer, qd] = await Promise.all([answerPromise, quickPromise]);

      // Backstop: if the AI itself decided this was out-of-domain, show the plain message, no charts/detail panel
      if (answer && answer.includes("Orderlens Assistant") && answer.includes("dashboard-related question")) {
        setLastResponse(null);
        setQuickData(null);
        setMessages(function(m){ return m.concat([{ role: "ai", content: answer.trim(), full: true }]); });
        setLoading(false);
        return;
      }

      const parsed = parseThreeSections(answer);
      setLastResponse({ raw: answer, parsed: parsed, question: question, tileKey: tileKey || null });
      setQuickData(qd);
      setMessages(function(m){ return m.concat([{ role: "ai", content: answer }]); });
    } catch (e) {
      setMessages(function(m){ return m.concat([{ role: "ai", content: "Error: " + e.message }]); });
    }
    setLoading(false);
  }

  function handleSend() {
    const q = input.trim();
    if (!q) return;
    setInput("");
    ask(q);
  }

  function clearChat() {
    persistSession(messages);
    setMessages([]);
    setSelectedTile(null);
    setLastResponse(null);
    setQuickData(null);
  }

  function exportMD() {
    const md = "# OrderLens Genie\n\n*Exported " + new Date().toLocaleString() + "*\n\n---\n\n" +
      messages.map(function(m){ return "**" + (m.role === "user" ? "You" : "Genie") + ":** " + m.content; }).join("\n\n");
    const blob = new Blob([md], { type: "text/markdown" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
    a.download = "genie_chat_" + Date.now() + ".md"; a.click();
  }

  async function summarizeChat() {
    if (messages.length < 2) return;
    setLoading(true);
    const transcript = messages.map(function(m){ return (m.role === "user" ? "User: " : "Genie: ") + stripBold(m.content); }).join("\n");
    const prompt = "Summarize the following conversation between a user and an analytics assistant in 3-5 concise bullet points, highlighting the key questions asked and the main insights given:\n\n" + transcript;
    try {
      const summary = await generateGenieAnswer(prompt, "");
      setMessages(function(m){ return m.concat([{ role: "ai", content: "**Summary**\n" + summary, full: true }]); });
    } catch (e) {
      setMessages(function(m){ return m.concat([{ role: "ai", content: "Error generating summary: " + e.message }]); });
    }
    setLoading(false);
  }

  function resumeSession(s) {
    setMessages(s.messages);
    setShowChats(false);
  }

  return (
    <div className="block-container">
      <div style={{ marginBottom: 8 }}>
        <h1 style={{ fontSize: 28, fontWeight: 900, color: "#1a1a1a", margin: "0 0 4px 0" }}>Welcome to OrderLens Genie</h1>
        <p style={{ fontSize: 16, color: "#64748b", margin: 0 }}>Let Genie run one of these quick analyses for you</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginTop: 16, marginBottom: 16 }}>
        {QUICK_ANALYSES.map(function(tile) {
          const isSel = selectedTile === tile.key;
          return (
            <div key={tile.key}>
              <div className={"genie-tile-card" + (isSel ? " selected" : "")}>
                <div className="genie-tile-icon">{tile.icon}</div>
                <div className="genie-tile-title">{tile.title}</div>
                <div className="genie-tile-desc">{tile.desc}</div>
              </div>
              <button className="genie-tile-select-btn" onClick={function(){ ask(tile.question, tile.key); }}>
                Ask Genie
              </button>
            </div>
          );
        })}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "0.35fr 0.65fr", gap: 16, alignItems: "start" }}>

        <div>
          <button className="btn btn-primary" style={{ width: "100%", marginBottom: 14 }}
            onClick={function(){ setMessages([]); setLastResponse(null); setQuickData(null); setSelectedTile(null); setShowChats(false); }}>
            + New Conversation
          </button>

          <Expander title={"Previous Chats (" + sessions.length + ")"}>
            {sessions.length === 0
              ? <div style={{ fontSize: 12, color: "#94a3b8", textAlign: "center", padding: "8px 0" }}>No previous chats found.</div>
              : sessions.map(function(s) {
                return (
                  <div key={s.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center",
                    background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 10, padding: "9px 12px", marginBottom: 6 }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>{s.label}</div>
                      <div style={{ fontSize: 11, color: "#64748b", marginTop: 2 }}>{s.turns} messages</div>
                    </div>
                    <button className="btn btn-primary" onClick={function(){ resumeSession(s); }}>Resume</button>
                  </div>
                );
              })
            }
          </Expander>

          <div style={{ fontSize: 15, fontWeight: 800, color: "#0f172a", margin: "14px 0 10px" }}>Analysis Library</div>

          <div className="card" style={{ marginBottom: 4 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: "#64748b", marginBottom: 6 }}>Recent analysis</div>
            {recentQueries.length === 0
              ? <div style={{ fontSize: 12, color: "#94a3b8", fontStyle: "italic", padding: "4px 0" }}>Run analyses to see them here.</div>
              : recentQueries.slice(0, 3).map(function(q, i) {
                return (
                  <button key={i} className="btn btn-secondary" style={{ width: "100%", textAlign: "left", marginBottom: 4 }}
                    onClick={function(){ ask(q); }}>
                    {q.length > 50 ? q.slice(0, 50) + "…" : q}
                  </button>
                );
              })
            }
          </div>

          <Expander title="Frequently asked by you">
            {recentQueries.length === 0
              ? <div style={{ fontSize: 12, color: "#94a3b8", textAlign: "center", padding: "8px 0" }}>No questions yet.</div>
              : recentQueries.slice(0, 5).map(function(q, i) {
                return (
                  <button key={i} className="btn btn-secondary" style={{ width: "100%", textAlign: "left", marginBottom: 4 }}
                    onClick={function(){ ask(q); }}>
                    {q.length > 55 ? q.slice(0, 55) + "…" : q}
                  </button>
                );
              })
            }
          </Expander>

          <Expander title="Most frequent (all)">
            <div style={{ fontSize: 12, color: "#94a3b8", textAlign: "center", padding: "8px 0" }}>
              Ask questions to see most frequent across all users.
            </div>
          </Expander>
        </div>

        <div className="card">
          <div className="genie-hdr-row">
            <div className="genie-hdr-title">{messages.length === 0 ? "New Chat" : "Chat"}</div>
            <button className="genie-hdr-btn" disabled={messages.length < 2} onClick={summarizeChat}>Summarize</button>
            <button className="genie-hdr-btn" disabled={messages.length === 0} onClick={exportMD}>Export MD</button>
            <button className="genie-hdr-btn" disabled={messages.length === 0} onClick={clearChat}>Clear</button>
          </div>

          <div className="chat-scroll" ref={scrollRef}>
            {messages.length === 0 ? (
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", textAlign: "center", padding: "60px 20px" }}>
                <div style={{ fontSize: 32, marginBottom: 16, color: "#94a3b8" }}>•</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: "#1a1a1a", marginBottom: 8 }}>Start a Conversation</div>
                <div style={{ fontSize: 14, color: "#64748b", maxWidth: 400 }}>
                  Ask questions about your Sales &amp; Operations data, or select a quick analysis above.
                </div>
              </div>
            ) : (
              messages.map(function(msg, i) {
                return msg.role === "user" ? (
                  <div key={i} className="g-user">
                    <div className="g-user-inner">
                      <div className="g-user-lbl">You</div>
                      {msg.content}
                    </div>
                  </div>
                ) : (
                  <div key={i} className="g-ai">
                    <div className="g-ai-inner">
                      <div className="g-ai-lbl">Genie</div>
                      {msg.full ? renderMultiline(msg.content) : stripBold(msg.content).split(".")[0] + "."}
                    </div>
                  </div>
                );
              })
            )}
            {loading && (
              <div className="typing-indicator">
                <span className="typing-dot" /><span className="typing-dot" /><span className="typing-dot" />
              </div>
            )}

            {lastResponse && !loading && (
              <div style={{ marginTop: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <button className="btn btn-secondary" onClick={function(){ setLastResponse(null); setQuickData(null); setSelectedTile(null); }}>Reset</button>
                  <button className="btn btn-secondary" onClick={function(){ saveInsight(lastResponse.question); }}>Save</button>
                </div>
                <div style={{ margin: "8px 0 12px 0" }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#64748b" }}>Your question</div>
                  <div style={{ fontSize: 15, fontWeight: 800, color: "#1a1a1a" }}>
                    {QUICK_ANALYSES.find(t => t.key === lastResponse.tileKey)?.title || lastResponse.question}
                  </div>
                </div>

                {/* Key Insights tile grid — adapts per analysis kind */}
                {quickData && quickData.kind === "revenue" && (
                  <div className="insights-banner">
                    <div className="insights-banner-title">Key Insights</div>
                    <div className="insights-grid">
                      <div className="insight-tile">
                        <div className="insight-tile-label">Total Revenue (YTD)</div>
                        <div className="insight-tile-value">{abbrCurrency(quickData.metrics.totalYTD)}</div>
                      </div>
                      <div className="insight-tile">
                        <div className="insight-tile-label">MoM Change</div>
                        <div className="insight-tile-value" style={{ color: quickData.metrics.momPct >= 0 ? "#059669" : "#dc2626" }}>
                          {quickData.metrics.momPct >= 0 ? "+" : ""}{quickData.metrics.momPct.toFixed(1)}%
                        </div>
                      </div>
                      <div className="insight-tile">
                        <div className="insight-tile-label">Top 5 Dealers</div>
                        <div className="insight-tile-value">{quickData.metrics.top5Pct}%</div>
                      </div>
                      <div className="insight-tile">
                        <div className="insight-tile-label">QoQ Change</div>
                        <div className="insight-tile-value">+{quickData.metrics.qoqPct.toFixed(1)}%</div>
                      </div>
                    </div>
                  </div>
                )}

                {quickData && quickData.kind === "dealer" && (
                  <div className="insights-banner">
                    <div className="insights-banner-title">Key Insights</div>
                    <div className="insights-grid">
                      <div className="insight-tile">
                        <div className="insight-tile-label">Total Dealers</div>
                        <div className="insight-tile-value">{quickData.metrics.totalDealers}</div>
                      </div>
                      <div className="insight-tile">
                        <div className="insight-tile-label">Top 5 Dealers Share</div>
                        <div className="insight-tile-value">{quickData.metrics.top5Pct}%</div>
                      </div>
                      <div className="insight-tile">
                        <div className="insight-tile-label">Top Dealer</div>
                        <div className="insight-tile-value" style={{ fontSize: 15 }}>{quickData.metrics.topDealerName}</div>
                      </div>
                      <div className="insight-tile">
                        <div className="insight-tile-label">Top Dealer Share</div>
                        <div className="insight-tile-value">{quickData.metrics.topPct}%</div>
                      </div>
                    </div>
                  </div>
                )}

                {quickData && quickData.kind === "product" && (
                  <div className="insights-banner">
                    <div className="insights-banner-title">Key Insights</div>
                    <div className="insights-grid">
                      <div className="insight-tile">
                        <div className="insight-tile-label">Total Sales</div>
                        <div className="insight-tile-value">{abbrCurrency(quickData.metrics.totalRevenue)}</div>
                      </div>
                      <div className="insight-tile">
                        <div className="insight-tile-label">Top Product Type</div>
                        <div className="insight-tile-value" style={{ fontSize: 16 }}>{quickData.metrics.topType}</div>
                      </div>
                      <div className="insight-tile">
                        <div className="insight-tile-label">Product Types</div>
                        <div className="insight-tile-value">{quickData.metrics.typeCount}</div>
                      </div>
                    </div>
                  </div>
                )}

                {quickData && quickData.kind === "order" && (
                  <div className="insights-banner">
                    <div className="insights-banner-title">Key Insights</div>
                    <div className="insights-grid">
                      <div className="insight-tile">
                        <div className="insight-tile-label">Total Orders</div>
                        <div className="insight-tile-value">{quickData.metrics.totalOrders.toLocaleString()}</div>
                      </div>
                      <div className="insight-tile">
                        <div className="insight-tile-label">Status Categories</div>
                        <div className="insight-tile-value">{quickData.metrics.statusCount}</div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Anomaly Detected banner */}
                {quickData && quickData.anomaly && (
                  <div className="anomaly-banner">
                    <span style={{ fontSize: 18 }}>⚠️</span>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 800, color: "#0f172a", marginBottom: 2 }}>Anomaly Detected</div>
                      <div style={{ fontSize: 13, color: "#475569" }}>{quickData.anomaly}</div>
                    </div>
                  </div>
                )}

                {/* Line chart (revenue trend) */}
                {quickData && quickData.lineChart && (
                  <div style={{ marginBottom: 16 }}>
                    <div style={{ fontWeight: 800, fontSize: 15, marginBottom: 8, color: "#0f172a" }}>Monthly Trend</div>
                    <div className="card">
                      <div className="chart-subtitle">{quickData.lineChart.title}</div>
                      <LineAreaChart
                        labels={quickData.lineChart.labels}
                        data={quickData.lineChart.data}
                        color="#3B82F6" fillColor="rgba(59,130,246,0.12)" height={220}
                        formatFn={v => v >= 1e6 ? `${(v/1e6).toFixed(0)}M` : v}
                      />
                    </div>
                  </div>
                )}

                {/* Bar chart (dealers / products / order status) */}
                {quickData && quickData.barChart && (
                  <div style={{ marginBottom: 16 }}>
                    <div style={{ fontWeight: 800, fontSize: 15, marginBottom: 8, color: "#0f172a" }}>{quickData.barChart.title}</div>
                    <div className="card">
                      <HBarChart
                        labels={quickData.barChart.labels}
                        data={quickData.barChart.data}
                        color="#3B5BDB" height={Math.max(140, quickData.barChart.labels.length * 36)}
                        formatFn={quickData.barChart.formatFn}
                      />
                    </div>
                  </div>
                )}

                {lastResponse.parsed.desc && (
                  <div className="descriptive-card">
                    <div className="descriptive-card-title">Descriptive — What the data shows</div>
                    <div style={{ color: "#0f172a", fontSize: 14, lineHeight: 1.6 }}>
                      {renderMultiline(lastResponse.parsed.desc)}
                    </div>
                  </div>
                )}

                {lastResponse.parsed.pres && (
                  <Expander title="Prescriptive — Recommendations & Actions">
                    <div className="prescriptive-content">{renderMultiline(lastResponse.parsed.pres)}</div>
                  </Expander>
                )}

                {lastResponse.parsed.pred && (
                  <Expander title="Predictive — 30–90 Day Forecast">
                    <div className="predictive-card">{renderMultiline(lastResponse.parsed.pred)}</div>
                  </Expander>
                )}
              </div>
            )}
          </div>

          <div className="genie-input-row">
            <input
              className="genie-input"
              placeholder="Ask about Sales & Operations data..."
              value={input}
              onChange={function(e){ setInput(e.target.value); }}
              onKeyDown={function(e){ if (e.key === "Enter") handleSend(); }}
            />
            <button className="genie-send-btn" onClick={handleSend}>Send →</button>
          </div>
        </div>
      </div>
    </div>
  );
}
