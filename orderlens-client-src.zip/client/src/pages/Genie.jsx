import React, { useState, useRef, useEffect } from "react";
import { generateGenieAnswer, runQuery, fetchMonthlyRevenue, fetchRevByDealer } from "../services/api";
import Expander from "../components/Expander";
import { LineAreaChart, HBarChart } from "../components/Charts";

const QUICK_ANALYSES = [
  {
    key: "revenue_overview", title: "Revenue Overview",
    desc: "Track total revenue, monthly trends and major changes",
    question: "Show me total revenue YTD, monthly trends, and top 5 dealers",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="4" y="14" width="4" height="6" rx="1" fill="white"/><rect x="10" y="10" width="4" height="10" rx="1" fill="white"/><rect x="16" y="6" width="4" height="14" rx="1" fill="white"/></svg>
    ),
  },
  {
    key: "dealer_analysis", title: "Dealer Analysis",
    desc: "Understand dealer-wise revenue, concentration, and dependency",
    question: "Analyze dealer concentration and dependency",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="9" cy="7" r="3" stroke="white" strokeWidth="1.5" fill="none"/><path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2" stroke="white" strokeWidth="1.5" fill="none"/><rect x="14" y="8" width="8" height="2" rx="0.5" fill="white"/><rect x="14" y="12" width="6" height="2" rx="0.5" fill="white"/><rect x="14" y="16" width="8" height="2" rx="0.5" fill="white"/></svg>
    ),
  },
  {
    key: "product_performance", title: "Product Performance",
    desc: "Identify top products, revenue, and quantity trends",
    question: "Show top products by revenue and quantity",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M7 3h8l5 5v11a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z" stroke="white" strokeWidth="1.5" fill="none"/><line x1="7" y1="9" x2="17" y2="9" stroke="white" strokeWidth="1.5"/><line x1="7" y1="13" x2="15" y2="13" stroke="white" strokeWidth="1.5"/></svg>
    ),
  },
  {
    key: "order_status", title: "Order Status",
    desc: "See order status distribution, fulfillment, and bottlenecks",
    question: "Show order status distribution by count and revenue",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="white" strokeWidth="1.5" fill="none"/><path d="M12 6v6l4 2" stroke="white" strokeWidth="1.5" strokeLinecap="round"/></svg>
    ),
  },
];

const RECENT_KEY  = "orderlens_recent_queries";
const SAVED_KEY   = "orderlens_saved_insights";
const SESSIONS_KEY = "orderlens_chat_sessions";
const MONTH_ABBR = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

function monthLabel(ym) {
  const m = parseInt((ym || "").slice(5, 7), 10);
  return m >= 1 && m <= 12 ? MONTH_ABBR[m - 1] : ym;
}

function abbrCurrency(v) {
  const n = Math.abs(v);
  const sign = v < 0 ? "-" : "";
  if (n >= 1e9) return sign + "$" + (n/1e9).toFixed(1) + "B";
  if (n >= 1e6) return sign + "$" + (n/1e6).toFixed(1) + "M";
  if (n >= 1e3) return sign + "$" + (n/1e3).toFixed(1) + "K";
  return sign + "$" + n.toFixed(0);
}

function parseThreeSections(text) {
  if (!text) return { desc: null, pres: null, pred: null };
  const di = text.search(/\b(?:\d+\.?\s+)?\*{0,2}descriptive\*{0,2}(?:\s*[-:])?/i);
  const pi = text.search(/\b(?:\d+\.?\s+)?\*{0,2}prescriptive\*{0,2}(?:\s*[-:])?/i);
  const ri = text.search(/\b(?:\d+\.?\s+)?\*{0,2}predictive\*{0,2}(?:\s*[-:])?/i);
  const idxs = [["desc", di], ["pres", pi], ["pred", ri]].filter(function(p){ return p[1] >= 0; }).sort(function(a,b){ return a[1]-b[1]; });
  if (idxs.length === 0) return { desc: text, pres: null, pred: null };
  const out = { desc: null, pres: null, pred: null };
  idxs.forEach(function(pair, idx) {
    const key = pair[0], start = pair[1];
    const matchEnd = text.slice(start).search(/[-:]/);
    const contentStart = matchEnd >= 0 ? start + matchEnd + 1 : start;
    const end = idx + 1 < idxs.length ? idxs[idx + 1][1] : text.length;
    out[key] = text.slice(contentStart, end).trim().replace(/^\*+/, "").trim();
  });
  return out;
}

function stripBold(s) {
  return (s || "").replace(/\*\*(.+?)\*\*/g, "$1");
}

function renderMultiline(text) {
  if (!text) return null;
  const lines = stripBold(text).split("\n");
  return lines.map(function(line, i) {
    return <React.Fragment key={i}>{line}{i < lines.length - 1 && <br />}</React.Fragment>;
  });
}

const TODAY = new Date().toISOString().slice(0, 10);
const YEAR_START = TODAY.slice(0,4) + "-01-01";

export default function Genie() {
  const [messages, setMessages]         = useState([]);
  const [selectedTile, setSelectedTile] = useState(null);
  const [lastResponse, setLastResponse] = useState(null);
  const [quickData, setQuickData]       = useState(null); // { monthly: [...], dealers: [...], metrics: {...}, anomaly }
  const [input, setInput]               = useState("");
  const [loading, setLoading]           = useState(false);
  const [showChats, setShowChats]       = useState(false);

  const [recentQueries, setRecentQueries] = useState(function() {
    try { return JSON.parse(localStorage.getItem(RECENT_KEY) || "[]"); } catch (e) { return []; }
  });
  const [savedInsights, setSavedInsights] = useState(function() {
    try { return JSON.parse(localStorage.getItem(SAVED_KEY) || "[]"); } catch (e) { return []; }
  });
  const [sessions, setSessions] = useState(function() {
    try { return JSON.parse(localStorage.getItem(SESSIONS_KEY) || "[]"); } catch (e) { return []; }
  });

  const scrollRef = useRef(null);

  useEffect(function() {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading]);

  function persistSession(msgs) {
    if (msgs.length === 0) return;
    const label = "Chat on " + new Date().toLocaleString();
    const updated = [{ id: Date.now(), label: label, messages: msgs, turns: msgs.length, ts: Date.now() }].concat(sessions).slice(0, 20);
    setSessions(updated);
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(updated));
  }

  function saveRecent(q) {
    const updated = [q].concat(recentQueries.filter(function(x){ return x !== q; })).slice(0, 10);
    setRecentQueries(updated);
    localStorage.setItem(RECENT_KEY, JSON.stringify(updated));
  }

  function saveInsight(q) {
    if (!q) return;
    const updated = [{ title: q.slice(0, 80), question: q, saved: new Date().toLocaleString() }]
      .concat(savedInsights.filter(function(x){ return x.question !== q; })).slice(0, 20);
    setSavedInsights(updated);
    localStorage.setItem(SAVED_KEY, JSON.stringify(updated));
  }

  async function runQueryForContext() {
    try {
      const results = await runQuery(
        "SELECT DEALER_NAME, PRODUCT_NAME, ORDER_STATUS, TOTAL_AMOUNT, QUANTITY, EFFECTIVE_DATE FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' ORDER BY EFFECTIVE_DATE DESC LIMIT 50"
      );
      return results.map(function(r){ return Object.values(r).join(", "); }).join("\n");
    } catch (e) { return ""; }
  }

  // Build the Key-Insights metrics + monthly trend + top dealers, mirroring Streamlit's run_quick_analysis("revenue_overview")
  async function buildQuickAnalysisData() {
    try {
      const [monthly, dealers] = await Promise.all([
        fetchMonthlyRevenue(YEAR_START, TODAY, ""),
        fetchRevByDealer(YEAR_START, TODAY, ""),
      ]);
      const monthlySorted = [...monthly].sort((a, b) => (a.MONTH || "").localeCompare(b.MONTH || ""));
      const totalYTD = monthlySorted.reduce((s, r) => s + (+(r.REVENUE_M || 0) * 1e6), 0);
      const curM = monthlySorted.length ? +(monthlySorted[monthlySorted.length - 1].REVENUE_M || 0) : 0;
      const prevM = monthlySorted.length > 1 ? +(monthlySorted[monthlySorted.length - 2].REVENUE_M || 0) : 0;
      const momPct = prevM ? ((curM - prevM) / prevM) * 100 : 0;

      const dealersSorted = [...dealers].sort((a, b) => (+(b.REVENUE_M || 0)) - (+(a.REVENUE_M || 0)));
      const totalDealerRev = dealersSorted.reduce((s, r) => s + (+(r.REVENUE_M || 0)), 0);
      const top5Rev = dealersSorted.slice(0, 5).reduce((s, r) => s + (+(r.REVENUE_M || 0)), 0);
      const top5Pct = totalDealerRev ? Math.round((top5Rev / totalDealerRev) * 100) : 0;

      // Detect biggest MoM spike for anomaly banner
      let anomaly = null;
      for (let i = 1; i < monthlySorted.length; i++) {
        const prev = +(monthlySorted[i - 1].REVENUE_M || 0);
        const cur = +(monthlySorted[i].REVENUE_M || 0);
        if (prev > 0 && (cur - prev) / prev > 0.20) {
          const pct = Math.round(((cur - prev) / prev) * 100);
          const topDealer = dealersSorted[0];
          anomaly = `${monthlySorted[i].MONTH} revenue spiked by ${pct}% vs prior month` +
            (topDealer ? `, primarily driven by ${topDealer.DEALER_NAME || topDealer.dealer_name} (${abbrCurrency((+topDealer.REVENUE_M||0)*1e6)})` : "") + ".";
        }
      }

      return {
        monthly: monthlySorted,
        dealers: dealersSorted.slice(0, 5),
        metrics: { totalYTD, momPct, top5Pct, qoqPct: 0 },
        anomaly,
      };
    } catch (e) {
      return null;
    }
  }

  async function ask(question, tileKey) {
    if (!question || !question.trim()) return;
    setLoading(true);
    setSelectedTile(tileKey || null);
    setQuickData(null);
    saveRecent(question);
    setMessages(function(m){ return m.concat([{ role: "user", content: question }]); });
    try {
      const ctx = await runQueryForContext();
      const answerPromise = generateGenieAnswer(question, ctx);
      const quickPromise = tileKey === "revenue_overview" ? buildQuickAnalysisData() : Promise.resolve(null);
      const [answer, qd] = await Promise.all([answerPromise, quickPromise]);
      const parsed = parseThreeSections(answer);
      setLastResponse({ raw: answer, parsed: parsed, question: question, tileKey: tileKey || null });
      setQuickData(qd);
      setMessages(function(m){ return m.concat([{ role: "ai", content: answer }]); });
    } catch (e) {
      setMessages(function(m){ return m.concat([{ role: "ai", content: "Error: " + e.message }]); });
    }
    setLoading(false);
  }

  function handleSend() {
    const q = input.trim();
    if (!q) return;
    setInput("");
    ask(q);
  }

  function clearChat() {
    persistSession(messages);
    setMessages([]);
    setSelectedTile(null);
    setLastResponse(null);
    setQuickData(null);
  }

  function exportMD() {
    const md = "# OrderLens Genie\n\n*Exported " + new Date().toLocaleString() + "*\n\n---\n\n" +
      messages.map(function(m){ return "**" + (m.role === "user" ? "You" : "Genie") + ":** " + m.content; }).join("\n\n");
    const blob = new Blob([md], { type: "text/markdown" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
    a.download = "genie_chat_" + Date.now() + ".md"; a.click();
  }

  function resumeSession(s) {
    setMessages(s.messages);
    setShowChats(false);
  }

  return (
    <div className="block-container">
      <div style={{ marginBottom: 8 }}>
        <h1 style={{ fontSize: 28, fontWeight: 900, color: "#1a1a1a", margin: "0 0 4px 0" }}>Welcome to OrderLens Genie</h1>
        <p style={{ fontSize: 16, color: "#64748b", margin: 0 }}>Let Genie run one of these quick analyses for you</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginTop: 16, marginBottom: 16 }}>
        {QUICK_ANALYSES.map(function(tile) {
          const isSel = selectedTile === tile.key;
          return (
            <div key={tile.key}>
              <div className={"genie-tile-card" + (isSel ? " selected" : "")}>
                <div className="genie-tile-icon">{tile.icon}</div>
                <div className="genie-tile-title">{tile.title}</div>
                <div className="genie-tile-desc">{tile.desc}</div>
              </div>
              <button className="genie-tile-select-btn" onClick={function(){ ask(tile.question, tile.key); }}>
                Ask Genie
              </button>
            </div>
          );
        })}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "0.35fr 0.65fr", gap: 16, alignItems: "start" }}>

        <div>
          <button className="btn btn-primary" style={{ width: "100%", marginBottom: 14 }}
            onClick={function(){ setMessages([]); setLastResponse(null); setQuickData(null); setSelectedTile(null); setShowChats(false); }}>
            + New Conversation
          </button>

          <Expander title={"Previous Chats (" + sessions.length + ")"}>
            {sessions.length === 0
              ? <div style={{ fontSize: 12, color: "#94a3b8", textAlign: "center", padding: "8px 0" }}>No previous chats found.</div>
              : sessions.map(function(s) {
                return (
                  <div key={s.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center",
                    background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 10, padding: "9px 12px", marginBottom: 6 }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>{s.label}</div>
                      <div style={{ fontSize: 11, color: "#64748b", marginTop: 2 }}>{s.turns} messages</div>
                    </div>
                    <button className="btn btn-primary" onClick={function(){ resumeSession(s); }}>Resume</button>
                  </div>
                );
              })
            }
          </Expander>

          <div style={{ fontSize: 15, fontWeight: 800, color: "#0f172a", margin: "14px 0 10px" }}>Analysis Library</div>

          <div className="card" style={{ marginBottom: 4 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: "#64748b", marginBottom: 6 }}>Recent analysis</div>
            {recentQueries.length === 0
              ? <div style={{ fontSize: 12, color: "#94a3b8", fontStyle: "italic", padding: "4px 0" }}>Run analyses to see them here.</div>
              : recentQueries.slice(0, 3).map(function(q, i) {
                return (
                  <button key={i} className="btn btn-secondary" style={{ width: "100%", textAlign: "left", marginBottom: 4 }}
                    onClick={function(){ ask(q); }}>
                    {q.length > 50 ? q.slice(0, 50) + "…" : q}
                  </button>
                );
              })
            }
          </div>

          <Expander title="Frequently asked by you">
            {recentQueries.length === 0
              ? <div style={{ fontSize: 12, color: "#94a3b8", textAlign: "center", padding: "8px 0" }}>No questions yet.</div>
              : recentQueries.slice(0, 5).map(function(q, i) {
                return (
                  <button key={i} className="btn btn-secondary" style={{ width: "100%", textAlign: "left", marginBottom: 4 }}
                    onClick={function(){ ask(q); }}>
                    {q.length > 55 ? q.slice(0, 55) + "…" : q}
                  </button>
                );
              })
            }
          </Expander>

          <Expander title="Most frequent (all)">
            <div style={{ fontSize: 12, color: "#94a3b8", textAlign: "center", padding: "8px 0" }}>
              Ask questions to see most frequent across all users.
            </div>
          </Expander>
        </div>

        <div className="card">
          <div className="genie-hdr-row">
            <div className="genie-hdr-title">{messages.length === 0 ? "New Chat" : "Chat"}</div>
            <button className="genie-hdr-btn" disabled={messages.length < 2}>Summarize</button>
            <button className="genie-hdr-btn" disabled={messages.length === 0} onClick={exportMD}>Export MD</button>
            <button className="genie-hdr-btn" disabled={messages.length === 0} onClick={clearChat}>Clear</button>
          </div>

          <div className="chat-scroll" ref={scrollRef}>
            {messages.length === 0 ? (
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", textAlign: "center", padding: "60px 20px" }}>
                <div style={{ fontSize: 32, marginBottom: 16, color: "#94a3b8" }}>•</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: "#1a1a1a", marginBottom: 8 }}>Start a Conversation</div>
                <div style={{ fontSize: 14, color: "#64748b", maxWidth: 400 }}>
                  Ask questions about your Sales &amp; Operations data, or select a quick analysis above.
                </div>
              </div>
            ) : (
              messages.map(function(msg, i) {
                return msg.role === "user" ? (
                  <div key={i} className="g-user">
                    <div className="g-user-inner">
                      <div className="g-user-lbl">You</div>
                      {msg.content}
                    </div>
                  </div>
                ) : (
                  <div key={i} className="g-ai">
                    <div className="g-ai-inner">
                      <div className="g-ai-lbl">Genie</div>
                      {stripBold(msg.content).split(".")[0]}.
                    </div>
                  </div>
                );
              })
            )}
            {loading && (
              <div className="typing-indicator">
                <span className="typing-dot" /><span className="typing-dot" /><span className="typing-dot" />
              </div>
            )}

            {lastResponse && !loading && (
              <div style={{ marginTop: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <button className="btn btn-secondary" onClick={function(){ setLastResponse(null); setQuickData(null); setSelectedTile(null); }}>Reset</button>
                  <button className="btn btn-secondary" onClick={function(){ saveInsight(lastResponse.question); }}>Save</button>
                </div>
                <div style={{ margin: "8px 0 12px 0" }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#64748b" }}>Your question</div>
                  <div style={{ fontSize: 15, fontWeight: 800, color: "#1a1a1a" }}>
                    {QUICK_ANALYSES.find(t => t.key === lastResponse.tileKey)?.title || lastResponse.question}
                  </div>
                </div>

                {/* Key Insights tile grid — only for Revenue Overview quick analysis */}
                {quickData && quickData.metrics && (
                  <div className="insights-banner">
                    <div className="insights-banner-title">Key Insights</div>
                    <div className="insights-grid">
                      <div className="insight-tile">
                        <div className="insight-tile-label">Total Revenue (YTD)</div>
                        <div className="insight-tile-value">{abbrCurrency(quickData.metrics.totalYTD)}</div>
                      </div>
                      <div className="insight-tile">
                        <div className="insight-tile-label">MoM Change</div>
                        <div className="insight-tile-value" style={{ color: quickData.metrics.momPct >= 0 ? "#059669" : "#dc2626" }}>
                          {quickData.metrics.momPct >= 0 ? "+" : ""}{quickData.metrics.momPct.toFixed(1)}%
                        </div>
                      </div>
                      <div className="insight-tile">
                        <div className="insight-tile-label">Top 5 Dealers</div>
                        <div className="insight-tile-value">{quickData.metrics.top5Pct}%</div>
                      </div>
                      <div className="insight-tile">
                        <div className="insight-tile-label">QoQ Change</div>
                        <div className="insight-tile-value">+{quickData.metrics.qoqPct.toFixed(1)}%</div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Anomaly Detected banner */}
                {quickData && quickData.anomaly && (
                  <div className="anomaly-banner">
                    <span style={{ fontSize: 18 }}>⚠️</span>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 800, color: "#0f172a", marginBottom: 2 }}>Anomaly Detected</div>
                      <div style={{ fontSize: 13, color: "#475569" }}>{quickData.anomaly}</div>
                    </div>
                  </div>
                )}

                {/* Monthly Trend chart */}
                {quickData && quickData.monthly && quickData.monthly.length > 0 && (
                  <div style={{ marginBottom: 16 }}>
                    <div style={{ fontWeight: 800, fontSize: 15, marginBottom: 8, color: "#0f172a" }}>Monthly Trend</div>
                    <div className="card">
                      <div className="chart-subtitle">Monthly Revenue Trend</div>
                      <LineAreaChart
                        labels={quickData.monthly.map(r => monthLabel(r.MONTH || r.month || ""))}
                        data={quickData.monthly.map(r => +(r.REVENUE_M || 0) * 1e6)}
                        color="#3B82F6" fillColor="rgba(59,130,246,0.12)" height={220}
                        formatFn={v => v >= 1e6 ? `${(v/1e6).toFixed(0)}M` : v}
                      />
                    </div>
                  </div>
                )}

                {/* Top Dealers by Revenue chart */}
                {quickData && quickData.dealers && quickData.dealers.length > 0 && (
                  <div style={{ marginBottom: 16 }}>
                    <div style={{ fontWeight: 800, fontSize: 15, marginBottom: 8, color: "#0f172a" }}>Top Dealers by Revenue</div>
                    <div className="card">
                      <HBarChart
                        labels={quickData.dealers.map(r => r.DEALER_NAME || r.dealer_name || "")}
                        data={quickData.dealers.map(r => +(r.REVENUE_M || 0) * 1e6)}
                        color="#3B5BDB" height={Math.max(120, quickData.dealers.length * 36)}
                        formatFn={v => `${(v/1e6).toFixed(4)}M`}
                      />
                    </div>
                  </div>
                )}

                {lastResponse.parsed.desc && (
                  <div className="descriptive-card">
                    <div className="descriptive-card-title">Descriptive — What the data shows</div>
                    <div style={{ color: "#0f172a", fontSize: 14, lineHeight: 1.6 }}>
                      {renderMultiline(lastResponse.parsed.desc)}
                    </div>
                  </div>
                )}

                {lastResponse.parsed.pres && (
                  <Expander title="Prescriptive — Recommendations & Actions">
                    <div className="prescriptive-content">{renderMultiline(lastResponse.parsed.pres)}</div>
                  </Expander>
                )}

                {lastResponse.parsed.pred && (
                  <Expander title="Predictive — 30–90 Day Forecast">
                    <div className="predictive-card">{renderMultiline(lastResponse.parsed.pred)}</div>
                  </Expander>
                )}
              </div>
            )}
          </div>

          <div className="genie-input-row">
            <input
              className="genie-input"
              placeholder="Ask about Sales & Operations data..."
              value={input}
              onChange={function(e){ setInput(e.target.value); }}
              onKeyDown={function(e){ if (e.key === "Enter") handleSend(); }}
            />
            <button className="genie-send-btn" onClick={handleSend}>Send →</button>
          </div>
        </div>
      </div>
    </div>
  );
}
