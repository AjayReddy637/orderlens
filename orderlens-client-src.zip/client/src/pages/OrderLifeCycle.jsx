import React, { useState, useEffect } from "react";
import { fetchOrderIds, fetchOrderSummary, fetchOrderStatusDetails, fetchProductInfo, fetchDealerInfo, fetchBOM } from "../services/api";

function StatusBadge({ status }) {
  const s = (status || "").toUpperCase();
  const cls = s === "DELIVERED" ? "badge-delivered" : s === "SHIPPED" ? "badge-shipped" : s === "CONFIRMED" ? "badge-confirmed" : "badge-placed";
  return <span className={`status-badge ${cls}`}>{status}</span>;
}

export default function OrderLifeCycle() {
  const [orderIds, setOrderIds]           = useState([]);
  const [selected, setSelected]           = useState([]);
  const [summaries, setSummaries]         = useState([]);
  const [statusDetails, setStatusDetails] = useState([]);
  const [productInfo, setProductInfo]     = useState([]);
  const [dealerInfo, setDealerInfo]       = useState([]);
  const [bomData, setBomData]             = useState([]);
  const [detailTab, setDetailTab]         = useState("product");
  const [loaded, setLoaded]               = useState(false);
  const [loading, setLoading]             = useState(false);
  const [searching, setSearching]         = useState(false);
  const [search, setSearch]               = useState("");
  const [dropdownOpen, setDropdownOpen]   = useState(false);

  useEffect(() => {
    setSearching(true);
    fetchOrderIds().then(rows => {
      setOrderIds(rows.map(r => r.ORDER_ID || r.order_id || Object.values(r)[0]));
      setSearching(false);
    });
  }, []);

  const filtered = search
    ? orderIds.filter(id => id.toLowerCase().includes(search.toLowerCase()) && !selected.includes(id))
    : orderIds.filter(id => !selected.includes(id));

  function toggleOrder(id) {
    setSelected(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
    setSearch("");
  }

  function removeOrder(id) {
    setSelected(prev => prev.filter(x => x !== id));
  }

  function clearAll() {
    setSelected([]);
    setLoaded(false);
  }

  // Auto-load whenever the selection changes (matches Streamlit multiselect auto-run behavior)
  useEffect(() => {
    if (selected.length === 0) {
      setLoaded(false);
      return;
    }
    loadOrders();
  }, [selected]);

  async function loadOrders() {
    if (!selected.length) return;
    setLoading(true);
    setLoaded(false);
    try {
      const [summ, status] = await Promise.all([
        fetchOrderSummary(selected),
        fetchOrderStatusDetails(selected),
      ]);
      setSummaries(summ);
      setStatusDetails(status);

      // Collect product ids and dealer ids
      const productIds = [...new Set(summ.flatMap(r => [r.PRODUCT_ID || r.product_id]).filter(Boolean))];
      const dealerIds  = [...new Set(summ.map(r => r.DEALER_ID || r.dealer_id).filter(Boolean))];

      const [pInfo, dInfo] = await Promise.all([
        fetchProductInfo(selected),
        fetchDealerInfo(dealerIds),
      ]);
      setProductInfo(pInfo);
      setDealerInfo(dInfo);

      const parentPids = [...new Set(pInfo.map(r => r.PRODUCT_ID || r.product_id).filter(Boolean))];
      if (parentPids.length) {
        const bom = await fetchBOM(parentPids);
        setBomData(bom);
      }
      setLoaded(true);
    } catch (e) {
      alert("Error loading orders: " + e.message);
    }
    setLoading(false);
  }

  function fmt(v) { return v ? `$${parseFloat(v).toLocaleString(undefined, { minimumFractionDigits: 2 })}` : "$0.00"; }
  function fmtDate(v) { return v ? String(v).slice(0, 10) : "N/A"; }

  return (
    <div className="block-container">
      <div className="olc-section-title">Order Details Lookup</div>
      <div style={{ color: "#64748b", marginBottom: 12 }}>Search and view comprehensive information about any order</div>
      <hr style={{ border: "none", borderTop: "1.5px solid #E5E7EB", marginBottom: 18 }} />

      {/* SEARCH BOX — chip-style multiselect matching Streamlit st.multiselect */}
      <div className="order-search-box">
        <label style={{ fontSize: 13, fontWeight: 600, color: "#374151", marginBottom: 6, display: "block" }}>
          Select Order ID(s)
        </label>
        <div style={{ position: "relative" }}>
          <div
            className="multiselect-control"
            onClick={() => setDropdownOpen(true)}
          >
            {selected.map(id => (
              <span key={id} className="multiselect-chip" onClick={e => e.stopPropagation()}>
                {id}
                <span className="multiselect-chip-x" onClick={() => removeOrder(id)}>×</span>
              </span>
            ))}
            <input
              className="multiselect-input"
              placeholder={selected.length === 0 ? "Select one or more orders" : ""}
              value={search}
              onChange={e => { setSearch(e.target.value); setDropdownOpen(true); }}
              onFocus={() => setDropdownOpen(true)}
            />
            {selected.length > 0 && (
              <span className="multiselect-clear-all" onClick={e => { e.stopPropagation(); clearAll(); }}>✕</span>
            )}
            <span className="multiselect-caret">▾</span>
          </div>

          {dropdownOpen && (
            <>
              <div className="multiselect-backdrop" onClick={() => setDropdownOpen(false)} />
              <div className="multiselect-dropdown">
                {searching
                  ? <div className="spinner-text" style={{ padding: "10px 14px" }}><span className="spinner-dot" /> Loading order IDs…</div>
                  : filtered.length === 0
                    ? <div style={{ padding: "10px 14px", fontSize: 13, color: "#94a3b8" }}>No orders found</div>
                    : filtered.slice(0, 100).map(id => (
                      <div key={id} className="multiselect-option"
                        onClick={() => { toggleOrder(id); setDropdownOpen(true); }}>
                        {id}
                      </div>
                    ))
                }
              </div>
            </>
          )}
        </div>

        {!loaded && !loading && selected.length === 0 && (
          <div className="info-box" style={{ marginTop: 12 }}>Select one or more Order IDs to view details</div>
        )}
        {loaded && !loading && (
          <div className="success-box" style={{ marginTop: 12 }}>{selected.length} order(s) loaded</div>
        )}
      </div>

      {loading && <div className="spinner-text"><span className="spinner-dot" /> Loading order details…</div>}

      {loaded && (
        <>
          {/* ORDER SUMMARY TILES */}
          <div className="olc-section-title">Order Summary</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
            {summaries.map(row => {
              const id   = row.ORDER_ID || row.order_id || "";
              const date = fmtDate(row.ORDER_DATE || row.order_date);
              const qty  = parseInt(row.TOTAL_QUANTITY || row.total_quantity || 0);
              const amt  = fmt(row.TOTAL_AMOUNT || row.total_amount);
              const exp  = fmtDate(row.EXPECTED_DELIVERY_DATE || row.expected_delivery_date);
              return (
                <div key={id} className="kpi-card kpi-card-blue order-summary-tile">
                  <div className="kpi-label">Order ID: {id}</div>
                  <div className="order-summary-grid">
                    <div><div className="order-summary-field-label">Order Date</div><div className="order-summary-field-value">{date}</div></div>
                    <div><div className="order-summary-field-label">Quantity</div><div className="order-summary-field-value">{qty}</div></div>
                    <div><div className="order-summary-field-label">Total Amount</div><div className="order-summary-field-value">{amt}</div></div>
                    <div><div className="order-summary-field-label">Expected Delivery Date</div><div className="order-summary-field-value">{exp}</div></div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* ORDER STATUS TABLE */}
          <div className="olc-section-title" style={{ marginTop: 20 }}>Order Status Information</div>
          <div className="card" style={{ padding: 16 }}>
            <table className="data-table">
              <thead>
                <tr><th>Order Number</th><th>Status</th><th>Order Status Date</th></tr>
              </thead>
              <tbody>
                {statusDetails.map((row, i) => (
                  <tr key={i}>
                    <td>{row.ORDER_ID || row.order_id}</td>
                    <td>{row.ORDER_STATUS || row.order_status}</td>
                    <td>{fmtDate(row.ORDER_STATUS_DATE || row.order_status_date)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* ORDER DETAILS TABS */}
          <div className="olc-section-title" style={{ marginTop: 20 }}>Order Details</div>
          <div className="subtab-wrap">
            {[["product","Product Info"],["dealer","Dealer Info"],["bom","Bill Of Materials"]].map(([k,l]) => (
              <button key={k} className={`subtab-btn${detailTab === k ? " active" : ""}`}
                onClick={() => setDetailTab(k)}>{l}</button>
            ))}
          </div>

          {detailTab === "product" && (
            <div className="card" style={{ padding: 16 }}>
              <table className="data-table">
                <thead>
                  <tr><th>Product ID</th><th>Name</th><th>Type</th><th>Category</th><th>Config</th><th>Unit Price</th><th>Qty</th></tr>
                </thead>
                <tbody>
                  {productInfo.map((row, i) => (
                    <tr key={i}>
                      <td>{row.PRODUCT_ID || row.product_id}</td>
                      <td>{row.PRODUCT_NAME || row.product_name}</td>
                      <td>{row.PRODUCT_TYPE || row.product_type}</td>
                      <td>{row.PRODUCT_CATEGORY || row.product_category}</td>
                      <td>{row.CONFIG_NAME || row.config_name}</td>
                      <td>{fmt(row.UNIT_PRICE || row.unit_price)}</td>
                      <td>{row.TOTAL_QUANTITY_ORDERED || row.total_quantity_ordered}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {detailTab === "dealer" && (
            <div className="card" style={{ padding: 16 }}>
              <table className="data-table">
                <thead>
                  <tr><th>Dealer ID</th><th>Name</th><th>Type</th><th>Country</th><th>Region</th><th>City</th><th>Total Orders</th><th>Total Revenue</th></tr>
                </thead>
                <tbody>
                  {dealerInfo.map((row, i) => (
                    <tr key={i}>
                      <td>{row.DEALER_ID || row.dealer_id}</td>
                      <td>{row.DEALER_NAME || row.dealer_name}</td>
                      <td>{row.DEALER_TYPE || row.dealer_type}</td>
                      <td>{row.COUNTRY || row.country}</td>
                      <td>{row.REGION || row.region}</td>
                      <td>{row.CITY || row.city}</td>
                      <td>{parseInt(row.TOTAL_ORDERS || row.total_orders || 0).toLocaleString()}</td>
                      <td>{fmt(row.TOTAL_REVENUE || row.total_revenue)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {detailTab === "bom" && (
            <div className="card" style={{ padding: 16 }}>
              <table className="data-table">
                <thead>
                  <tr><th>Parent Product</th><th>Parent Name</th><th>Child Product</th><th>Child Name</th><th>Qty/Assembly</th><th>UOM</th><th>Scrap Factor</th></tr>
                </thead>
                <tbody>
                  {bomData.map((row, i) => (
                    <tr key={i}>
                      <td>{row.PARENT_PRODUCT || row.parent_product}</td>
                      <td>{row.PARENT_PRODUCT_NAME || row.parent_product_name}</td>
                      <td>{row.CHILD_PRODUCT || row.child_product}</td>
                      <td>{row.CHILD_PRODUCT_NAME || row.child_product_name}</td>
                      <td>{row.QUANTITY_PER_ASSEMBLY || row.quantity_per_assembly}</td>
                      <td>{row.UNIT_OF_MEASURE || row.unit_of_measure}</td>
                      <td>{row.SCRAP_FACTOR || row.scrap_factor ? `${(parseFloat(row.SCRAP_FACTOR || row.scrap_factor) * 100).toFixed(1)}%` : "0.0%"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}
