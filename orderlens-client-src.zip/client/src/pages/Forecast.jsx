import React, { useState, useEffect } from "react";
import { fetchForecastQty, fetchForecastRev, fetchProductMix, fetchRevenueShare, fetchForecastProducts, fetchForecastMonths } from "../services/api";
import { HBarChart, VBarChart, ScatterChart, ScatterLegend, COLORS } from "../components/Charts";

export default function Forecast() {
  const [products, setProducts]     = useState([]);
  const [months, setMonths]         = useState([]);
  const [selProducts, setSelProd]   = useState([]);
  const [selMonth, setSelMonth]     = useState("All");
  const [fcstQty, setFcstQty]       = useState([]);
  const [fcstRev, setFcstRev]       = useState([]);
  const [prodMix, setProdMix]       = useState([]);
  const [revShare, setRevShare]     = useState([]);
  const [loading, setLoading]       = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [search, setSearch]         = useState("");

  useEffect(() => {
    Promise.all([fetchForecastProducts(), fetchForecastMonths()]).then(([p, m]) => {
      const mapped = p.map(r => ({ id: r.PRODUCT_ID || r.product_id, name: r.PRODUCT_NAME || r.product_name }));
      const seen = new Set();
      const deduped = mapped.filter(item => {
        if (seen.has(item.name)) return false;
        seen.add(item.name);
        return true;
      });
      setProducts(deduped);
      setMonths(m.map(r => r.MONTH || r.month || Object.values(r)[0]));
    });
  }, []);

  useEffect(() => {
    setLoading(true);
    const pc = selProducts.length
      ? `AND F.PRODUCT_ID IN (${selProducts.map(id => `'${id}'`).join(",")})` : "";
    const mc = selMonth !== "All"
      ? `AND DATE_FORMAT(DATE_TRUNC('month', F.FORECAST_PERIOD_END),'%Y-%m') = '${selMonth}'` : "";

    Promise.all([
      fetchForecastQty(pc, mc),
      fetchForecastRev(pc, mc),
      fetchProductMix(pc, mc),
      fetchRevenueShare(pc, mc),
    ]).then(([q, r, pm, rs]) => {
      setFcstQty(q); setFcstRev(r); setProdMix(pm); setRevShare(rs);
      setLoading(false);
    });
  }, [selProducts, selMonth]);

  const qtyLabels = fcstQty.map(r => r.MONTH || r.month || "");
  const qtyData   = fcstQty.map(r => +(r.QTY || r.qty || 0));
  const revLabels = fcstRev.map(r => r.MONTH || r.month || "");
  const revData   = fcstRev.map(r => +(r.REVENUE_M || r.revenue_m || 0));

  const mixTypes = [...new Set(prodMix.map(r => r.PRODUCT_TYPE || r.product_type || "Other"))];
  const mixDS = mixTypes.map(t => ({
    label: t,
    data: prodMix
      .filter(r => (r.PRODUCT_TYPE || r.product_type) === t)
      .map(r => ({ x: +(r.FORECAST_QUANTITY || 0), y: +(r.FORECAST_REVENUE_M || 0) })),
  }));

  const rsLabels = revShare.map(r => r.PRODUCT_FAMILY || r.product_family || "");
  const rsData   = revShare.map(r => +(r.REVENUE_M || r.revenue_m || 0));

  function toggleProduct(id) {
    setSelProd(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
    setSearch("");
  }

  function removeProduct(id) {
    setSelProd(prev => prev.filter(x => x !== id));
  }

  function clearAllProducts() {
    setSelProd([]);
  }

  const filteredProducts = search
    ? products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) && !selProducts.includes(p.id))
    : products.filter(p => !selProducts.includes(p.id));

  return (
    <div className="block-container">
      <div className="welcome-title">Sales Forecast</div>
      <div style={{ color: "#64748b", marginBottom: 16 }}>Projected demand and revenue</div>

      <div className="filter-row">
        <div style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 320 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: "#64748b" }}>Filter by Product</div>
          <div style={{ position: "relative" }}>
            <div className="multiselect-control" onClick={() => setDropdownOpen(true)}>
              {selProducts.map(id => {
                const p = products.find(pp => pp.id === id);
                return (
                  <span key={id} className="multiselect-chip" onClick={e => e.stopPropagation()}>
                    {p ? p.name : id}
                    <span className="multiselect-chip-x" onClick={() => removeProduct(id)}>×</span>
                  </span>
                );
              })}
              <input
                className="multiselect-input"
                placeholder={selProducts.length === 0 ? "Choose options" : ""}
                value={search}
                onChange={e => { setSearch(e.target.value); setDropdownOpen(true); }}
                onFocus={() => setDropdownOpen(true)}
              />
              {selProducts.length > 0 && (
                <span className="multiselect-clear-all" onClick={e => { e.stopPropagation(); clearAllProducts(); }}>✕</span>
              )}
              <span className="multiselect-caret">▾</span>
            </div>
            {dropdownOpen && (
              <>
                <div className="multiselect-backdrop" onClick={() => setDropdownOpen(false)} />
                <div className="multiselect-dropdown">
                  {filteredProducts.length === 0
                    ? <div style={{ padding: "10px 14px", fontSize: 13, color: "#94a3b8" }}>No products found</div>
                    : filteredProducts.slice(0, 100).map(p => (
                      <div key={p.id} className="multiselect-option" onClick={() => toggleProduct(p.id)}>
                        {p.name}
                      </div>
                    ))
                  }
                </div>
              </>
            )}
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: "#64748b" }}>Filter by Month</div>
          <select className="filter-input" value={selMonth} onChange={e => setSelMonth(e.target.value)}>
            <option value="All">All</option>
            {months.map(m => <option key={m}>{m}</option>)}
          </select>
        </div>
        {loading && <div className="spinner-text" style={{ marginTop: 16 }}><span className="spinner-dot" /> Loading…</div>}
      </div>

      <div className="chart-grid-2">
        <div className="card">
          <div className="chart-title">Monthly Forecast Quantity</div>
          <HBarChart labels={qtyLabels} data={qtyData} color="#60A5FA" height={280}
            xAxisLabel="Total Quantity" yAxisLabel="Month" />
        </div>
        <div className="card">
          <div className="chart-title">Monthly Forecast Revenue</div>
          <HBarChart labels={revLabels} data={revData} color="#4ADE80" height={280}
            formatFn={v => `$${v.toFixed(1)}M`} xAxisLabel="Total Revenue ($M)" yAxisLabel="Month" />
        </div>
      </div>

      <div className="chart-grid-2" style={{ marginTop: 16 }}>
        <div className="card">
          <div className="chart-title">Product Mix: Quantity vs Revenue</div>
          <ScatterChart datasets={mixDS} height={300}
            xLabel="Forecast Quantity" yLabel="Forecast Revenue (Millions $)" />
          <ScatterLegend heading="PRODUCT TYPE" items={mixTypes.map((t, i) => ({ label: t, color: COLORS[i % COLORS.length] }))} />
        </div>
        <div className="card">
          <div className="chart-title">Revenue Share by Product Family</div>
          <VBarChart labels={rsLabels} data={rsData} color="#60A5FA" height={340}
            formatFn={v => `$${v.toFixed(1)}M`} xAxisLabel="Product Family" yAxisLabel="Revenue ($M)" />
        </div>
      </div>
    </div>
  );
}
