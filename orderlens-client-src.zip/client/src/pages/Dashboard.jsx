import React, { useState, useEffect, useCallback } from "react";
import {
  fetchKPIs, fetchSalesByProductType, fetchOrderStatus,
  fetchMonthlyRevenue, fetchMonthlyOrders, fetchCategoryPerformance,
  fetchDealerPerformance, fetchDealerTypeDist, fetchUniqueProducts, fetchRevByDealer,
  fetchConfigRevenue, fetchConfigAOV, fetchConfigByDealerType,
  fetchTopFeatures, fetchFeaturesByDealerType, fetchFeaturesByProductType,
  fetchDealers,
} from "../services/api";
import {
  HBarChart, VBarChart, GroupedBarChart, DonutChart, LineAreaChart,
  BubbleChart, DonutLegend,
} from "../components/Charts";

const TODAY = new Date().toISOString().slice(0, 10);
const D30   = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);

function abbr(v) {
  const n = Math.abs(+v || 0);
  if (n >= 1e9) return `$${(n / 1e9).toFixed(1)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(1)}M`;
  if (n >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${n.toFixed(0)}`;
}
function pctChange(curr, prev) {
  const c = +curr || 0, p = +prev || 0;
  if (p === 0) return { val: 0, cls: "neutral", str: "0%" };
  const v = ((c - p) / p) * 100;
  if (Math.abs(v) < 0.5) return { val: 0, cls: "neutral", str: "0%" };
  return { val: v, cls: v > 0 ? "positive" : "negative", str: `${v > 0 ? "↗" : "↘"} ${Math.abs(v).toFixed(0)}%` };
}

const COLORS = ["#4ADE80","#FBBF24","#60A5FA","#F87171","#A78BFA","#F472B6"];

export default function Dashboard() {
  const [startDate, setStartDate]     = useState(D30);
  const [endDate, setEndDate]         = useState(TODAY);
  const [timeFilter, setTimeFilter]   = useState("Last 30 Days");
  const [dealer, setDealer]           = useState("All Dealers");
  const [dealers, setDealers]         = useState([]);
  const [activeTab, setActiveTab]     = useState("health");
  const [kpis, setKpis]               = useState({ current: {}, previous: {} });
  const [loading, setLoading]         = useState(true);

  // Tab-specific data
  const [salesByType, setSalesByType]         = useState([]);
  const [orderStatus, setOrderStatus]         = useState([]);
  const [monthlyRev, setMonthlyRev]           = useState([]);
  const [monthlyOrd, setMonthlyOrd]           = useState([]);
  const [catPerf, setCatPerf]                 = useState([]);
  const [dealerPerf, setDealerPerf]           = useState([]);
  const [dealerType, setDealerType]           = useState([]);
  const [uniqueProd, setUniqueProd]           = useState([]);
  const [revByDealer, setRevByDealer]         = useState([]);
  const [configRev, setConfigRev]             = useState([]);
  const [configAOV, setConfigAOV]             = useState([]);
  const [configByDlr, setConfigByDlr]         = useState([]);
  const [topFeatures, setTopFeatures]         = useState([]);
  const [featByDlr, setFeatByDlr]             = useState([]);
  const [featByProd, setFeatByProd]           = useState([]);

  const dc = dealer && dealer !== "All Dealers"
    ? `AND DEALER_NAME = '${dealer.replace(/'/g, "''")}'` : "";
  const dcf = dealer && dealer !== "All Dealers"
    ? `AND f.DEALER_NAME = '${dealer.replace(/'/g, "''")}'` : "";

  useEffect(() => {
    fetchDealers(D30, TODAY).then(rows => {
      setDealers(rows.map(r => r.DEALER_NAME || r.dealer_name || Object.values(r)[0]));
    });
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    const [k] = await Promise.all([fetchKPIs(startDate, endDate, dealer)]);
    setKpis(k);
    setLoading(false);
  }, [startDate, endDate, dealer]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (activeTab === "health") {
      Promise.all([
        fetchSalesByProductType(startDate, endDate, dcf),
        fetchOrderStatus(startDate, endDate, dc),
        fetchMonthlyRevenue(startDate, endDate, dc),
        fetchMonthlyOrders(startDate, endDate, dc),
        fetchCategoryPerformance(startDate, endDate, dc),
      ]).then(([st, os, mr, mo, cp]) => {
        setSalesByType(st); setOrderStatus(os);
        setMonthlyRev(mr); setMonthlyOrd(mo); setCatPerf(cp);
      });
    }
  }, [activeTab, startDate, endDate, dc, dcf]);

  useEffect(() => {
    if (activeTab === "dealer") {
      Promise.all([
        fetchDealerPerformance(startDate, endDate, dcf),
        fetchDealerTypeDist(startDate, endDate, dcf),
        fetchUniqueProducts(startDate, endDate, dc),
        fetchRevByDealer(startDate, endDate, dc),
      ]).then(([dp, dt, up, rbd]) => {
        setDealerPerf(dp); setDealerType(dt);
        setUniqueProd(up); setRevByDealer(rbd);
      });
    }
  }, [activeTab, startDate, endDate, dc, dcf]);

  useEffect(() => {
    if (activeTab === "config") {
      Promise.all([
        fetchConfigRevenue(startDate, endDate, dc),
        fetchConfigAOV(startDate, endDate, dc),
        fetchConfigByDealerType(startDate, endDate, dcf),
      ]).then(([cr, ca, cbd]) => {
        setConfigRev(cr); setConfigAOV(ca); setConfigByDlr(cbd);
      });
    }
  }, [activeTab, startDate, endDate, dc, dcf]);

  useEffect(() => {
    if (activeTab === "features") {
      Promise.all([
        fetchTopFeatures(startDate, endDate, dcf),
        fetchFeaturesByDealerType(startDate, endDate, dcf),
        fetchFeaturesByProductType(startDate, endDate, dcf),
      ]).then(([tf, fbd, fbp]) => {
        setTopFeatures(tf); setFeatByDlr(fbd); setFeatByProd(fbp);
      });
    }
  }, [activeTab, startDate, endDate, dc, dcf]);

  function setPreset(label) {
    const today = new Date();
    setTimeFilter(label);
    setEndDate(TODAY);
    if (label === "Last 30 Days") setStartDate(new Date(today - 30 * 86400000).toISOString().slice(0, 10));
    if (label === "QTD") {
      const qm = Math.floor(today.getMonth() / 3) * 3;
      setStartDate(new Date(today.getFullYear(), qm, 1).toISOString().slice(0, 10));
    }
    if (label === "YTD") setStartDate(`${today.getFullYear()}-01-01`);
    if (label === "Custom") { /* user sets via date inputs */ }
  }

  const cur = kpis.current, prev = kpis.previous;
  const kpiDefs = [
    { label: "Total Revenue",       cls: "kpi-card-green",  val: abbr(cur.REVENUE),          chg: pctChange(cur.REVENUE, prev.REVENUE) },
    { label: "Total Orders",        cls: "kpi-card-purple", val: (+cur.ORDERS || 0).toLocaleString(), chg: pctChange(cur.ORDERS, prev.ORDERS) },
    { label: "Average Order Value", cls: "kpi-card-cyan",   val: abbr(cur.AOV),              chg: pctChange(cur.AOV, prev.AOV) },
    { label: "Active Dealers",      cls: "kpi-card-blue",   val: (+cur.DEALERS || 0).toLocaleString(), chg: pctChange(cur.DEALERS, prev.DEALERS) },
    { label: "Active Products",     cls: "kpi-card-yellow", val: (+cur.PRODUCTS || 0).toLocaleString(), chg: pctChange(cur.PRODUCTS, prev.PRODUCTS) },
    { label: "Total Units",         cls: "kpi-card-lime",   val: (+cur.UNITS || 0).toLocaleString(), chg: pctChange(cur.UNITS, prev.UNITS) },
  ];

  // Chart data helpers
  const salesTypeLabels = salesByType.map(r => r.PRODUCT_TYPE || r.product_type || "");
  const salesTypeData   = salesByType.map(r => +(r.TOTAL_SALES || r.total_sales || 0));
  const statusLabels    = orderStatus.map(r => r.ORDER_STATUS || r.order_status || "");
  const statusData      = orderStatus.map(r => +(r.ORDER_COUNT || r.order_count || 0));
  const MONTH_ABBR = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  function monthLabel(ym) {
    // ym is "YYYY-MM" -> "Mon"
    const m = parseInt((ym || "").slice(5, 7), 10);
    return m >= 1 && m <= 12 ? MONTH_ABBR[m - 1] : ym;
  }
  const monRevLabels    = monthlyRev.map(r => monthLabel(r.MONTH || r.month || ""));
  const monRevData      = monthlyRev.map(r => +(r.REVENUE_M || r.revenue_m || 0));
  const monOrdLabels    = monthlyOrd.map(r => monthLabel(r.MONTH || r.month || ""));
  const monOrdData      = monthlyOrd.map(r => +(r.ORDERS || r.orders || 0));
  const catMax          = Math.max(...catPerf.map(r => +(r.REVENUE_M || r.revenue_m || 0)), 1);

  const dealerBubbleDS  = (() => {
    const byType = {};
    dealerPerf.forEach(r => {
      const t = r.DEALER_TYPE || r.dealer_type || "Other";
      if (!byType[t]) byType[t] = [];
      byType[t].push({ x: +(r.ORDERS || 0), y: +(r.REVENUE_MILLIONS || 0), r: Math.max(5, Math.min(20, +(r.AVG_ORDER_VALUE || 0) / 500)) });
    });
    return Object.entries(byType).map(([label, data]) => ({ label, data }));
  })();

  const dtLabels = dealerType.map(r => r.DEALER_TYPE || r.dealer_type || "");
  const dtData   = dealerType.map(r => +(r.DEALER_COUNT || r.dealer_count || 0));

  const upLabels = uniqueProd.map(r => r.DEALER_NAME || r.dealer_name || "");
  const upData   = uniqueProd.map(r => +(r.UNIQUE_PRODUCTS || r.unique_products || 0));
  const rbdLabels= revByDealer.map(r => r.DEALER_NAME || r.dealer_name || "");
  const rbdData  = revByDealer.map(r => +(r.REVENUE_M || r.revenue_m || 0));

  const crLabels = configRev.map(r => r.CONFIG_NAME || r.config_name || "");
  const crData   = configRev.map(r => +(r.REVENUE_M || r.revenue_m || 0));
  const caLabels = configAOV.map(r => r.CONFIG_NAME || r.config_name || "");
  const caData   = configAOV.map(r => +(r.AVG_ORDER_VALUE || r.avg_order_value || 0));
  const cbdDS    = (() => {
    const types = [...new Set(configByDlr.map(r => r.DEALER_TYPE || r.dealer_type || ""))];
    const configs = [...new Set(configByDlr.map(r => r.CONFIG_NAME || r.config_name || ""))].slice(0, 10);
    return types.map(t => ({
      label: t,
      data: configs.map(c => {
        const row = configByDlr.find(r => (r.DEALER_TYPE || r.dealer_type) === t && (r.CONFIG_NAME || r.config_name) === c);
        return row ? +(row.REVENUE_M || row.revenue_m || 0) : 0;
      }),
    }));
  })();
  const cbdLabels = [...new Set(configByDlr.map(r => r.CONFIG_NAME || r.config_name || ""))].slice(0, 10);

  const tfLabels = topFeatures.map(r => r.FEATURE_NAME || r.feature_name || "");
  const tfData   = topFeatures.map(r => +(r.REVENUE_M || r.revenue_m || 0));
  const fbdTypes = [...new Set(featByDlr.map(r => r.DEALER_TYPE || r.dealer_type || ""))];
  const fbdFeats = [...new Set(featByDlr.map(r => r.FEATURE_NAME || r.feature_name || ""))].slice(0, 8);
  const fbdDS = fbdTypes.map(t => ({
    label: t,
    data: fbdFeats.map(f => {
      const row = featByDlr.find(r => (r.DEALER_TYPE || r.dealer_type) === t && (r.FEATURE_NAME || r.feature_name) === f);
      return row ? +(row.REVENUE_M || row.revenue_m || 0) : 0;
    }),
  }));
  const fbpTypes = [...new Set(featByProd.map(r => r.PRODUCT_TYPE || r.product_type || ""))];
  const fbpFeats = [...new Set(featByProd.map(r => r.FEATURE_NAME || r.feature_name || ""))].slice(0, 8);
  const fbpDS = fbpTypes.map(t => ({
    label: t,
    data: fbpFeats.map(f => {
      const row = featByProd.find(r => (r.PRODUCT_TYPE || r.product_type) === t && (r.FEATURE_NAME || r.feature_name) === f);
      return row ? +(row.REVENUE_M || row.revenue_m || 0) : 0;
    }),
  }));

  return (
    <div className="block-container">
      <div className="welcome-title">Welcome to Personal Sales Dashboard</div>

      {/* FILTER ROW */}
      <div className="filter-row">
        <input type="date" className="filter-input" value={startDate}
          onChange={e => { setStartDate(e.target.value); setTimeFilter("Custom"); }} />
        <span style={{ fontSize: 13, color: "#64748b" }}>to</span>
        <input type="date" className="filter-input" value={endDate}
          onChange={e => { setEndDate(e.target.value); setTimeFilter("Custom"); }} />
        <select className="filter-input" style={{ minWidth: 160 }}
          value={dealer} onChange={e => setDealer(e.target.value)}>
          <option>All Dealers</option>
          {dealers.map(d => <option key={d}>{d}</option>)}
        </select>
        <div className="filter-spacer" />
        {["Last 30 Days","QTD","YTD","Custom"].map(t => (
          <button key={t} className={`period-btn${timeFilter === t ? " active" : ""}`}
            onClick={() => setPreset(t)}>{t}</button>
        ))}
      </div>

      {/* KPI CARDS */}
      {loading ? (
        <div className="spinner-text"><span className="spinner-dot" /> Loading KPIs…</div>
      ) : (
        <div className="kpi-row">
          {kpiDefs.map(k => (
            <div key={k.label} className={`kpi-card ${k.cls}`}>
              <div className="kpi-label">{k.label}</div>
              <div className="kpi-value">{k.val}</div>
              <div className={`kpi-change ${k.chg.cls}`}>{k.chg.str} vs last period</div>
            </div>
          ))}
        </div>
      )}

      {/* TABS */}
      <div className="dashboard-tabs">
        {[["health","Business Health"],["dealer","Dealer Performance"],["config","Configurations"],["features","Features"]].map(([k,l]) => (
          <button key={k} className={`tab-btn${activeTab === k ? " active" : ""}`}
            onClick={() => setActiveTab(k)}>{l}</button>
        ))}
      </div>

      {/* ── BUSINESS HEALTH ── */}
      {activeTab === "health" && (
        <>
          <div className="chart-grid-2">
            <div className="card">
              <div className="chart-title">SALES BY PRODUCT TYPE</div>
              <HBarChart labels={salesTypeLabels} data={salesTypeData} color="#FDE047"
                formatFn={v => `$${(v/1e6).toFixed(1)}M`} height={260} xAxisLabel="Total Sales" />
            </div>
            <div className="card">
              <div className="chart-title">ORDER STATUS DISTRIBUTION</div>
              <DonutChart labels={statusLabels} data={statusData} height={220} />
              <div className="legend-heading">ORDER STATUS</div>
              <DonutLegend items={statusLabels.map((l, i) => ({
                label: `${l} (${statusData[i].toLocaleString()})`,
                color: COLORS[i],
              }))} />
            </div>
          </div>

          <div className="chart-full">
            <div className="chart-title">Monthly Performance Trends</div>
            <div className="chart-grid-2">
              <div>
                <div className="chart-subtitle">Total Revenue Trend</div>
                <LineAreaChart labels={monRevLabels} data={monRevData} color="#4ECDC4"
                  fillColor="rgba(219,234,254,0.3)" height={220}
                  formatFn={v => `$${v.toFixed(1)}M`} />
              </div>
              <div>
                <div className="chart-subtitle">Total Orders Trend</div>
                <LineAreaChart labels={monOrdLabels} data={monOrdData} color="#95E1D3"
                  fillColor="rgba(209,250,229,0.3)" height={220} />
              </div>
            </div>
          </div>

          <div className="chart-full">
            <div className="chart-title">Product Category Performance</div>
            {catPerf.map(row => {
              const name = row.DEALER_NAME || row.dealer_name || "";
              const rev  = +(row.REVENUE_M || row.revenue_m || 0);
              const pct  = Math.round(rev / catMax * 100);
              return (
                <div key={name} className="prog-row">
                  <div className="prog-label"><span>{name}</span><span>${rev.toFixed(2)}M</span></div>
                  <div className="prog-track"><div className="prog-fill" style={{ width: `${pct}%` }} /></div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {/* ── DEALER PERFORMANCE ── */}
      {activeTab === "dealer" && (
        <>
          <div className="chart-grid-2">
            <div className="card">
              <div className="chart-title">Dealer Performance</div>
              <BubbleChart datasets={dealerBubbleDS} height={400}
                xLabel="Total Orders" yLabel="Revenue ($M)" />
            </div>
            <div className="card">
              <div className="chart-title">Revenue by Dealer Type</div>
              <DonutChart labels={dtLabels} data={dtData} height={300} />
              <DonutLegend items={dtLabels.map((l, i) => ({
                label: `${l} ${dtData[i] ? Math.round(dtData[i] / (dtData.reduce((a,b)=>a+b,0)||1) * 100) : 0}%`,
                color: COLORS[i],
              }))} />
            </div>
          </div>
          <div className="chart-grid-2">
            <div className="card">
              <div className="chart-title">Unique Products by Dealer</div>
              <HBarChart labels={upLabels} data={upData} color="#60A5FA" height={400} />
            </div>
            <div className="card">
              <div className="chart-title">Total Revenue (Millions $) by Dealer</div>
              <HBarChart labels={rbdLabels} data={rbdData} color="#60A5FA" height={400}
                formatFn={v => `$${v.toFixed(1)}M`} />
            </div>
          </div>
        </>
      )}

      {/* ── CONFIGURATIONS ── */}
      {activeTab === "config" && (
        <>
          <div className="chart-grid-2">
            <div className="card">
              <div className="chart-title">Revenue By Config</div>
              <HBarChart labels={crLabels} data={crData} color="#60A5FA" height={300}
                formatFn={v => `$${v.toFixed(1)}M`} />
            </div>
            <div className="card">
              <div className="chart-title">Average Order Value By Config</div>
              <HBarChart labels={caLabels} data={caData} color="#4ADE80" height={300}
                formatFn={v => `$${(v/1000).toFixed(1)}K`} />
            </div>
          </div>
          <div className="chart-full">
            <div className="chart-title">Configuration Preference by Dealer Type</div>
            <GroupedBarChart labels={cbdLabels} datasets={cbdDS} height={340}
              formatFn={v => `$${v.toFixed(1)}M`} />
          </div>
        </>
      )}

      {/* ── FEATURES ── */}
      {activeTab === "features" && (
        <>
          <div className="chart-grid-2">
            <div className="card">
              <div className="chart-title">Top 10 Features by Revenue</div>
              <HBarChart labels={tfLabels} data={tfData} color="#60A5FA" height={340}
                formatFn={v => `$${v.toFixed(2)}M`} />
            </div>
            <div className="card">
              <div className="chart-title">Feature Revenue By Dealer Type</div>
              <GroupedBarChart labels={fbdFeats} datasets={fbdDS} height={340} horizontal
                formatFn={v => `$${v.toFixed(1)}M`} />
            </div>
          </div>
          <div className="chart-full">
            <div className="chart-title">Feature Revenue By Product Type</div>
            <GroupedBarChart labels={fbpFeats} datasets={fbpDS} height={300}
              formatFn={v => `$${v.toFixed(1)}M`} />
          </div>
        </>
      )}
    </div>
  );
}
