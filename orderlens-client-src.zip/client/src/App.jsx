import React, { useState } from "react";
import "./index.css";
import Header from "./components/Header";
import BgButton from "./components/BgButton";
import Dashboard from "./pages/Dashboard";
import Genie from "./pages/Genie";
import OrderLifeCycle from "./pages/OrderLifeCycle";
import Forecast from "./pages/Forecast";
import AIAgents from "./pages/AIAgents";

export default function App() {
  const [currentPage, setCurrentPage] = useState("dashboard");

  const pages = {
    dashboard: <Dashboard />,
    genie:     <Genie />,
    lifecycle: <OrderLifeCycle />,
    forecast:  <Forecast />,
    agents:    <AIAgents />,
  };

  return (
    <div className="app-wrapper">
      <Header currentPage={currentPage} setCurrentPage={setCurrentPage} />
      {pages[currentPage] || <Dashboard />}
      <BgButton />
    </div>
  );
}
