import React, { useState } from "react";
import "./index.css";
import Header from "./components/Header";
import BgButton from "./components/BgButton";
import Dashboard from "./pages/Dashboard";
import Genie from "./pages/Genie";
import OrderLifeCycle from "./pages/OrderLifeCycle";
import Forecast from "./pages/Forecast";
import AIAgents from "./pages/AIAgents";

export default function App() {
  const [currentPage, setCurrentPage] = useState("dashboard");

  const pageKeys = ["dashboard", "genie", "lifecycle", "forecast", "agents"];
  const pageComponents = {
    dashboard: <Dashboard />,
    genie:     <Genie />,
    lifecycle: <OrderLifeCycle />,
    forecast:  <Forecast />,
    agents:    <AIAgents />,
  };

  return (
    <div className="app-wrapper">
      <Header currentPage={currentPage} setCurrentPage={setCurrentPage} />
      {pageKeys.map(key => (
        <div key={key} style={{ display: currentPage === key ? "block" : "none" }}>
          {pageComponents[key]}
        </div>
      ))}
      <BgButton />
    </div>
  );
}
