import { BedrockRuntimeClient, InvokeModelCommand } from "@aws-sdk/client-bedrock-runtime";

const bedrockClient = new BedrockRuntimeClient({
  region: process.env.REACT_APP_AWS_REGION || "us-east-1",
  credentials: {
    accessKeyId: process.env.REACT_APP_AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.REACT_APP_AWS_SECRET_ACCESS_KEY,
  },
});

const MODEL_ID = process.env.REACT_APP_BEDROCK_MODEL_ID || "amazon.nova-micro-v1:0";

export async function aiComplete(prompt) {
  try {
    const body = JSON.stringify({
      messages: [{ role: "user", content: [{ text: prompt.slice(0, 3000) }] }],
      inferenceConfig: { maxTokens: 1024, temperature: 0.3 },
    });
    const res = await bedrockClient.send(new InvokeModelCommand({
      modelId: MODEL_ID,
      body,
      contentType: "application/json",
      accept: "application/json",
    }));
    const decoded = JSON.parse(new TextDecoder().decode(res.body));
    return decoded?.output?.message?.content?.[0]?.text || "";
  } catch (err) {
    console.error("Bedrock error:", err);
    return "[AI generation failed. Check Bedrock permissions.]";
  }
}

export async function generateBottleneckAnalysis(funnelData, worstDealers, bottleneckStage) {
  const dealerText = worstDealers.map(d =>
    `- ${d.DEALER_NAME}: ${parseFloat(d.DROP_PCT || 0).toFixed(1)}% drop (${d.FROM_CNT} → ${d.TO_CNT} orders)`
  ).join("\n");

  const prompt = `You are a Sales & Operations analyst reviewing an order pipeline.

PIPELINE SUMMARY:
- PLACED:    ${funnelData.placed} orders (100%)
- CONFIRMED: ${funnelData.confirmed} orders (${funnelData.confirmedPct}%) — ${funnelData.confirmDrop}% dropout
- SHIPPED:   ${funnelData.shipped} orders (${funnelData.shippedPct}%) — ${funnelData.shipDrop}% dropout
- DELIVERED: ${funnelData.delivered} orders (${funnelData.deliveredPct}%) — ${funnelData.delivDrop}% dropout

BIGGEST BOTTLENECK: ${bottleneckStage} (${funnelData.biggestDrop}% dropout)

WORST DEALERS AT THIS STAGE:
${dealerText}

Provide:
1. Bottleneck diagnosis (2 sentences — what is likely causing orders to stop, citing the dropout numbers)
2. Three specific fixes with expected outcomes (bullet points)
3. One dealer-specific action for the worst-performing dealer
Be direct, cite the numbers, no generic advice.`;

  return aiComplete(prompt);
}

export async function generateDealerFixPlan(dealer, dropPct, fromCnt, toCnt, fromStage, toStage) {
  const prompt = `Order pipeline issue for dealer '${dealer}':
Stage ${fromStage} → ${toStage}: ${dropPct.toFixed(1)}% dropout (${fromCnt} orders entered, only ${toCnt} progressed).

Write a specific 3-point action plan to fix this dropout.
Each point must include: the action, who does it, and expected outcome.
Be specific to the ${fromStage} → ${toStage} transition. No generic advice.`;
  return aiComplete(prompt);
}

export async function generateVelocityPlan(dealer, prevOrders, currOrders, dropPct, prevRev, currRev, prevOpd, currOpd, catSummary, dropType) {
  const prompt = `Order velocity analysis for dealer '${dealer}':
- Orders dropped ${Math.abs(dropPct).toFixed(1)}%: ${prevOrders} → ${currOrders} orders
- Order frequency: ${prevOpd.toFixed(3)} orders/day → ${currOpd.toFixed(3)} orders/day
- Revenue: $${parseFloat(prevRev).toLocaleString()} → $${parseFloat(currRev).toLocaleString()}
- Drop type diagnosed as: ${dropType}
- Product breakdown: ${catSummary}

Generate a re-engagement plan:
1. Root cause diagnosis (2 sentences — cite the numbers)
2. Three specific re-engagement actions (bullet points, concrete and product-specific)
3. 30-day success metric (one sentence with a specific order count target)
Be direct, data-specific, no generic advice.`;
  return aiComplete(prompt);
}

export async function generateGenieAnswer(question, dataContext) {
  const prompt = `You are a sales & operations business analyst.

User question: ${question}

Data context:
${dataContext.slice(0, 4000)}

Respond with exactly THREE sections:
(1) **Descriptive**: What the data shows with specific numbers. For YES/NO questions start with Yes or No.
(2) **Prescriptive**: 3-5 SPECIFIC recommended actions with exact findings and numbers.
(3) **Predictive**: A short 30-90 day forecast tied to current metrics. State assumptions and confidence level (Low/Medium/High).

NEVER use vague phrases like "review the data below" without citing specific numbers.`;
  return aiComplete(prompt);
}
