import { AthenaClient, StartQueryExecutionCommand, GetQueryExecutionCommand, GetQueryResultsCommand } from "@aws-sdk/client-athena";

const athenaClient = new AthenaClient({
  region: process.env.REACT_APP_AWS_REGION || "us-east-1",
  credentials: {
    accessKeyId: process.env.REACT_APP_AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.REACT_APP_AWS_SECRET_ACCESS_KEY,
  },
});

const DATABASE = process.env.REACT_APP_ATHENA_DATABASE || "orderlens";
const WORKGROUP = process.env.REACT_APP_ATHENA_WORKGROUP || "primary";
const OUTPUT_BUCKET = process.env.REACT_APP_ATHENA_OUTPUT_BUCKET;

async function waitForQuery(queryExecutionId, maxWait = 60000) {
  const start = Date.now();
  while (Date.now() - start < maxWait) {
    const res = await athenaClient.send(new GetQueryExecutionCommand({ QueryExecutionId: queryExecutionId }));
    const state = res.QueryExecution.Status.State;
    if (state === "SUCCEEDED") return true;
    if (state === "FAILED" || state === "CANCELLED") {
      throw new Error(`Query ${state}: ${res.QueryExecution.Status.StateChangeReason}`);
    }
    await new Promise(r => setTimeout(r, 1000));
  }
  throw new Error("Query timeout");
}

async function getQueryResults(queryExecutionId) {
  const results = [];
  let nextToken;
  do {
    const res = await athenaClient.send(new GetQueryResultsCommand({ QueryExecutionId: queryExecutionId, NextToken: nextToken }));
    const rows = res.ResultSet.Rows;
    const headers = rows[0].Data.map(d => d.VarCharValue);
    const dataRows = results.length === 0 ? rows.slice(1) : rows;
    for (const row of dataRows) {
      const obj = {};
      row.Data.forEach((cell, i) => { obj[headers[i]] = cell.VarCharValue ?? null; });
      results.push(obj);
    }
    nextToken = res.NextToken;
  } while (nextToken);
  return results;
}

export async function runQuery(sql) {
  try {
    const startRes = await athenaClient.send(new StartQueryExecutionCommand({
      QueryString: sql,
      QueryExecutionContext: { Database: DATABASE },
      WorkGroup: WORKGROUP,
      ResultConfiguration: { OutputLocation: OUTPUT_BUCKET },
    }));
    const queryId = startRes.QueryExecutionId;
    await waitForQuery(queryId);
    return await getQueryResults(queryId);
  } catch (err) {
    console.error("Athena query error:", err);
    return [];
  }
}

// ─── DASHBOARD QUERIES ───────────────────────────────────────────────────────

export async function fetchKPIs(startDate, endDate, dealer) {
  const dealerClause = dealer && dealer !== "All Dealers" ? `AND DEALER_NAME = '${dealer.replace(/'/g, "''")}'` : "";
  const dateFilter = `EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}'`;
  const prevEnd = new Date(startDate); prevEnd.setDate(prevEnd.getDate() - 1);
  const days = Math.ceil((new Date(endDate) - new Date(startDate)) / 86400000) + 1;
  const prevStart = new Date(prevEnd); prevStart.setDate(prevStart.getDate() - days + 1);
  const prevFilter = `EFFECTIVE_DATE BETWEEN '${prevStart.toISOString().slice(0,10)}' AND '${prevEnd.toISOString().slice(0,10)}'`;

  const [curr, prev] = await Promise.all([
    runQuery(`SELECT
      COALESCE(SUM(TOTAL_AMOUNT),0) AS REVENUE,
      COUNT(DISTINCT ORDER_ID) AS ORDERS,
      COALESCE(SUM(TOTAL_AMOUNT)/NULLIF(COUNT(DISTINCT ORDER_ID),0),0) AS AOV,
      COUNT(DISTINCT DEALER_ID) AS DEALERS,
      COUNT(DISTINCT PRODUCT_ID) AS PRODUCTS,
      COALESCE(SUM(QUANTITY),0) AS UNITS
      FROM FACT_ORDER_HISTORY_VW
      WHERE CURRENT_FLAG='Y' AND ${dateFilter} ${dealerClause}`),
    runQuery(`SELECT
      COALESCE(SUM(TOTAL_AMOUNT),0) AS REVENUE,
      COUNT(DISTINCT ORDER_ID) AS ORDERS,
      COALESCE(SUM(TOTAL_AMOUNT)/NULLIF(COUNT(DISTINCT ORDER_ID),0),0) AS AOV,
      COUNT(DISTINCT DEALER_ID) AS DEALERS,
      COUNT(DISTINCT PRODUCT_ID) AS PRODUCTS,
      COALESCE(SUM(QUANTITY),0) AS UNITS
      FROM FACT_ORDER_HISTORY_VW
      WHERE CURRENT_FLAG='Y' AND ${prevFilter} ${dealerClause}`),
  ]);
  return { current: curr[0] || {}, previous: prev[0] || {} };
}

export async function fetchSalesByProductType(startDate, endDate, dealerClause) {
  return runQuery(`SELECT p.PRODUCT_TYPE, COUNT(DISTINCT f.ORDER_ID) AS ORDER_COUNT, SUM(f.TOTAL_AMOUNT) AS TOTAL_SALES
    FROM FACT_ORDER_HISTORY_VW f
    JOIN DIM_PRODUCT_VW p ON f.PRODUCT_ID=p.PRODUCT_ID AND p.CURRENT_FLAG='Y'
    WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY p.PRODUCT_TYPE ORDER BY TOTAL_SALES DESC`);
}

export async function fetchOrderStatus(startDate, endDate, dealerClause) {
  return runQuery(`SELECT ORDER_STATUS, COUNT(DISTINCT ORDER_ID) AS ORDER_COUNT
    FROM FACT_ORDER_HISTORY_VW
    WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY ORDER_STATUS ORDER BY ORDER_COUNT DESC`);
}

export async function fetchMonthlyRevenue(startDate, endDate, dealerClause) {
  return runQuery(`SELECT DATE_FORMAT(DATE_TRUNC('month', EFFECTIVE_DATE),'%Y-%m') AS MONTH,
    SUM(TOTAL_AMOUNT)/1000000.0 AS REVENUE_M
    FROM FACT_ORDER_HISTORY_VW
    WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY 1 ORDER BY 1`);
}

export async function fetchMonthlyOrders(startDate, endDate, dealerClause) {
  return runQuery(`SELECT DATE_FORMAT(DATE_TRUNC('month', EFFECTIVE_DATE),'%Y-%m') AS MONTH,
    COUNT(DISTINCT ORDER_ID) AS ORDERS
    FROM FACT_ORDER_HISTORY_VW
    WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY 1 ORDER BY 1`);
}

export async function fetchCategoryPerformance(startDate, endDate, dealerClause) {
  return runQuery(`SELECT DEALER_NAME, SUM(TOTAL_AMOUNT)/1000000.0 AS REVENUE_M
    FROM FACT_ORDER_HISTORY_VW
    WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY DEALER_NAME ORDER BY REVENUE_M DESC LIMIT 10`);
}

export async function fetchDealerPerformance(startDate, endDate, dealerClause) {
  return runQuery(`SELECT f.DEALER_NAME, d.DEALER_TYPE,
    COUNT(DISTINCT f.ORDER_ID) AS ORDERS,
    SUM(f.TOTAL_AMOUNT)/1000000.0 AS REVENUE_MILLIONS,
    SUM(f.TOTAL_AMOUNT)/NULLIF(COUNT(DISTINCT f.ORDER_ID),0) AS AVG_ORDER_VALUE,
    COUNT(DISTINCT f.PRODUCT_ID) AS PRODUCT_COUNT
    FROM FACT_ORDER_HISTORY_VW f
    JOIN DIM_DEALER_VW d ON f.DEALER_ID=d.DEALER_ID AND d.CURRENT_FLAG='Y'
    WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY f.DEALER_NAME, d.DEALER_TYPE ORDER BY REVENUE_MILLIONS DESC`);
}

export async function fetchDealerTypeDist(startDate, endDate, dealerClause) {
  return runQuery(`SELECT d.DEALER_TYPE, COUNT(DISTINCT f.DEALER_ID) AS DEALER_COUNT, SUM(f.TOTAL_AMOUNT) AS REVENUE
    FROM FACT_ORDER_HISTORY_VW f
    JOIN DIM_DEALER_VW d ON f.DEALER_ID=d.DEALER_ID AND d.CURRENT_FLAG='Y'
    WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY d.DEALER_TYPE`);
}

export async function fetchUniqueProducts(startDate, endDate, dealerClause) {
  return runQuery(`SELECT DEALER_NAME, COUNT(DISTINCT PRODUCT_ID) AS UNIQUE_PRODUCTS
    FROM FACT_ORDER_HISTORY_VW
    WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY DEALER_NAME ORDER BY UNIQUE_PRODUCTS DESC LIMIT 15`);
}

export async function fetchRevByDealer(startDate, endDate, dealerClause) {
  return runQuery(`SELECT DEALER_NAME, SUM(TOTAL_AMOUNT)/1000000.0 AS REVENUE_M
    FROM FACT_ORDER_HISTORY_VW
    WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY DEALER_NAME ORDER BY REVENUE_M DESC LIMIT 15`);
}

export async function fetchConfigRevenue(startDate, endDate, dealerClause) {
  return runQuery(`SELECT CONFIG_NAME, SUM(TOTAL_AMOUNT)/1000000.0 AS REVENUE_M
    FROM FACT_ORDER_HISTORY_VW
    WHERE CURRENT_FLAG='Y' AND CONFIG_NAME IS NOT NULL AND EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY CONFIG_NAME ORDER BY REVENUE_M DESC`);
}

export async function fetchConfigAOV(startDate, endDate, dealerClause) {
  return runQuery(`SELECT CONFIG_NAME, SUM(TOTAL_AMOUNT)/NULLIF(COUNT(DISTINCT ORDER_ID),0) AS AVG_ORDER_VALUE
    FROM FACT_ORDER_HISTORY_VW
    WHERE CURRENT_FLAG='Y' AND CONFIG_NAME IS NOT NULL AND EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY CONFIG_NAME ORDER BY AVG_ORDER_VALUE DESC`);
}

export async function fetchConfigByDealerType(startDate, endDate, dealerClause) {
  return runQuery(`SELECT d.DEALER_TYPE, f.CONFIG_NAME,
    COUNT(DISTINCT f.ORDER_ID) AS ORDER_COUNT, SUM(f.TOTAL_AMOUNT)/1000000.0 AS REVENUE_M
    FROM FACT_ORDER_HISTORY_VW f
    JOIN DIM_DEALER_VW d ON f.DEALER_ID=d.DEALER_ID AND d.CURRENT_FLAG='Y'
    WHERE f.CURRENT_FLAG='Y' AND f.CONFIG_NAME IS NOT NULL AND f.EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY d.DEALER_TYPE, f.CONFIG_NAME ORDER BY d.DEALER_TYPE, REVENUE_M DESC`);
}

export async function fetchTopFeatures(startDate, endDate, dealerClause) {
  return runQuery(`SELECT fe.FEATURE_NAME, SUM(f.TOTAL_AMOUNT)/1000000.0 AS REVENUE_M
    FROM FACT_ORDER_HISTORY_VW f
    LEFT JOIN DIM_FEATURE_VW fe ON f.FEATURE_ID=fe.FEATURE_ID AND fe.CURRENT_FLAG='Y'
    WHERE f.CURRENT_FLAG='Y' AND f.FEATURE_ID IS NOT NULL AND f.EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY fe.FEATURE_NAME ORDER BY REVENUE_M DESC LIMIT 10`);
}

export async function fetchFeaturesByDealerType(startDate, endDate, dealerClause) {
  return runQuery(`SELECT d.DEALER_TYPE, fe.FEATURE_NAME, SUM(f.TOTAL_AMOUNT)/1000000.0 AS REVENUE_M
    FROM FACT_ORDER_HISTORY_VW f
    JOIN DIM_DEALER_VW d ON f.DEALER_ID=d.DEALER_ID AND d.CURRENT_FLAG='Y'
    LEFT JOIN DIM_FEATURE_VW fe ON f.FEATURE_ID=fe.FEATURE_ID AND fe.CURRENT_FLAG='Y'
    WHERE f.CURRENT_FLAG='Y' AND f.FEATURE_ID IS NOT NULL AND fe.FEATURE_NAME IS NOT NULL AND f.EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY d.DEALER_TYPE, fe.FEATURE_NAME ORDER BY REVENUE_M DESC`);
}

export async function fetchFeaturesByProductType(startDate, endDate, dealerClause) {
  return runQuery(`SELECT p.PRODUCT_TYPE, fe.FEATURE_NAME, SUM(f.TOTAL_AMOUNT)/1000000.0 AS REVENUE_M
    FROM FACT_ORDER_HISTORY_VW f
    JOIN DIM_PRODUCT_VW p ON f.PRODUCT_ID=p.PRODUCT_ID AND p.CURRENT_FLAG='Y'
    LEFT JOIN DIM_FEATURE_VW fe ON f.FEATURE_ID=fe.FEATURE_ID AND fe.CURRENT_FLAG='Y'
    WHERE f.CURRENT_FLAG='Y' AND f.FEATURE_ID IS NOT NULL AND p.PRODUCT_TYPE IS NOT NULL AND fe.FEATURE_NAME IS NOT NULL AND f.EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ${dealerClause}
    GROUP BY p.PRODUCT_TYPE, fe.FEATURE_NAME ORDER BY REVENUE_M DESC`);
}

export async function fetchDealers(startDate, endDate) {
  return runQuery(`SELECT DISTINCT DEALER_NAME FROM FACT_ORDER_HISTORY_VW
    WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN '${startDate}' AND '${endDate}' ORDER BY DEALER_NAME`);
}

// ─── ORDER LIFECYCLE QUERIES ──────────────────────────────────────────────────

export async function fetchOrderIds() {
  return runQuery(`SELECT DISTINCT ORDER_ID FROM FACT_ORDER_HISTORY_VW ORDER BY ORDER_ID DESC LIMIT 200`);
}

export async function fetchOrderSummary(orderIds) {
  const ids = orderIds.map(id => `'${id.replace(/'/g,"''")}'`).join(",");
  return runQuery(`SELECT ORDER_ID,
    MAX(CASE WHEN ORDER_STATUS='PLACED' THEN ORDER_STATUS_DATE END) AS ORDER_DATE,
    MAX(CASE WHEN CURRENT_FLAG='Y' THEN ORDER_STATUS END) AS LATEST_STATUS,
    MAX(DEALER_ID) AS DEALER_ID, MAX(DEALER_NAME) AS DEALER_NAME,
    SUM(QUANTITY) AS TOTAL_QUANTITY, SUM(TOTAL_AMOUNT) AS TOTAL_AMOUNT,
    COUNT(DISTINCT PRODUCT_ID) AS PRODUCT_COUNT,
    MAX(EXPECTED_DELIVERY_DATE) AS EXPECTED_DELIVERY_DATE
    FROM FACT_ORDER_HISTORY_VW WHERE ORDER_ID IN (${ids}) GROUP BY ORDER_ID`);
}

export async function fetchOrderStatusDetails(orderIds) {
  const ids = orderIds.map(id => `'${id.replace(/'/g,"''")}'`).join(",");
  return runQuery(`SELECT ORDER_ID, ORDER_STATUS, ORDER_STATUS_DATE
    FROM FACT_ORDER_HISTORY_VW WHERE ORDER_ID IN (${ids})
    GROUP BY ORDER_ID, ORDER_STATUS, ORDER_STATUS_DATE
    ORDER BY ORDER_ID, CASE UPPER(ORDER_STATUS) WHEN 'PLACED' THEN 1 WHEN 'CONFIRMED' THEN 2 WHEN 'SHIPPED' THEN 3 WHEN 'DELIVERED' THEN 4 ELSE 5 END`);
}

export async function fetchProductInfo(orderIds) {
  const ids = orderIds.map(id => `'${id.replace(/'/g,"''")}'`).join(",");
  return runQuery(`SELECT c.PRODUCT_ID, c.PRODUCT_NAME, c.MATERIAL_TYPE, c.PRODUCT_TYPE,
    c.PRODUCT_CATEGORY, c.CONFIG_NAME, c.CONFIG_TYPE, c.UNIT_PRICE, o.QUANTITY AS TOTAL_QUANTITY_ORDERED
    FROM PRODUCT_CATALOG_VW c
    JOIN (SELECT PRODUCT_ID, CONFIG_ID, QUANTITY FROM FACT_ORDER_HISTORY_VW WHERE ORDER_ID IN (${ids})) o
      ON c.PRODUCT_ID=o.PRODUCT_ID AND c.CONFIG_ID=o.CONFIG_ID`);
}

export async function fetchDealerInfo(dealerIds) {
  const ids = dealerIds.map(id => `'${id.replace(/'/g,"''")}'`).join(",");
  return runQuery(`SELECT f.DEALER_ID, f.DEALER_NAME, d.DEALER_TYPE, d.COUNTRY, d.REGION, d.CITY,
    SUM(k.ORDER_COUNT) AS TOTAL_ORDERS, SUM(k.REVENUE) AS TOTAL_REVENUE
    FROM FACT_ORDER_HISTORY_VW f
    LEFT JOIN DEALER_ORDER_KPI_VW k ON f.DEALER_ID=k.DEALER_ID
    LEFT JOIN DIM_DEALER_VW d ON f.DEALER_ID=d.DEALER_ID AND d.CURRENT_FLAG='Y'
    WHERE f.DEALER_ID IN (${ids})
    GROUP BY f.DEALER_ID, f.DEALER_NAME, d.DEALER_TYPE, d.COUNTRY, d.REGION, d.CITY`);
}

export async function fetchBOM(productIds) {
  const ids = productIds.map(id => `'${id.replace(/'/g,"''")}'`).join(",");
  return runQuery(`SELECT PARENT_PRODUCT, PARENT_PRODUCT_NAME, CHILD_PRODUCT, CHILD_PRODUCT_NAME,
    QUANTITY_PER_ASSEMBLY, UNIT_OF_MEASURE, SCRAP_FACTOR
    FROM PRODUCT_BOM_VW WHERE PARENT_PRODUCT IN (${ids})`);
}

// ─── FORECAST QUERIES ─────────────────────────────────────────────────────────

export async function fetchForecastQty(productClause, monthClause) {
  return runQuery(`SELECT DATE_FORMAT(DATE_TRUNC('month', FORECAST_PERIOD_END),'%Y-%m') AS MONTH,
    SUM(FORECAST_QUANTITY) AS QTY
    FROM PRODUCT_FORECAST_KPI_VW F WHERE 1=1 ${productClause} ${monthClause}
    GROUP BY 1 ORDER BY 1`);
}

export async function fetchForecastRev(productClause, monthClause) {
  return runQuery(`SELECT DATE_FORMAT(DATE_TRUNC('month', FORECAST_PERIOD_END),'%Y-%m') AS MONTH,
    SUM(FORECAST_REVENUE)/1000000.0 AS REVENUE_M
    FROM PRODUCT_FORECAST_KPI_VW F WHERE 1=1 ${productClause} ${monthClause}
    GROUP BY 1 ORDER BY 1`);
}

export async function fetchProductMix(productClause, monthClause) {
  return runQuery(`SELECT p.PRODUCT_CATEGORY, p.PRODUCT_TYPE,
    SUM(f.FORECAST_QUANTITY) AS FORECAST_QUANTITY,
    SUM(f.FORECAST_REVENUE)/1000000.0 AS FORECAST_REVENUE_M
    FROM PRODUCT_FORECAST_KPI_VW f
    LEFT JOIN DIM_PRODUCT_VW p ON f.PRODUCT_ID=p.PRODUCT_ID AND p.CURRENT_FLAG='Y'
    WHERE 1=1 ${productClause} ${monthClause} AND p.PRODUCT_CATEGORY IS NOT NULL
    GROUP BY p.PRODUCT_CATEGORY, p.PRODUCT_TYPE ORDER BY FORECAST_REVENUE_M DESC`);
}

export async function fetchRevenueShare(productClause, monthClause) {
  return runQuery(`SELECT p.PRODUCT_FAMILY, SUM(f.FORECAST_REVENUE)/1000000.0 AS REVENUE_M
    FROM PRODUCT_FORECAST_KPI_VW f
    LEFT JOIN DIM_PRODUCT_VW p ON f.PRODUCT_ID=p.PRODUCT_ID AND p.CURRENT_FLAG='Y'
    WHERE 1=1 ${productClause} ${monthClause} AND p.PRODUCT_FAMILY IS NOT NULL
    GROUP BY p.PRODUCT_FAMILY ORDER BY REVENUE_M DESC LIMIT 10`);
}

export async function fetchForecastProducts() {
  return runQuery(`SELECT DISTINCT PRODUCT_ID, PRODUCT_NAME FROM PRODUCT_FORECAST_KPI_VW ORDER BY PRODUCT_NAME`);
}

export async function fetchForecastMonths() {
  return runQuery(`SELECT DISTINCT DATE_FORMAT(DATE_TRUNC('month', FORECAST_PERIOD_END),'%Y-%m') AS MONTH
    FROM PRODUCT_FORECAST_KPI_VW ORDER BY MONTH`);
}

// ─── AI AGENT QUERIES ─────────────────────────────────────────────────────────

export async function fetchPipelineFunnel(fracClause) {
  return runQuery(`WITH date_bounds AS (
    SELECT MIN(EFFECTIVE_DATE) AS dt_min, MAX(EFFECTIVE_DATE) AS dt_max,
      DATE_DIFF('day', MIN(EFFECTIVE_DATE), MAX(EFFECTIVE_DATE)) AS total_days
    FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y'),
  analysis_window AS (
    SELECT dt_max, ${fracClause} AS a_start FROM date_bounds),
  orders_in_window AS (
    SELECT DISTINCT f.ORDER_ID FROM FACT_ORDER_HISTORY_VW f
    CROSS JOIN analysis_window aw
    WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE BETWEEN aw.a_start AND aw.dt_max),
  stage_reach AS (
    SELECT f.ORDER_ID,
      MAX(CASE WHEN UPPER(f.ORDER_STATUS)='PLACED' THEN 1 ELSE 0 END) AS rp,
      MAX(CASE WHEN UPPER(f.ORDER_STATUS)='CONFIRMED' THEN 1 ELSE 0 END) AS rc,
      MAX(CASE WHEN UPPER(f.ORDER_STATUS)='SHIPPED' THEN 1 ELSE 0 END) AS rs,
      MAX(CASE WHEN UPPER(f.ORDER_STATUS)='DELIVERED' THEN 1 ELSE 0 END) AS rd
    FROM FACT_ORDER_HISTORY_VW f INNER JOIN orders_in_window o ON f.ORDER_ID=o.ORDER_ID
    WHERE f.CURRENT_FLAG='Y' GROUP BY f.ORDER_ID)
  SELECT SUM(rp) AS PLACED_COUNT, SUM(rc) AS CONFIRMED_COUNT,
    SUM(rs) AS SHIPPED_COUNT, SUM(rd) AS DELIVERED_COUNT, COUNT(*) AS TOTAL_ORDERS
  FROM stage_reach`);
}

export async function fetchDealerStageDropoff(fracClause, minOrders) {
  return runQuery(`WITH date_bounds AS (
    SELECT MIN(EFFECTIVE_DATE) AS dt_min, MAX(EFFECTIVE_DATE) AS dt_max,
      DATE_DIFF('day', MIN(EFFECTIVE_DATE), MAX(EFFECTIVE_DATE)) AS total_days
    FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y'),
  analysis_window AS (SELECT dt_max, ${fracClause} AS a_start FROM date_bounds),
  dealer_orders AS (
    SELECT DISTINCT f.ORDER_ID, f.DEALER_NAME FROM FACT_ORDER_HISTORY_VW f
    CROSS JOIN analysis_window aw WHERE f.CURRENT_FLAG='Y'
    AND f.EFFECTIVE_DATE BETWEEN aw.a_start AND aw.dt_max),
  dealer_stage_reach AS (
    SELECT d.DEALER_NAME, d.ORDER_ID,
      MAX(CASE WHEN UPPER(f.ORDER_STATUS)='PLACED' THEN 1 ELSE 0 END) AS rp,
      MAX(CASE WHEN UPPER(f.ORDER_STATUS)='CONFIRMED' THEN 1 ELSE 0 END) AS rc,
      MAX(CASE WHEN UPPER(f.ORDER_STATUS)='SHIPPED' THEN 1 ELSE 0 END) AS rs,
      MAX(CASE WHEN UPPER(f.ORDER_STATUS)='DELIVERED' THEN 1 ELSE 0 END) AS rd
    FROM dealer_orders d JOIN FACT_ORDER_HISTORY_VW f ON d.ORDER_ID=f.ORDER_ID
    WHERE f.CURRENT_FLAG='Y' GROUP BY d.DEALER_NAME, d.ORDER_ID)
  SELECT DEALER_NAME, COUNT(*) AS TOTAL_ORDERS,
    SUM(rp) AS PLACED_CNT, SUM(rc) AS CONFIRMED_CNT,
    SUM(rs) AS SHIPPED_CNT, SUM(rd) AS DELIVERED_CNT,
    ROUND(SUM(rc)*100.0/NULLIF(SUM(rp),0),1) AS CONFIRMED_PCT,
    ROUND(SUM(rs)*100.0/NULLIF(SUM(rp),0),1) AS SHIPPED_PCT,
    ROUND(SUM(rd)*100.0/NULLIF(SUM(rp),0),1) AS DELIVERED_PCT
  FROM dealer_stage_reach GROUP BY DEALER_NAME
  HAVING COUNT(*) >= ${minOrders} ORDER BY DELIVERED_PCT ASC`);
}

export async function fetchOrderVelocity(splitFrac, dropThresh, maxDealers) {
  return runQuery(`WITH date_bounds AS (
    SELECT MIN(EFFECTIVE_DATE) AS dt_min, MAX(EFFECTIVE_DATE) AS dt_max,
      DATE_DIFF('day', MIN(EFFECTIVE_DATE), MAX(EFFECTIVE_DATE)) AS total_days
    FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y'),
  split_date AS (
    SELECT dt_min, dt_max,
      DATE_ADD('day', CAST(ROUND(total_days * ${1 - splitFrac}, 0) AS INTEGER), dt_min) AS split_pt,
      ROUND(total_days * ${1 - splitFrac}, 0) AS prior_days,
      ROUND(total_days * ${splitFrac}, 0) AS curr_days
    FROM date_bounds),
  current_p AS (
    SELECT f.DEALER_NAME, COUNT(DISTINCT f.ORDER_ID) AS CURR_ORDERS,
      COUNT(DISTINCT f.PRODUCT_ID) AS CURR_PRODUCTS, SUM(f.TOTAL_AMOUNT) AS CURR_REV, s.curr_days
    FROM FACT_ORDER_HISTORY_VW f CROSS JOIN split_date s
    WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE > s.split_pt AND f.EFFECTIVE_DATE <= s.dt_max
    GROUP BY f.DEALER_NAME, s.curr_days),
  prior_p AS (
    SELECT f.DEALER_NAME, COUNT(DISTINCT f.ORDER_ID) AS PREV_ORDERS,
      COUNT(DISTINCT f.PRODUCT_ID) AS PREV_PRODUCTS, SUM(f.TOTAL_AMOUNT) AS PREV_REV, s.prior_days
    FROM FACT_ORDER_HISTORY_VW f CROSS JOIN split_date s
    WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE >= s.dt_min AND f.EFFECTIVE_DATE <= s.split_pt
    GROUP BY f.DEALER_NAME, s.prior_days)
  SELECT c.DEALER_NAME, COALESCE(p.PREV_ORDERS,0) AS PREV_ORDERS,
    COALESCE(c.CURR_ORDERS,0) AS CURR_ORDERS, COALESCE(p.PREV_PRODUCTS,0) AS PREV_PRODUCTS,
    COALESCE(c.CURR_PRODUCTS,0) AS CURR_PRODUCTS, COALESCE(p.PREV_REV,0) AS PREV_REV,
    COALESCE(c.CURR_REV,0) AS CURR_REV,
    ROUND(COALESCE(c.CURR_ORDERS,0)*1.0/NULLIF(c.curr_days,0),4) AS CURR_ORDERS_PER_DAY,
    ROUND(COALESCE(p.PREV_ORDERS,0)*1.0/NULLIF(p.prior_days,0),4) AS PREV_ORDERS_PER_DAY,
    CASE WHEN COALESCE(p.PREV_ORDERS,0)>0
      THEN ROUND((COALESCE(c.CURR_ORDERS,0)-p.PREV_ORDERS)*1.0/p.PREV_ORDERS*100,1)
      ELSE NULL END AS ORDER_CHANGE_PCT
  FROM current_p c LEFT JOIN prior_p p ON c.DEALER_NAME=p.DEALER_NAME
  WHERE COALESCE(p.PREV_ORDERS,0)>0
    AND COALESCE(c.CURR_ORDERS,0) < p.PREV_ORDERS*(1-${dropThresh}/100.0)
  ORDER BY ORDER_CHANGE_PCT ASC LIMIT ${maxDealers}`);
}
