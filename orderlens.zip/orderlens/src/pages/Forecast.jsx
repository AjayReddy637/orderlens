import React, { useState, useEffect } from "react";
import { fetchForecastQty, fetchForecastRev, fetchProductMix, fetchRevenueShare, fetchForecastProducts, fetchForecastMonths } from "../services/athena";
import { HBarChart, VBarChart, ScatterChart } from "../components/Charts";

export default function Forecast() {
  const [products, setProducts]     = useState([]);
  const [months, setMonths]         = useState([]);
  const [selProducts, setSelProd]   = useState([]);
  const [selMonth, setSelMonth]     = useState("All");
  const [fcstQty, setFcstQty]       = useState([]);
  const [fcstRev, setFcstRev]       = useState([]);
  const [prodMix, setProdMix]       = useState([]);
  const [revShare, setRevShare]     = useState([]);
  const [loading, setLoading]       = useState(false);

  useEffect(() => {
    Promise.all([fetchForecastProducts(), fetchForecastMonths()]).then(([p, m]) => {
      setProducts(p.map(r => ({ id: r.PRODUCT_ID || r.product_id, name: r.PRODUCT_NAME || r.product_name })));
      setMonths(m.map(r => r.MONTH || r.month || Object.values(r)[0]));
    });
  }, []);

  useEffect(() => {
    setLoading(true);
    const pc = selProducts.length
      ? `AND F.PRODUCT_ID IN (${selProducts.map(id => `'${id}'`).join(",")})` : "";
    const mc = selMonth !== "All"
      ? `AND DATE_FORMAT(DATE_TRUNC('month', F.FORECAST_PERIOD_END),'%Y-%m') = '${selMonth}'` : "";

    Promise.all([
      fetchForecastQty(pc, mc),
      fetchForecastRev(pc, mc),
      fetchProductMix(pc, mc),
      fetchRevenueShare(pc, mc),
    ]).then(([q, r, pm, rs]) => {
      setFcstQty(q); setFcstRev(r); setProdMix(pm); setRevShare(rs);
      setLoading(false);
    });
  }, [selProducts, selMonth]);

  const qtyLabels = fcstQty.map(r => r.MONTH || r.month || "");
  const qtyData   = fcstQty.map(r => +(r.QTY || r.qty || 0));
  const revLabels = fcstRev.map(r => r.MONTH || r.month || "");
  const revData   = fcstRev.map(r => +(r.REVENUE_M || r.revenue_m || 0));

  const mixTypes = [...new Set(prodMix.map(r => r.PRODUCT_TYPE || r.product_type || "Other"))];
  const mixDS = mixTypes.map(t => ({
    label: t,
    data: prodMix
      .filter(r => (r.PRODUCT_TYPE || r.product_type) === t)
      .map(r => ({ x: +(r.FORECAST_QUANTITY || 0), y: +(r.FORECAST_REVENUE_M || 0) })),
  }));

  const rsLabels = revShare.map(r => r.PRODUCT_FAMILY || r.product_family || "");
  const rsData   = revShare.map(r => +(r.REVENUE_M || r.revenue_m || 0));

  function toggleProduct(id) {
    setSelProd(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  }

  return (
    <div className="page-container">
      <div className="welcome-title">Sales Forecast</div>
      <div className="section-sub">Projected demand and revenue</div>

      <div className="forecast-filter">
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: "#64748b" }}>Filter by Product</div>
          <div style={{ background: "#fff", border: "1.5px solid #E5E7EB", borderRadius: 8, maxHeight: 120, overflowY: "auto", minWidth: 260, padding: "4px 0" }}>
            {products.map(p => (
              <label key={p.id} style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 10px", fontSize: 12, cursor: "pointer" }}>
                <input type="checkbox" checked={selProducts.includes(p.id)} onChange={() => toggleProduct(p.id)} />
                {p.name}
              </label>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: "#64748b" }}>Filter by Month</div>
          <select className="filter-input" value={selMonth} onChange={e => setSelMonth(e.target.value)}>
            <option value="All">All</option>
            {months.map(m => <option key={m}>{m}</option>)}
          </select>
        </div>
        {loading && <div className="loading-text" style={{ marginTop: 16 }}><span className="loading-spinner" /> Loading…</div>}
      </div>

      <div className="chart-grid-2">
        <div className="chart-box">
          <div className="chart-title">Monthly Forecast Quantity</div>
          <HBarChart labels={qtyLabels} data={qtyData} color="#60A5FA" height={280} />
        </div>
        <div className="chart-box">
          <div className="chart-title">Monthly Forecast Revenue</div>
          <HBarChart labels={revLabels} data={revData} color="#4ADE80" height={280}
            formatFn={v => `$${v.toFixed(1)}M`} />
        </div>
      </div>

      <div className="chart-grid-2" style={{ marginTop: 16 }}>
        <div className="chart-box">
          <div className="chart-title">Product Mix: Quantity vs Revenue</div>
          <ScatterChart datasets={mixDS} height={340}
            xLabel="Forecast Quantity" yLabel="Revenue ($M)" />
        </div>
        <div className="chart-box">
          <div className="chart-title">Revenue Share by Product Family</div>
          <VBarChart labels={rsLabels} data={rsData} color="#60A5FA" height={340}
            formatFn={v => `$${v.toFixed(1)}M`} />
        </div>
      </div>
    </div>
  );
}
