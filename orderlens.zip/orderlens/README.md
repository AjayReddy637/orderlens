# OrderLens — React + AWS Athena + Bedrock

Full React port of the OrderLens Snowflake app.
UI matches the original 100%. Backend uses AWS Athena (queries) + Amazon Bedrock (AI).

## Project Structure

```
orderlens/
├── public/index.html
├── src/
│   ├── index.js              # Entry point
│   ├── index.css             # All CSS — exact match to Snowflake UI
│   ├── App.jsx               # Root component + routing
│   ├── components/
│   │   ├── Header.jsx        # Nav header with YASH logo
│   │   └── Charts.jsx        # Reusable Chart.js wrappers
│   ├── pages/
│   │   ├── Dashboard.jsx     # KPIs + 4 tabs (Health/Dealer/Config/Features)
│   │   ├── Genie.jsx         # AI chat with quick-analysis tiles
│   │   ├── OrderLifeCycle.jsx# Order search + detail tabs
│   │   ├── Forecast.jsx      # Forecast charts
│   │   └── AIAgents.jsx      # 3 AI agents (DropOff/Velocity/Fulfillment)
│   └── services/
│       ├── athena.js         # All AWS Athena queries
│       └── bedrock.js        # Amazon Bedrock (nova-micro-v1:0) AI calls
└── .env.example
```

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
Copy `.env.example` to `.env` and fill in your values:
```
REACT_APP_AWS_REGION=us-east-1
REACT_APP_AWS_ACCESS_KEY_ID=your_access_key
REACT_APP_AWS_SECRET_ACCESS_KEY=your_secret_key
REACT_APP_ATHENA_DATABASE=orderlens
REACT_APP_ATHENA_WORKGROUP=primary
REACT_APP_ATHENA_OUTPUT_BUCKET=s3://your-bucket/athena-results/
REACT_APP_BEDROCK_MODEL_ID=amazon.nova-micro-v1:0
REACT_APP_LOGO_URL=https://th.bing.com/th/id/OIP.Vy1yFQtg8-D1SsAxcqqtSgHaE6?w=235&h=180&c=7&r=0&o=7&dpr=1.5&pid=1.7&rm=3
```

### 3. AWS Athena setup
- Create an Athena database named `orderlens` (or match your REACT_APP_ATHENA_DATABASE)
- Create all views/tables used in the original Snowflake app:
  - `FACT_ORDER_HISTORY_VW`
  - `DIM_PRODUCT_VW`
  - `DIM_DEALER_VW`
  - `DIM_FEATURE_VW`
  - `PRODUCT_CATALOG_VW`
  - `PRODUCT_BOM_VW`
  - `DEALER_ORDER_KPI_VW`
  - `PRODUCT_FORECAST_KPI_VW`
- Set your S3 bucket for Athena query results
- Make sure the IAM user/role has permissions:
  - `athena:StartQueryExecution`
  - `athena:GetQueryExecution`
  - `athena:GetQueryResults`
  - `s3:PutObject` / `s3:GetObject` on the results bucket
  - `bedrock:InvokeModel` for `amazon.nova-micro-v1:0`

### 4. Run locally
```bash
npm start
```

### 5. Build for production
```bash
npm run build
```

## AI Model
- Model: `amazon.nova-micro-v1:0`
- Region: `us-east-1`
- Used for: Genie AI chat, Agent bottleneck analysis, re-engagement plans

## Pages

| Page | Description |
|------|-------------|
| Dashboard | KPI cards + Business Health / Dealer / Config / Features tabs |
| Genie | Quick-analysis tiles + AI chat (Bedrock) |
| Order Life Cycle | Order search, status timeline, product/dealer/BOM tabs |
| Forecast | Monthly qty/revenue + product mix + family share |
| AI Agents | Drop-Off Agent, Velocity Agent, Smart Fulfillment Agent |

## Notes
- AWS credentials should be stored in `.env` (never commit `.env` to git)
- For production, use AWS Cognito or IAM roles instead of hardcoded keys
- Athena queries use `DATE_FORMAT`, `DATE_TRUNC`, `DATE_DIFF`, `DATE_ADD` — compatible with Athena (Presto/Trino SQL)
- All Snowflake-specific functions (`TO_CHAR`, `DATEADD`, `DATEDIFF`) have been converted to Athena equivalents
