# OrderLens — EC2 Deployment Guide

## Project Structure
```
orderlens/
├── server/
│   ├── index.js        ← Express backend (handles ALL AWS calls)
│   ├── package.json
│   └── .env.example    ← Copy to .env and fill in your values
├── client/
│   ├── src/            ← React frontend (UI — unchanged)
│   ├── public/
│   └── package.json
├── deploy.sh           ← Run this once to deploy everything
└── package.json
```

## How it works
- **Express server** (port 3001) handles all Athena + Bedrock AWS calls securely
- **React client** is built and served by the Express server as static files
- **No CORS issues** — everything goes through the same server
- **One port** — open port 3001 in your EC2 Security Group

## Step 1 — Upload this folder to EC2
From your Windows laptop CMD:
```cmd
scp -i "your-key.pem" -r orderlens ec2-user@YOUR_EC2_IP:/home/ec2-user/
```

## Step 2 — SSH into EC2
```bash
ssh -i "your-key.pem" ec2-user@YOUR_EC2_IP
cd orderlens
```

## Step 3 — Create .env file
```bash
cp server/.env.example server/.env
nano server/.env
```

Fill in these values:
```
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your_actual_access_key
AWS_SECRET_ACCESS_KEY=your_actual_secret_key
ATHENA_DATABASE=orderlens
ATHENA_WORKGROUP=primary
ATHENA_OUTPUT_BUCKET=s3://yignite-orderlens-miniature-landing/athena-results/
BEDROCK_MODEL_ID=amazon.nova-micro-v1:0
PORT=3001
```
Press Ctrl+X → Y → Enter to save.

## Step 4 — Run deploy script
```bash
bash deploy.sh
```

This automatically:
- Installs Node.js
- Installs all dependencies
- Builds the React app
- Starts the server with PM2 (stays running forever)

## Step 5 — Open EC2 Security Group port 3001
AWS Console → EC2 → Security Groups → Inbound Rules → Add Rule:
- Type: Custom TCP
- Port: 3001
- Source: 0.0.0.0/0

## Step 6 — Access the app
```
http://YOUR_EC2_PUBLIC_IP:3001
```

## Useful commands after deployment
```bash
pm2 status              # check running status
pm2 logs orderlens      # view live logs
pm2 restart orderlens   # restart after code changes
pm2 stop orderlens      # stop the app
```
