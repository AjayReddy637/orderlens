#!/bin/bash
# ============================================================
# OrderLens EC2 Deploy Script
# Run this script inside your EC2 orderlens folder
# Usage: bash deploy.sh
# ============================================================

set -e
echo ""
echo "========================================"
echo "  OrderLens EC2 Deployment Script"
echo "========================================"
echo ""

# Step 1: Install Node.js if not present
if ! command -v node &> /dev/null; then
  echo "📦 Installing Node.js 20..."
  curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
  sudo yum install -y nodejs
  echo "✅ Node.js installed: $(node -v)"
else
  echo "✅ Node.js already installed: $(node -v)"
fi

# Step 2: Install server dependencies
echo ""
echo "📦 Installing server dependencies..."
cd server && npm install && cd ..
echo "✅ Server dependencies installed"

# Step 3: Install client dependencies
echo ""
echo "📦 Installing client dependencies..."
cd client && npm install
echo "✅ Client dependencies installed"

# Step 4: Build React app
echo ""
echo "🔨 Building React app..."
npm run build
cd ..
echo "✅ React app built successfully"

# Step 5: Install PM2 if not present
if ! command -v pm2 &> /dev/null; then
  echo ""
  echo "📦 Installing PM2 process manager..."
  sudo npm install -g pm2
  echo "✅ PM2 installed"
fi

# Step 6: Stop existing instance if running
pm2 stop orderlens 2>/dev/null || true
pm2 delete orderlens 2>/dev/null || true

# Step 7: Start with PM2
echo ""
echo "🚀 Starting OrderLens server with PM2..."
pm2 start server/index.js --name orderlens
pm2 save
pm2 startup | tail -1 | sudo bash || true

echo ""
echo "========================================"
echo "✅ OrderLens is LIVE!"
EC2_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || echo "your-ec2-ip")
echo "🌐 Open in browser: http://${EC2_IP}:3001"
echo "========================================"
echo ""
echo "Useful commands:"
echo "  pm2 status        - check if app is running"
echo "  pm2 logs orderlens - view live logs"
echo "  pm2 restart orderlens - restart the app"
echo ""
