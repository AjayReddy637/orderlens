import React from "react";
import { Bar, Doughnut, Line, Bubble, Scatter } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement, ArcElement,
  LineElement, PointElement, BubbleController, ScatterController,
  Title, Tooltip, Legend, Filler,
} from "chart.js";

ChartJS.register(
  CategoryScale, LinearScale, BarElement, ArcElement,
  LineElement, PointElement, BubbleController, ScatterController,
  Title, Tooltip, Legend, Filler
);

const COLORS = ["#4ADE80","#FBBF24","#60A5FA","#F87171","#A78BFA","#F472B6","#34D399","#FB923C"];

const baseOpts = {
  responsive: true, maintainAspectRatio: false,
  plugins: { legend: { display: false } },
};

export function HBarChart({ labels, data, color = "#60A5FA", height = 300, formatFn }) {
  const cfg = {
    ...baseOpts,
    indexAxis: "y",
    scales: {
      x: { grid: { display: false }, ticks: { callback: formatFn || (v => v) } },
      y: { grid: { display: false } },
    },
  };
  const d = {
    labels,
    datasets: [{ data, backgroundColor: color, borderRadius: 5 }],
  };
  return <div style={{ position: "relative", height }}><Bar data={d} options={cfg} /></div>;
}

export function VBarChart({ labels, data, color = "#60A5FA", height = 300, formatFn }) {
  const cfg = {
    ...baseOpts,
    scales: {
      x: { grid: { display: false }, ticks: { autoSkip: false, maxRotation: 45 } },
      y: { grid: { display: false }, ticks: { callback: formatFn || (v => v) } },
    },
  };
  const d = { labels, datasets: [{ data, backgroundColor: color, borderRadius: 5 }] };
  return <div style={{ position: "relative", height }}><Bar data={d} options={cfg} /></div>;
}

export function GroupedBarChart({ labels, datasets, height = 320, formatFn, horizontal = false }) {
  const cfg = {
    ...baseOpts,
    indexAxis: horizontal ? "y" : "x",
    plugins: { legend: { display: true, position: "bottom" } },
    scales: {
      x: { grid: { display: false }, ticks: { autoSkip: false, maxRotation: horizontal ? 0 : 45 } },
      y: { grid: { display: false }, ticks: { callback: formatFn || (v => v) } },
    },
  };
  const d = {
    labels,
    datasets: datasets.map((ds, i) => ({
      ...ds, backgroundColor: COLORS[i % COLORS.length], borderRadius: 4,
    })),
  };
  return <div style={{ position: "relative", height }}><Bar data={d} options={cfg} /></div>;
}

export function DonutChart({ labels, data, colors = COLORS, height = 260 }) {
  const cfg = {
    responsive: true, maintainAspectRatio: false,
    cutout: "55%",
    plugins: { legend: { display: false } },
  };
  const d = { labels, datasets: [{ data, backgroundColor: colors.slice(0, data.length), hoverOffset: 4 }] };
  return <div style={{ position: "relative", height }}><Doughnut data={d} options={cfg} /></div>;
}

export function LineAreaChart({ labels, data, color = "#4ECDC4", fillColor = "rgba(219,234,254,0.3)", height = 220, formatFn }) {
  const cfg = {
    ...baseOpts,
    scales: {
      x: { grid: { display: false } },
      y: { grid: { display: false }, ticks: { callback: formatFn || (v => v) } },
    },
  };
  const d = {
    labels,
    datasets: [{
      data, borderColor: color, backgroundColor: fillColor,
      fill: true, tension: 0.4, pointBackgroundColor: color,
    }],
  };
  return <div style={{ position: "relative", height }}><Line data={d} options={cfg} /></div>;
}

export function BubbleChart({ datasets, height = 340, xLabel = "", yLabel = "" }) {
  const cfg = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: true, position: "bottom" } },
    scales: {
      x: { title: { display: true, text: xLabel }, grid: { display: false } },
      y: { title: { display: true, text: yLabel }, grid: { display: false } },
    },
  };
  const d = { datasets: datasets.map((ds, i) => ({ ...ds, backgroundColor: COLORS[i % COLORS.length] + "b0" })) };
  return <div style={{ position: "relative", height }}><Bubble data={d} options={cfg} /></div>;
}

export function ScatterChart({ datasets, height = 340, xLabel = "", yLabel = "" }) {
  const cfg = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: true, position: "bottom" } },
    scales: {
      x: { title: { display: true, text: xLabel }, grid: { display: false } },
      y: { title: { display: true, text: yLabel }, grid: { display: false } },
    },
  };
  const d = { datasets: datasets.map((ds, i) => ({ ...ds, backgroundColor: COLORS[i % COLORS.length], pointRadius: 10 })) };
  return <div style={{ position: "relative", height }}><Scatter data={d} options={cfg} /></div>;
}

export function DonutLegend({ items }) {
  return (
    <div className="donut-legend">
      {items.map((item, i) => (
        <span key={i} className="legend-item">
          <span className="legend-dot" style={{ background: item.color || COLORS[i % COLORS.length] }} />
          {item.label}
        </span>
      ))}
    </div>
  );
}
