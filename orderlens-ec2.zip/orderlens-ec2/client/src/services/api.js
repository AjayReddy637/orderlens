const BASE = "/api";

async function post(endpoint, body = {}) {
  const res = await fetch(`${BASE}${endpoint}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || res.statusText);
  }
  return res.json();
}

async function get(endpoint, params = {}) {
  const qs = new URLSearchParams(params).toString();
  const res = await fetch(`${BASE}${endpoint}${qs ? "?" + qs : ""}`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || res.statusText);
  }
  return res.json();
}

// ── DASHBOARD ──────────────────────────────────────────────────────────────────
export async function fetchKPIs(startDate, endDate, dealer) {
  const dc = dealer && dealer !== "All Dealers" ? `AND DEALER_NAME = '${dealer.replace(/'/g, "''")}'` : "";
  const days = Math.ceil((new Date(endDate) - new Date(startDate)) / 86400000) + 1;
  const prevEnd = new Date(startDate); prevEnd.setDate(prevEnd.getDate() - 1);
  const prevStart = new Date(prevEnd); prevStart.setDate(prevStart.getDate() - days + 1);
  return post("/dashboard/kpis", {
    startDate, endDate,
    prevStart: prevStart.toISOString().slice(0, 10),
    prevEnd: prevEnd.toISOString().slice(0, 10),
    dealerClause: dc,
  });
}

export async function fetchDealers(startDate, endDate) {
  const r = await get("/dashboard/dealers", { startDate, endDate });
  return r.data || [];
}

export async function fetchSalesByProductType(startDate, endDate, dc) {
  const r = await post("/dashboard/sales-by-type", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchOrderStatus(startDate, endDate, dc) {
  const r = await post("/dashboard/order-status", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchMonthlyRevenue(startDate, endDate, dc) {
  const r = await post("/dashboard/monthly-revenue", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchMonthlyOrders(startDate, endDate, dc) {
  const r = await post("/dashboard/monthly-orders", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchCategoryPerformance(startDate, endDate, dc) {
  const r = await post("/dashboard/category-performance", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchDealerPerformance(startDate, endDate, dc) {
  const r = await post("/dashboard/dealer-performance", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchDealerTypeDist(startDate, endDate, dc) {
  const r = await post("/dashboard/dealer-type-dist", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchUniqueProducts(startDate, endDate, dc) {
  const r = await post("/dashboard/unique-products", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchRevByDealer(startDate, endDate, dc) {
  const r = await post("/dashboard/rev-by-dealer", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchConfigRevenue(startDate, endDate, dc) {
  const r = await post("/dashboard/config-revenue", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchConfigAOV(startDate, endDate, dc) {
  const r = await post("/dashboard/config-aov", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchConfigByDealerType(startDate, endDate, dc) {
  const r = await post("/dashboard/config-by-dealer", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchTopFeatures(startDate, endDate, dc) {
  const r = await post("/dashboard/top-features", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchFeaturesByDealerType(startDate, endDate, dc) {
  const r = await post("/dashboard/features-by-dealer", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

export async function fetchFeaturesByProductType(startDate, endDate, dc) {
  const r = await post("/dashboard/features-by-product", { startDate, endDate, dealerClause: dc });
  return r.data || [];
}

// ── ORDER LIFECYCLE ────────────────────────────────────────────────────────────
export async function fetchOrderIds() {
  const r = await get("/orders/ids");
  return r.data || [];
}

export async function fetchOrderSummary(orderIds) {
  const r = await post("/orders/summary", { orderIds });
  return r.data || [];
}

export async function fetchOrderStatusDetails(orderIds) {
  const r = await post("/orders/status", { orderIds });
  return r.data || [];
}

export async function fetchProductInfo(orderIds) {
  const r = await post("/orders/products", { orderIds });
  return r.data || [];
}

export async function fetchDealerInfo(dealerIds) {
  const r = await post("/orders/dealers", { dealerIds });
  return r.data || [];
}

export async function fetchBOM(productIds) {
  const r = await post("/orders/bom", { productIds });
  return r.data || [];
}

// ── FORECAST ───────────────────────────────────────────────────────────────────
export async function fetchForecastProducts() {
  const r = await get("/forecast/products");
  return r.data || [];
}

export async function fetchForecastMonths() {
  const r = await get("/forecast/months");
  return r.data || [];
}

export async function fetchForecastQty(productClause, monthClause) {
  const r = await post("/forecast/qty", { productClause, monthClause });
  return r.data || [];
}

export async function fetchForecastRev(productClause, monthClause) {
  const r = await post("/forecast/rev", { productClause, monthClause });
  return r.data || [];
}

export async function fetchProductMix(productClause, monthClause) {
  const r = await post("/forecast/product-mix", { productClause, monthClause });
  return r.data || [];
}

export async function fetchRevenueShare(productClause, monthClause) {
  const r = await post("/forecast/rev-share", { productClause, monthClause });
  return r.data || [];
}

// ── AI (BEDROCK via backend) ───────────────────────────────────────────────────
export async function aiComplete(prompt) {
  const r = await post("/ai", { prompt });
  return r.text || "";
}

export async function generateGenieAnswer(question, dataContext) {
  return aiComplete(
    `You are a sales & operations business analyst.\n\nUser question: ${question}\n\nData context:\n${dataContext.slice(0, 3000)}\n\nRespond with THREE sections:\n(1) **Descriptive**: What the data shows with specific numbers.\n(2) **Prescriptive**: 3-5 SPECIFIC recommended actions with exact findings.\n(3) **Predictive**: 30-90 day forecast with confidence level (Low/Medium/High).`
  );
}

export async function generateBottleneckAnalysis(funnelData, worstDealers, stage) {
  const dealerText = worstDealers.map(d => `- ${d.DEALER_NAME}: ${parseFloat(d.DROP_PCT || 0).toFixed(1)}% drop (${d.FROM_CNT} → ${d.TO_CNT} orders)`).join("\n");
  return aiComplete(
    `You are a Sales & Operations analyst.\n\nPIPELINE:\n- PLACED: ${funnelData.placed} (100%)\n- CONFIRMED: ${funnelData.confirmed} (${funnelData.confirmedPct}%) — ${funnelData.confirmDrop}% dropout\n- SHIPPED: ${funnelData.shipped} (${funnelData.shippedPct}%) — ${funnelData.shipDrop}% dropout\n- DELIVERED: ${funnelData.delivered} (${funnelData.deliveredPct}%) — ${funnelData.delivDrop}% dropout\n\nBIGGEST BOTTLENECK: ${stage} (${funnelData.biggestDrop}% dropout)\n\nWORST DEALERS:\n${dealerText}\n\nProvide:\n1. Bottleneck diagnosis (2 sentences)\n2. Three specific fixes with outcomes\n3. One dealer-specific action\nBe direct, cite numbers.`
  );
}

export async function generateDealerFixPlan(dealer, dropPct, fromCnt, toCnt, fromStage, toStage) {
  return aiComplete(
    `Order pipeline issue for dealer '${dealer}':\nStage ${fromStage} → ${toStage}: ${dropPct.toFixed(1)}% dropout (${fromCnt} entered, only ${toCnt} progressed).\n\nWrite a specific 3-point action plan. Each point: action, who does it, expected outcome. No generic advice.`
  );
}

export async function generateVelocityPlan(dealer, prevOrders, currOrders, dropPct, prevRev, currRev, prevOpd, currOpd, catSummary, dropType) {
  return aiComplete(
    `Order velocity analysis for dealer '${dealer}':\n- Orders dropped ${Math.abs(dropPct).toFixed(1)}%: ${prevOrders} → ${currOrders}\n- Frequency: ${prevOpd.toFixed(3)}/day → ${currOpd.toFixed(3)}/day\n- Revenue: $${parseFloat(prevRev).toLocaleString()} → $${parseFloat(currRev).toLocaleString()}\n- Drop type: ${dropType}\n- Products: ${catSummary}\n\nGenerate:\n1. Root cause (2 sentences)\n2. Three re-engagement actions\n3. 30-day success metric\nBe specific, cite numbers.`
  );
}

// ── AGENT QUERIES ──────────────────────────────────────────────────────────────
export async function fetchPipelineFunnel(frac) {
  const r = await post("/agents/pipeline-funnel", { frac });
  return r.data || [];
}

export async function fetchDealerStageDropoff(frac, minOrders) {
  const r = await post("/agents/dealer-dropoff", { frac, minOrders });
  return r.data || [];
}

export async function fetchOrderVelocity(splitFrac, dropThresh, maxDealers) {
  const r = await post("/agents/order-velocity", { splitFrac, dropThresh, maxDealers });
  return r.data || [];
}

// Generic runQuery — used by Genie for data context
export async function runQuery(sql) {
  const r = await post("/query", { sql });
  return r.data || [];
}
