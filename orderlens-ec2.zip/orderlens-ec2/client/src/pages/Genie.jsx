import React, { useState, useRef, useEffect } from "react";
import { generateGenieAnswer } from "../services/api";
import { runQuery } from "../services/api";

const QUICK_ANALYSES = [
  {
    key: "revenue_overview", icon: "📊", title: "Revenue Overview",
    desc: "Track total revenue, monthly trends and major changes",
    question: "Show me total revenue YTD, monthly trends, and top 5 dealers",
  },
  {
    key: "dealer_analysis", icon: "👥", title: "Dealer Analysis",
    desc: "Understand dealer-wise revenue, concentration, and dependency",
    question: "Analyze dealer concentration and dependency",
  },
  {
    key: "product_performance", icon: "📦", title: "Product Performance",
    desc: "Identify top products, revenue, and quantity trends",
    question: "Show top products by revenue and quantity",
  },
  {
    key: "order_status", icon: "🕐", title: "Order Status",
    desc: "See order status distribution, fulfillment, and bottlenecks",
    question: "Show order status distribution by count and revenue",
  },
];

const RECENT_QUERIES_KEY = "orderlens_recent_queries";
const SAVED_INSIGHTS_KEY = "orderlens_saved_insights";

function Expander({ title, children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="expander">
      <div className="exp-header" onClick={() => setOpen(o => !o)}>
        {title}<span>{open ? "▲" : "▼"}</span>
      </div>
      {open && <div className="exp-body">{children}</div>}
    </div>
  );
}

export default function Genie() {
  const [messages, setMessages]           = useState([]);
  const [selectedTile, setSelectedTile]   = useState(null);
  const [input, setInput]                 = useState("");
  const [loading, setLoading]             = useState(false);
  const [recentQueries, setRecentQueries] = useState(() => {
    try { return JSON.parse(localStorage.getItem(RECENT_QUERIES_KEY) || "[]"); } catch { return []; }
  });
  const [savedInsights, setSavedInsights] = useState(() => {
    try { return JSON.parse(localStorage.getItem(SAVED_INSIGHTS_KEY) || "[]"); } catch { return []; }
  });
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  function saveRecent(q) {
    const updated = [q, ...recentQueries.filter(x => x !== q)].slice(0, 10);
    setRecentQueries(updated);
    localStorage.setItem(RECENT_QUERIES_KEY, JSON.stringify(updated));
  }

  function saveInsight(q) {
    const updated = [{ title: q.slice(0, 80), question: q, saved: new Date().toLocaleString() },
      ...savedInsights.filter(x => x.question !== q)].slice(0, 20);
    setSavedInsights(updated);
    localStorage.setItem(SAVED_INSIGHTS_KEY, JSON.stringify(updated));
    alert("Insight saved!");
  }

  async function runQueryForContext(question) {
    try {
      const results = await runQuery(
        `SELECT DEALER_NAME, PRODUCT_NAME, ORDER_STATUS, TOTAL_AMOUNT, QUANTITY, EFFECTIVE_DATE
         FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' ORDER BY EFFECTIVE_DATE DESC LIMIT 50`
      );
      return results.map(r => Object.values(r).join(", ")).join("\n");
    } catch { return ""; }
  }

  async function ask(question) {
    if (!question.trim()) return;
    setLoading(true);
    saveRecent(question);
    setMessages(m => [...m, { role: "user", content: question }]);
    try {
      const ctx = await runQueryForContext(question);
      const answer = await generateGenieAnswer(question, ctx);
      setMessages(m => [...m, { role: "ai", content: answer }]);
    } catch (e) {
      setMessages(m => [...m, { role: "ai", content: `Error: ${e.message}` }]);
    }
    setLoading(false);
  }

  function handleTileSelect(tile) {
    setSelectedTile(tile.key);
    ask(tile.question);
  }

  function handleSend() {
    const q = input.trim();
    if (!q) return;
    setInput("");
    ask(q);
  }

  function clearChat() {
    setMessages([]);
    setSelectedTile(null);
  }

  function exportMD() {
    const md = messages.map(m => `**${m.role === "user" ? "You" : "Genie"}:** ${m.content}`).join("\n\n");
    const blob = new Blob([md], { type: "text/markdown" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
    a.download = `genie_chat_${Date.now()}.md`; a.click();
  }

  function renderAIContent(content) {
    const lines = content.split("\n");
    return lines.map((line, i) => {
      const bold = line.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
      return <p key={i} style={{ margin: "2px 0" }} dangerouslySetInnerHTML={{ __html: bold }} />;
    });
  }

  return (
    <div className="page-container">
      <div className="genie-hero">
        <h1>Welcome to OrderLens Genie</h1>
        <p>Let Genie run one of these quick analyses for you</p>
      </div>

      {/* QUICK ANALYSIS TILES */}
      <div className="tile-grid">
        {QUICK_ANALYSES.map(tile => (
          <div key={tile.key} className={`tile-card${selectedTile === tile.key ? " selected" : ""}`}>
            <div className="tile-icon">{tile.icon}</div>
            <div className="tile-title">{tile.title}</div>
            <div className="tile-desc">{tile.desc}</div>
            <button className="tile-select-btn" onClick={() => handleTileSelect(tile)}>Select</button>
          </div>
        ))}
      </div>

      {/* TWO-COLUMN LAYOUT */}
      <div className="genie-layout">

        {/* LEFT: ANALYSIS LIBRARY */}
        <div className="genie-panel">
          <div className="lib-title">Analysis Library</div>

          <div className="lib-section">
            <div className="lib-sec-title">Recent analysis</div>
            {recentQueries.length === 0
              ? <div style={{ fontSize: 12, color: "#94a3b8", fontStyle: "italic" }}>Run analyses to see them here.</div>
              : recentQueries.slice(0, 5).map((q, i) => (
                <button key={i} className="lib-item" onClick={() => ask(q)}>
                  {q.length > 55 ? q.slice(0, 55) + "…" : q}
                </button>
              ))
            }
          </div>

          <Expander title="Saved insights">
            {savedInsights.length === 0
              ? <div style={{ fontSize: 12, color: "#94a3b8", textAlign: "center" }}>Save any Genie answer to see it here.</div>
              : savedInsights.map((s, i) => (
                <button key={i} className="lib-item" onClick={() => ask(s.question)}>
                  {s.title}
                </button>
              ))
            }
          </Expander>

          <Expander title="Frequently asked by you">
            {recentQueries.slice(0, 8).map((q, i) => (
              <button key={i} className="lib-item" onClick={() => ask(q)}>
                {q.length > 55 ? q.slice(0, 55) + "…" : q}
              </button>
            ))}
          </Expander>
        </div>

        {/* RIGHT: AI ASSISTANT */}
        <div className="genie-panel">
          <div className="chat-header">
            <div className="chat-title">AI Assistant</div>
            <div className="chat-header-btns">
              <button className="chat-hbtn" disabled={messages.length === 0} onClick={exportMD}>Export MD</button>
              <button className="chat-hbtn" disabled={messages.length === 0} onClick={clearChat}>Clear</button>
              {messages.length > 0 && messages[messages.length - 1]?.role === "ai" && (
                <button className="chat-hbtn"
                  onClick={() => saveInsight(messages.findLast(m => m.role === "user")?.content || "")}>
                  ⭐ Save
                </button>
              )}
            </div>
          </div>

          {/* CHAT SCROLL */}
          <div className="chat-scroll" ref={scrollRef}>
            {messages.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">•</div>
                <div className="empty-title">Start a Conversation</div>
                <div className="empty-sub">Ask questions about your Sales &amp; Operations data, or select a quick analysis above.</div>
              </div>
            ) : (
              messages.map((msg, i) => (
                msg.role === "user" ? (
                  <div key={i} className="bubble-user">
                    <div className="bubble-user-inner">
                      <div className="bubble-lbl">You</div>
                      {msg.content}
                    </div>
                  </div>
                ) : (
                  <div key={i} className="bubble-ai">
                    <div className="bubble-ai-inner">
                      <div className="bubble-lbl">Genie</div>
                      {renderAIContent(msg.content)}
                    </div>
                  </div>
                )
              ))
            )}
            {loading && (
              <div className="bubble-ai">
                <div className="bubble-ai-inner">
                  <div className="bubble-lbl">Genie</div>
                  <span className="loading-spinner" style={{ display: "inline-block" }} />
                  {" "}Analyzing…
                </div>
              </div>
            )}
          </div>

          {/* CHAT INPUT */}
          <div className="chat-form">
            <input
              className="chat-input"
              placeholder="Ask about Sales &amp; Operations data..."
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleSend()}
            />
            <button className="chat-send" onClick={handleSend}>→</button>
          </div>
        </div>
      </div>
    </div>
  );
}
