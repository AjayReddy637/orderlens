require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const { AthenaClient, StartQueryExecutionCommand, GetQueryExecutionCommand, GetQueryResultsCommand } = require("@aws-sdk/client-athena");
const { BedrockRuntimeClient, InvokeModelCommand } = require("@aws-sdk/client-bedrock-runtime");

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3001;
const REGION = process.env.AWS_REGION || "us-east-1";
const DATABASE = process.env.ATHENA_DATABASE || "orderlens";
const WORKGROUP = process.env.ATHENA_WORKGROUP || "primary";
const OUTPUT_BUCKET = process.env.ATHENA_OUTPUT_BUCKET;
const BEDROCK_MODEL = process.env.BEDROCK_MODEL_ID || "amazon.nova-micro-v1:0";

// ── AWS CLIENTS ────────────────────────────────────────────────────────────────
const awsCreds = {
  region: REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
};

const athenaClient = new AthenaClient(awsCreds);
const bedrockClient = new BedrockRuntimeClient(awsCreds);

// ── ATHENA HELPER ──────────────────────────────────────────────────────────────
async function waitForQuery(queryExecutionId, maxWait = 120000) {
  const start = Date.now();
  while (Date.now() - start < maxWait) {
    const res = await athenaClient.send(new GetQueryExecutionCommand({ QueryExecutionId: queryExecutionId }));
    const state = res.QueryExecution.Status.State;
    if (state === "SUCCEEDED") return true;
    if (state === "FAILED" || state === "CANCELLED") {
      throw new Error(`Query ${state}: ${res.QueryExecution.Status.StateChangeReason}`);
    }
    await new Promise(r => setTimeout(r, 1500));
  }
  throw new Error("Query timeout after " + maxWait + "ms");
}

async function getQueryResults(queryExecutionId) {
  const results = [];
  let nextToken;
  let isFirst = true;
  do {
    const res = await athenaClient.send(new GetQueryResultsCommand({
      QueryExecutionId: queryExecutionId,
      NextToken: nextToken,
    }));
    const rows = res.ResultSet.Rows;
    if (rows.length === 0) break;
    const headers = rows[0].Data.map(d => d.VarCharValue);
    const dataRows = isFirst ? rows.slice(1) : rows;
    isFirst = false;
    for (const row of dataRows) {
      const obj = {};
      row.Data.forEach((cell, i) => { obj[headers[i]] = cell.VarCharValue ?? null; });
      results.push(obj);
    }
    nextToken = res.NextToken;
  } while (nextToken);
  return results;
}

async function runQuery(sql) {
  const startRes = await athenaClient.send(new StartQueryExecutionCommand({
    QueryString: sql,
    QueryExecutionContext: { Database: DATABASE },
    WorkGroup: WORKGROUP,
    ResultConfiguration: { OutputLocation: OUTPUT_BUCKET },
  }));
  const queryId = startRes.QueryExecutionId;
  await waitForQuery(queryId);
  return await getQueryResults(queryId);
}

// ── ROUTES ─────────────────────────────────────────────────────────────────────

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// Generic Athena query endpoint
app.post("/api/query", async (req, res) => {
  const { sql } = req.body;
  if (!sql) return res.status(400).json({ error: "sql is required" });
  try {
    const data = await runQuery(sql);
    res.json({ data });
  } catch (err) {
    console.error("Athena error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// Bedrock AI endpoint
app.post("/api/ai", async (req, res) => {
  const { prompt } = req.body;
  if (!prompt) return res.status(400).json({ error: "prompt is required" });
  try {
    const body = JSON.stringify({
      messages: [{ role: "user", content: [{ text: prompt.slice(0, 4000) }] }],
      inferenceConfig: { maxTokens: 1024, temperature: 0.3 },
    });
    const result = await bedrockClient.send(new InvokeModelCommand({
      modelId: BEDROCK_MODEL,
      body,
      contentType: "application/json",
      accept: "application/json",
    }));
    const decoded = JSON.parse(new TextDecoder().decode(result.body));
    const text = decoded?.output?.message?.content?.[0]?.text || "";
    res.json({ text });
  } catch (err) {
    console.error("Bedrock error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── DASHBOARD ENDPOINTS ────────────────────────────────────────────────────────

app.post("/api/dashboard/kpis", async (req, res) => {
  const { startDate, endDate, dealerClause, prevStart, prevEnd } = req.body;
  const dc = dealerClause || "";
  try {
    const [curr, prev] = await Promise.all([
      runQuery(`SELECT COALESCE(SUM(TOTAL_AMOUNT),0) AS REVENUE, COUNT(DISTINCT ORDER_ID) AS ORDERS, COALESCE(SUM(TOTAL_AMOUNT)/NULLIF(COUNT(DISTINCT ORDER_ID),0),0) AS AOV, COUNT(DISTINCT DEALER_ID) AS DEALERS, COUNT(DISTINCT PRODUCT_ID) AS PRODUCTS, COALESCE(SUM(QUANTITY),0) AS UNITS FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dc}`),
      runQuery(`SELECT COALESCE(SUM(TOTAL_AMOUNT),0) AS REVENUE, COUNT(DISTINCT ORDER_ID) AS ORDERS, COALESCE(SUM(TOTAL_AMOUNT)/NULLIF(COUNT(DISTINCT ORDER_ID),0),0) AS AOV, COUNT(DISTINCT DEALER_ID) AS DEALERS, COUNT(DISTINCT PRODUCT_ID) AS PRODUCTS, COALESCE(SUM(QUANTITY),0) AS UNITS FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN DATE '${prevStart}' AND DATE '${prevEnd}' ${dc}`),
    ]);
    res.json({ current: curr[0] || {}, previous: prev[0] || {} });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/sales-by-type", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT p.PRODUCT_TYPE, COUNT(DISTINCT f.ORDER_ID) AS ORDER_COUNT, SUM(f.TOTAL_AMOUNT) AS TOTAL_SALES FROM FACT_ORDER_HISTORY_VW f JOIN DIM_PRODUCT_VW p ON f.PRODUCT_ID=p.PRODUCT_ID AND p.CURRENT_FLAG='Y' WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY p.PRODUCT_TYPE ORDER BY TOTAL_SALES DESC`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/order-status", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT ORDER_STATUS, COUNT(DISTINCT ORDER_ID) AS ORDER_COUNT FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY ORDER_STATUS ORDER BY ORDER_COUNT DESC`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/monthly-revenue", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT DATE_FORMAT(DATE_TRUNC('month', EFFECTIVE_DATE),'%Y-%m') AS MONTH, SUM(TOTAL_AMOUNT)/1000000.0 AS REVENUE_M FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY 1 ORDER BY 1`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/monthly-orders", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT DATE_FORMAT(DATE_TRUNC('month', EFFECTIVE_DATE),'%Y-%m') AS MONTH, COUNT(DISTINCT ORDER_ID) AS ORDERS FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY 1 ORDER BY 1`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/category-performance", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT DEALER_NAME, SUM(TOTAL_AMOUNT)/1000000.0 AS REVENUE_M FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY DEALER_NAME ORDER BY REVENUE_M DESC LIMIT 10`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/dealer-performance", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT f.DEALER_NAME, d.DEALER_TYPE, COUNT(DISTINCT f.ORDER_ID) AS ORDERS, SUM(f.TOTAL_AMOUNT)/1000000.0 AS REVENUE_MILLIONS, SUM(f.TOTAL_AMOUNT)/NULLIF(COUNT(DISTINCT f.ORDER_ID),0) AS AVG_ORDER_VALUE, COUNT(DISTINCT f.PRODUCT_ID) AS PRODUCT_COUNT FROM FACT_ORDER_HISTORY_VW f JOIN DIM_DEALER_VW d ON f.DEALER_ID=d.DEALER_ID AND d.CURRENT_FLAG='Y' WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY f.DEALER_NAME, d.DEALER_TYPE ORDER BY REVENUE_MILLIONS DESC`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/dealer-type-dist", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT d.DEALER_TYPE, COUNT(DISTINCT f.DEALER_ID) AS DEALER_COUNT, SUM(f.TOTAL_AMOUNT) AS REVENUE FROM FACT_ORDER_HISTORY_VW f JOIN DIM_DEALER_VW d ON f.DEALER_ID=d.DEALER_ID AND d.CURRENT_FLAG='Y' WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY d.DEALER_TYPE`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/unique-products", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT DEALER_NAME, COUNT(DISTINCT PRODUCT_ID) AS UNIQUE_PRODUCTS FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY DEALER_NAME ORDER BY UNIQUE_PRODUCTS DESC LIMIT 15`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/rev-by-dealer", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT DEALER_NAME, SUM(TOTAL_AMOUNT)/1000000.0 AS REVENUE_M FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY DEALER_NAME ORDER BY REVENUE_M DESC LIMIT 15`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/config-revenue", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT CONFIG_NAME, SUM(TOTAL_AMOUNT)/1000000.0 AS REVENUE_M FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' AND CONFIG_NAME IS NOT NULL AND EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY CONFIG_NAME ORDER BY REVENUE_M DESC`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/config-aov", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT CONFIG_NAME, SUM(TOTAL_AMOUNT)/NULLIF(COUNT(DISTINCT ORDER_ID),0) AS AVG_ORDER_VALUE FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' AND CONFIG_NAME IS NOT NULL AND EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY CONFIG_NAME ORDER BY AVG_ORDER_VALUE DESC`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/config-by-dealer", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT d.DEALER_TYPE, f.CONFIG_NAME, COUNT(DISTINCT f.ORDER_ID) AS ORDER_COUNT, SUM(f.TOTAL_AMOUNT)/1000000.0 AS REVENUE_M FROM FACT_ORDER_HISTORY_VW f JOIN DIM_DEALER_VW d ON f.DEALER_ID=d.DEALER_ID AND d.CURRENT_FLAG='Y' WHERE f.CURRENT_FLAG='Y' AND f.CONFIG_NAME IS NOT NULL AND f.EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY d.DEALER_TYPE, f.CONFIG_NAME ORDER BY d.DEALER_TYPE, REVENUE_M DESC`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/top-features", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT fe.FEATURE_NAME, SUM(f.TOTAL_AMOUNT)/1000000.0 AS REVENUE_M FROM FACT_ORDER_HISTORY_VW f LEFT JOIN DIM_FEATURE_VW fe ON f.FEATURE_ID=fe.FEATURE_ID AND fe.CURRENT_FLAG='Y' WHERE f.CURRENT_FLAG='Y' AND f.FEATURE_ID IS NOT NULL AND f.EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY fe.FEATURE_NAME ORDER BY REVENUE_M DESC LIMIT 10`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/features-by-dealer", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT d.DEALER_TYPE, fe.FEATURE_NAME, SUM(f.TOTAL_AMOUNT)/1000000.0 AS REVENUE_M FROM FACT_ORDER_HISTORY_VW f JOIN DIM_DEALER_VW d ON f.DEALER_ID=d.DEALER_ID AND d.CURRENT_FLAG='Y' LEFT JOIN DIM_FEATURE_VW fe ON f.FEATURE_ID=fe.FEATURE_ID AND fe.CURRENT_FLAG='Y' WHERE f.CURRENT_FLAG='Y' AND f.FEATURE_ID IS NOT NULL AND fe.FEATURE_NAME IS NOT NULL AND f.EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY d.DEALER_TYPE, fe.FEATURE_NAME ORDER BY REVENUE_M DESC`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/dashboard/features-by-product", async (req, res) => {
  const { startDate, endDate, dealerClause } = req.body;
  try {
    const data = await runQuery(`SELECT p.PRODUCT_TYPE, fe.FEATURE_NAME, SUM(f.TOTAL_AMOUNT)/1000000.0 AS REVENUE_M FROM FACT_ORDER_HISTORY_VW f JOIN DIM_PRODUCT_VW p ON f.PRODUCT_ID=p.PRODUCT_ID AND p.CURRENT_FLAG='Y' LEFT JOIN DIM_FEATURE_VW fe ON f.FEATURE_ID=fe.FEATURE_ID AND fe.CURRENT_FLAG='Y' WHERE f.CURRENT_FLAG='Y' AND f.FEATURE_ID IS NOT NULL AND p.PRODUCT_TYPE IS NOT NULL AND fe.FEATURE_NAME IS NOT NULL AND f.EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ${dealerClause || ""} GROUP BY p.PRODUCT_TYPE, fe.FEATURE_NAME ORDER BY REVENUE_M DESC`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get("/api/dashboard/dealers", async (req, res) => {
  const { startDate, endDate } = req.query;
  try {
    const data = await runQuery(`SELECT DISTINCT DEALER_NAME FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y' AND EFFECTIVE_DATE BETWEEN DATE '${startDate}' AND DATE '${endDate}' ORDER BY DEALER_NAME`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── ORDER LIFECYCLE ENDPOINTS ──────────────────────────────────────────────────

app.get("/api/orders/ids", async (req, res) => {
  try {
    const data = await runQuery(`SELECT DISTINCT ORDER_ID FROM FACT_ORDER_HISTORY_VW ORDER BY ORDER_ID DESC LIMIT 200`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/orders/summary", async (req, res) => {
  const { orderIds } = req.body;
  const ids = orderIds.map(id => `'${id.replace(/'/g, "''")}'`).join(",");
  try {
    const data = await runQuery(`SELECT ORDER_ID, MAX(CASE WHEN ORDER_STATUS='PLACED' THEN ORDER_STATUS_DATE END) AS ORDER_DATE, MAX(CASE WHEN CURRENT_FLAG='Y' THEN ORDER_STATUS END) AS LATEST_STATUS, MAX(DEALER_ID) AS DEALER_ID, MAX(DEALER_NAME) AS DEALER_NAME, SUM(QUANTITY) AS TOTAL_QUANTITY, SUM(TOTAL_AMOUNT) AS TOTAL_AMOUNT, COUNT(DISTINCT PRODUCT_ID) AS PRODUCT_COUNT, MAX(EXPECTED_DELIVERY_DATE) AS EXPECTED_DELIVERY_DATE FROM FACT_ORDER_HISTORY_VW WHERE ORDER_ID IN (${ids}) GROUP BY ORDER_ID`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/orders/status", async (req, res) => {
  const { orderIds } = req.body;
  const ids = orderIds.map(id => `'${id.replace(/'/g, "''")}'`).join(",");
  try {
    const data = await runQuery(`SELECT ORDER_ID, ORDER_STATUS, ORDER_STATUS_DATE FROM FACT_ORDER_HISTORY_VW WHERE ORDER_ID IN (${ids}) GROUP BY ORDER_ID, ORDER_STATUS, ORDER_STATUS_DATE ORDER BY ORDER_ID, CASE UPPER(ORDER_STATUS) WHEN 'PLACED' THEN 1 WHEN 'CONFIRMED' THEN 2 WHEN 'SHIPPED' THEN 3 WHEN 'DELIVERED' THEN 4 ELSE 5 END`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/orders/products", async (req, res) => {
  const { orderIds } = req.body;
  const ids = orderIds.map(id => `'${id.replace(/'/g, "''")}'`).join(",");
  try {
    const data = await runQuery(`SELECT c.PRODUCT_ID, c.PRODUCT_NAME, c.MATERIAL_TYPE, c.PRODUCT_TYPE, c.PRODUCT_CATEGORY, c.CONFIG_NAME, c.CONFIG_TYPE, c.UNIT_PRICE, o.QUANTITY AS TOTAL_QUANTITY_ORDERED FROM PRODUCT_CATALOG_VW c JOIN (SELECT PRODUCT_ID, CONFIG_ID, QUANTITY FROM FACT_ORDER_HISTORY_VW WHERE ORDER_ID IN (${ids})) o ON c.PRODUCT_ID=o.PRODUCT_ID AND c.CONFIG_ID=o.CONFIG_ID`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/orders/dealers", async (req, res) => {
  const { dealerIds } = req.body;
  const ids = dealerIds.map(id => `'${id.replace(/'/g, "''")}'`).join(",");
  try {
    const data = await runQuery(`SELECT f.DEALER_ID, f.DEALER_NAME, d.DEALER_TYPE, d.COUNTRY, d.REGION, d.CITY, SUM(k.ORDER_COUNT) AS TOTAL_ORDERS, SUM(k.REVENUE) AS TOTAL_REVENUE FROM FACT_ORDER_HISTORY_VW f LEFT JOIN DEALER_ORDER_KPI_VW k ON f.DEALER_ID=k.DEALER_ID LEFT JOIN DIM_DEALER_VW d ON f.DEALER_ID=d.DEALER_ID AND d.CURRENT_FLAG='Y' WHERE f.DEALER_ID IN (${ids}) GROUP BY f.DEALER_ID, f.DEALER_NAME, d.DEALER_TYPE, d.COUNTRY, d.REGION, d.CITY`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/orders/bom", async (req, res) => {
  const { productIds } = req.body;
  const ids = productIds.map(id => `'${id.replace(/'/g, "''")}'`).join(",");
  try {
    const data = await runQuery(`SELECT PARENT_PRODUCT, PARENT_PRODUCT_NAME, CHILD_PRODUCT, CHILD_PRODUCT_NAME, QUANTITY_PER_ASSEMBLY, UNIT_OF_MEASURE, SCRAP_FACTOR FROM PRODUCT_BOM_VW WHERE PARENT_PRODUCT IN (${ids})`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── FORECAST ENDPOINTS ─────────────────────────────────────────────────────────

app.get("/api/forecast/products", async (req, res) => {
  try {
    const data = await runQuery(`SELECT DISTINCT PRODUCT_ID, PRODUCT_NAME FROM PRODUCT_FORECAST_KPI_VW ORDER BY PRODUCT_NAME`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get("/api/forecast/months", async (req, res) => {
  try {
    const data = await runQuery(`SELECT DISTINCT DATE_FORMAT(DATE_TRUNC('month', FORECAST_PERIOD_END),'%Y-%m') AS MONTH FROM PRODUCT_FORECAST_KPI_VW ORDER BY MONTH`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/forecast/qty", async (req, res) => {
  const { productClause, monthClause } = req.body;
  try {
    const data = await runQuery(`SELECT DATE_FORMAT(DATE_TRUNC('month', FORECAST_PERIOD_END),'%Y-%m') AS MONTH, SUM(FORECAST_QUANTITY) AS QTY FROM PRODUCT_FORECAST_KPI_VW F WHERE 1=1 ${productClause || ""} ${monthClause || ""} GROUP BY 1 ORDER BY 1`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/forecast/rev", async (req, res) => {
  const { productClause, monthClause } = req.body;
  try {
    const data = await runQuery(`SELECT DATE_FORMAT(DATE_TRUNC('month', FORECAST_PERIOD_END),'%Y-%m') AS MONTH, SUM(FORECAST_REVENUE)/1000000.0 AS REVENUE_M FROM PRODUCT_FORECAST_KPI_VW F WHERE 1=1 ${productClause || ""} ${monthClause || ""} GROUP BY 1 ORDER BY 1`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/forecast/product-mix", async (req, res) => {
  const { productClause, monthClause } = req.body;
  try {
    const data = await runQuery(`SELECT p.PRODUCT_CATEGORY, p.PRODUCT_TYPE, SUM(f.FORECAST_QUANTITY) AS FORECAST_QUANTITY, SUM(f.FORECAST_REVENUE)/1000000.0 AS FORECAST_REVENUE_M FROM PRODUCT_FORECAST_KPI_VW f LEFT JOIN DIM_PRODUCT_VW p ON f.PRODUCT_ID=p.PRODUCT_ID AND p.CURRENT_FLAG='Y' WHERE 1=1 ${productClause || ""} ${monthClause || ""} AND p.PRODUCT_CATEGORY IS NOT NULL GROUP BY p.PRODUCT_CATEGORY, p.PRODUCT_TYPE ORDER BY FORECAST_REVENUE_M DESC`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/forecast/rev-share", async (req, res) => {
  const { productClause, monthClause } = req.body;
  try {
    const data = await runQuery(`SELECT p.PRODUCT_FAMILY, SUM(f.FORECAST_REVENUE)/1000000.0 AS REVENUE_M FROM PRODUCT_FORECAST_KPI_VW f LEFT JOIN DIM_PRODUCT_VW p ON f.PRODUCT_ID=p.PRODUCT_ID AND p.CURRENT_FLAG='Y' WHERE 1=1 ${productClause || ""} ${monthClause || ""} AND p.PRODUCT_FAMILY IS NOT NULL GROUP BY p.PRODUCT_FAMILY ORDER BY REVENUE_M DESC LIMIT 10`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── AGENT ENDPOINTS ────────────────────────────────────────────────────────────

app.post("/api/agents/pipeline-funnel", async (req, res) => {
  const { frac } = req.body;
  const fracClause = frac >= 1.0 ? "dt_min" : `DATE_ADD('day', CAST(-ROUND(total_days * ${frac}, 0) AS INTEGER), dt_max)`;
  try {
    const data = await runQuery(`WITH date_bounds AS (SELECT MIN(EFFECTIVE_DATE) AS dt_min, MAX(EFFECTIVE_DATE) AS dt_max, DATE_DIFF('day', MIN(EFFECTIVE_DATE), MAX(EFFECTIVE_DATE)) AS total_days FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y'), analysis_window AS (SELECT dt_max, ${fracClause} AS a_start FROM date_bounds), orders_in_window AS (SELECT DISTINCT f.ORDER_ID FROM FACT_ORDER_HISTORY_VW f CROSS JOIN analysis_window aw WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE BETWEEN aw.a_start AND aw.dt_max), stage_reach AS (SELECT f.ORDER_ID, MAX(CASE WHEN UPPER(f.ORDER_STATUS)='PLACED' THEN 1 ELSE 0 END) AS rp, MAX(CASE WHEN UPPER(f.ORDER_STATUS)='CONFIRMED' THEN 1 ELSE 0 END) AS rc, MAX(CASE WHEN UPPER(f.ORDER_STATUS)='SHIPPED' THEN 1 ELSE 0 END) AS rs, MAX(CASE WHEN UPPER(f.ORDER_STATUS)='DELIVERED' THEN 1 ELSE 0 END) AS rd FROM FACT_ORDER_HISTORY_VW f INNER JOIN orders_in_window o ON f.ORDER_ID=o.ORDER_ID WHERE f.CURRENT_FLAG='Y' GROUP BY f.ORDER_ID) SELECT SUM(rp) AS PLACED_COUNT, SUM(rc) AS CONFIRMED_COUNT, SUM(rs) AS SHIPPED_COUNT, SUM(rd) AS DELIVERED_COUNT, COUNT(*) AS TOTAL_ORDERS FROM stage_reach`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/agents/dealer-dropoff", async (req, res) => {
  const { frac, minOrders } = req.body;
  const fracClause = frac >= 1.0 ? "dt_min" : `DATE_ADD('day', CAST(-ROUND(total_days * ${frac}, 0) AS INTEGER), dt_max)`;
  try {
    const data = await runQuery(`WITH date_bounds AS (SELECT MIN(EFFECTIVE_DATE) AS dt_min, MAX(EFFECTIVE_DATE) AS dt_max, DATE_DIFF('day', MIN(EFFECTIVE_DATE), MAX(EFFECTIVE_DATE)) AS total_days FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y'), analysis_window AS (SELECT dt_max, ${fracClause} AS a_start FROM date_bounds), dealer_orders AS (SELECT DISTINCT f.ORDER_ID, f.DEALER_NAME FROM FACT_ORDER_HISTORY_VW f CROSS JOIN analysis_window aw WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE BETWEEN aw.a_start AND aw.dt_max), dealer_stage_reach AS (SELECT d.DEALER_NAME, d.ORDER_ID, MAX(CASE WHEN UPPER(f.ORDER_STATUS)='PLACED' THEN 1 ELSE 0 END) AS rp, MAX(CASE WHEN UPPER(f.ORDER_STATUS)='CONFIRMED' THEN 1 ELSE 0 END) AS rc, MAX(CASE WHEN UPPER(f.ORDER_STATUS)='SHIPPED' THEN 1 ELSE 0 END) AS rs, MAX(CASE WHEN UPPER(f.ORDER_STATUS)='DELIVERED' THEN 1 ELSE 0 END) AS rd FROM dealer_orders d JOIN FACT_ORDER_HISTORY_VW f ON d.ORDER_ID=f.ORDER_ID WHERE f.CURRENT_FLAG='Y' GROUP BY d.DEALER_NAME, d.ORDER_ID) SELECT DEALER_NAME, COUNT(*) AS TOTAL_ORDERS, SUM(rp) AS PLACED_CNT, SUM(rc) AS CONFIRMED_CNT, SUM(rs) AS SHIPPED_CNT, SUM(rd) AS DELIVERED_CNT, ROUND(SUM(rc)*100.0/NULLIF(SUM(rp),0),1) AS CONFIRMED_PCT, ROUND(SUM(rs)*100.0/NULLIF(SUM(rp),0),1) AS SHIPPED_PCT, ROUND(SUM(rd)*100.0/NULLIF(SUM(rp),0),1) AS DELIVERED_PCT FROM dealer_stage_reach GROUP BY DEALER_NAME HAVING COUNT(*) >= ${minOrders || 1} ORDER BY DELIVERED_PCT ASC`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post("/api/agents/order-velocity", async (req, res) => {
  const { splitFrac, dropThresh, maxDealers } = req.body;
  const sf = splitFrac || 0.5;
  try {
    const data = await runQuery(`WITH date_bounds AS (SELECT MIN(EFFECTIVE_DATE) AS dt_min, MAX(EFFECTIVE_DATE) AS dt_max, DATE_DIFF('day', MIN(EFFECTIVE_DATE), MAX(EFFECTIVE_DATE)) AS total_days FROM FACT_ORDER_HISTORY_VW WHERE CURRENT_FLAG='Y'), split_date AS (SELECT dt_min, dt_max, DATE_ADD('day', CAST(ROUND(total_days * ${1 - sf}, 0) AS INTEGER), dt_min) AS split_pt, ROUND(total_days * ${1 - sf}, 0) AS prior_days, ROUND(total_days * ${sf}, 0) AS curr_days FROM date_bounds), current_p AS (SELECT f.DEALER_NAME, COUNT(DISTINCT f.ORDER_ID) AS CURR_ORDERS, COUNT(DISTINCT f.PRODUCT_ID) AS CURR_PRODUCTS, SUM(f.TOTAL_AMOUNT) AS CURR_REV, s.curr_days FROM FACT_ORDER_HISTORY_VW f CROSS JOIN split_date s WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE > s.split_pt AND f.EFFECTIVE_DATE <= s.dt_max GROUP BY f.DEALER_NAME, s.curr_days), prior_p AS (SELECT f.DEALER_NAME, COUNT(DISTINCT f.ORDER_ID) AS PREV_ORDERS, COUNT(DISTINCT f.PRODUCT_ID) AS PREV_PRODUCTS, SUM(f.TOTAL_AMOUNT) AS PREV_REV, s.prior_days FROM FACT_ORDER_HISTORY_VW f CROSS JOIN split_date s WHERE f.CURRENT_FLAG='Y' AND f.EFFECTIVE_DATE >= s.dt_min AND f.EFFECTIVE_DATE <= s.split_pt GROUP BY f.DEALER_NAME, s.prior_days) SELECT c.DEALER_NAME, COALESCE(p.PREV_ORDERS,0) AS PREV_ORDERS, COALESCE(c.CURR_ORDERS,0) AS CURR_ORDERS, COALESCE(p.PREV_PRODUCTS,0) AS PREV_PRODUCTS, COALESCE(c.CURR_PRODUCTS,0) AS CURR_PRODUCTS, COALESCE(p.PREV_REV,0) AS PREV_REV, COALESCE(c.CURR_REV,0) AS CURR_REV, ROUND(COALESCE(c.CURR_ORDERS,0)*1.0/NULLIF(c.curr_days,0),4) AS CURR_ORDERS_PER_DAY, ROUND(COALESCE(p.PREV_ORDERS,0)*1.0/NULLIF(p.prior_days,0),4) AS PREV_ORDERS_PER_DAY, CASE WHEN COALESCE(p.PREV_ORDERS,0)>0 THEN ROUND((COALESCE(c.CURR_ORDERS,0)-p.PREV_ORDERS)*1.0/p.PREV_ORDERS*100,1) ELSE NULL END AS ORDER_CHANGE_PCT FROM current_p c LEFT JOIN prior_p p ON c.DEALER_NAME=p.DEALER_NAME WHERE COALESCE(p.PREV_ORDERS,0)>0 AND COALESCE(c.CURR_ORDERS,0) < p.PREV_ORDERS*(1-${dropThresh || 20}/100.0) ORDER BY ORDER_CHANGE_PCT ASC LIMIT ${maxDealers || 10}`);
    res.json({ data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── SERVE REACT BUILD ──────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, "../client/build")));
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../client/build", "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`\n✅ OrderLens server running at http://0.0.0.0:${PORT}`);
  console.log(`📊 Athena database: ${DATABASE}`);
  console.log(`🤖 Bedrock model: ${BEDROCK_MODEL}`);
  console.log(`🪣 S3 bucket: ${OUTPUT_BUCKET}\n`);
});
